# Database Manager - Work Management System

## Quick Summary

A PostgreSQL-compatible IndexedDB database manager for offline work ticket management. Supports single-user operation with day-focused task organization, comprehensive search, and data export/import capabilities.

## Key Features

- **Single User**: Auto-generates unique user ID on first run
- **Day-Focused**: Tasks organized by date with calendar navigation
- **Relational Structure**: Tickets → Buildings → Devices with proper relationships
- **Search & Filter**: Full-text search across all task fields
- **Export/Import**: JSON format for backup and data migration
- **Offline First**: Works completely offline using IndexedDB

## Database Structure

```
users (single user)
├── buildings (one building per system)
│   └── devices (multiple devices per building)
└── tickets (unique ticket numbers)
    └── ticketEntries (multiple daily entries per ticket)
miscEntries (general tasks not tied to tickets)
```

## Core Rules

1. **One Ticket = One Building**: Tickets are permanently tied to a building
2. **Multiple Entries per Ticket**: Same ticket can have multiple daily work entries
3. **Flexible Devices**: Each entry can specify different devices from the building
4. **Building Code Tolerance**: Job names may contain incorrect building codes (human error)

## Usage

### Initialize Database
```javascript
const dbManager = new TicketDBManager();
await dbManager.init();
```

### Create Ticket Entry
```javascript
// Ensure ticket exists (creates if new)
const ticket = await dbManager.ensureTicket('T123456', buildingId);

// Create entry
const entry = createEmptyTicketEntry('2025-01-15', ticket.id);
entry.jobName = 'Service Call B-802641';
entry.jobDeviceNames = 'Reader-101\nDoor-Contact-A2'; // One per line
entry.jobTroubleDescription = 'Reader not responding';
entry.jobWorkDescription = 'Replaced reader module';

await dbManager.saveTicketEntry(entry);
```

### Create General Task
```javascript
const entry = createEmptyMiscEntry('2025-01-15');
entry.miscName = 'Routine maintenance';
entry.miscDescription = 'Monthly system check';
entry.miscLocation = 'Building A - 2nd Floor';

await dbManager.saveMiscEntry(entry);
```

### Query Data
```javascript
// Get all entries for a date
const entries = await dbManager.getEntriesForDate('2025-01-15');

// Search across all fields
const results = await dbManager.searchEntries('reader');

// Get all entries for a ticket
const ticketEntries = await dbManager.getEntriesByTicket('T123456');
```

### Export/Import
```javascript
// Export all data
const data = await dbManager.exportData();

// Import data (merges with existing)
await dbManager.importData(data);
```

## Field Reference

### Ticket Entry Fields

**Job Information:**
- `jobName` - Service call title
- `jobBuildingCode` - Building identifier (may differ from ticket building)
- `jobDeviceNames` - Multi-line device list (one per line)

**Schedule:**
- `jobStartDate` - Work date (YYYY-MM-DD)
- `jobStartTime` - Start time (HH:MM)
- `jobEndTime` - End time (HH:MM)
- `jobParticipants` - Team members

**Status:**
- `jobDispatchType` - Sim-T, Corrigo, Spontaneous
- `jobFieldStatus` - close, pending, in progress, completed, on hold, reassign, monitor
- `jobFollowupRequired` - Boolean
- `jobFiledStatusNotes` - Additional status info

**Materials:**
- `jobMaterialsUsed` - Materials consumed
- `jobMaterialsNeeded` - Materials required for future work

**Problem & Resolution:**
- `jobTroubleType` - malfunction, DFO, line error, other
- `jobTroubleDescription` - Problem description (required)
- `jobWorkDescription` - Work performed (required)
- `jobTechnicalDetails` - Technical specifications

**Additional:**
- `jobReferenceNumber` - External reference
- `jobEscortDelay` - Time delay for escorts
- `jobHindrances` - Obstacles encountered
- `jobAccessNeeded` - Access requirements
- `jobProgrammingChanges` - System modifications
- `jobDeviceDetails` - Device specifications

### Misc Entry Fields

- `miscName` - Task name
- `miscDescription` - Task description
- `miscLocation` - Work location
- `miscStartDate` - Task date
- `miscStartTime` - Start time
- `miscPriority` - Low, Medium, High, Urgent
- `miscParticipants` - Team members
- `miscDuration` - Duration in minutes
- `miscNotes` - Additional notes

## Test Interface

The `test.html` file provides a complete testing interface:

1. **Calendar Navigation**: Select dates and view tasks
2. **Add Tasks**: Create sample ticket entries and general tasks
3. **Search**: Real-time search across all fields
4. **Expand Details**: Click tasks to view all field data
5. **Data Operations**: Generate sample data, export/import, clear database

## Integration Notes

- **PostgreSQL Compatible**: Field names and structure match PostgreSQL schema
- **User Management**: Single user system with auto-generated ID
- **Building Management**: Auto-creates default building if none exists
- **Device Relationships**: Devices linked to buildings, entries reference devices by name
- **Audit Trail**: Timestamps on all entries (created_at, updated_at)

## Error Handling

- **Ticket Building Conflicts**: Warns when trying to assign different building to existing ticket
- **Missing References**: Auto-creates buildings/devices as needed
- **Data Validation**: Client-side validation for required fields
- **Import Errors**: Graceful handling of malformed import data

This system provides a robust foundation for offline work management with full PostgreSQL migration capability when needed.