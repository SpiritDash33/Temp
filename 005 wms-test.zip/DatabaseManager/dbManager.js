// dbManager.js - PostgreSQL-aligned structure with search
class TicketDBManager {
    constructor() {
        this.dbName = 'TicketWorkDB';
        this.version = 4;
        this.db = null;
        this.currentUserId = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.version);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = async () => {
                this.db = request.result;
                await this.ensureUser();
                await this.ensureBuilding();
                resolve(this.db);
            };
            
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Users store
                if (!db.objectStoreNames.contains('users')) {
                    db.createObjectStore('users', { keyPath: 'id' });
                }
                
                // Buildings store
                if (!db.objectStoreNames.contains('buildings')) {
                    const store = db.createObjectStore('buildings', { keyPath: 'id', autoIncrement: true });
                    store.createIndex('siteCode', 'siteCode', { unique: true });
                }
                
                // Devices store
                if (!db.objectStoreNames.contains('devices')) {
                    const store = db.createObjectStore('devices', { keyPath: 'id', autoIncrement: true });
                    store.createIndex('buildingId', 'buildingId', { unique: false });
                    store.createIndex('deviceName', 'deviceName', { unique: false });
                }
                
                // Tickets store
                if (!db.objectStoreNames.contains('tickets')) {
                    const store = db.createObjectStore('tickets', { keyPath: 'id', autoIncrement: true });
                    store.createIndex('ticketNumber', 'ticketNumber', { unique: true });
                    store.createIndex('buildingId', 'buildingId', { unique: false });
                }
                
                // Ticket entries store
                if (!db.objectStoreNames.contains('ticketEntries')) {
                    const store = db.createObjectStore('ticketEntries', { keyPath: 'id', autoIncrement: true });
                    store.createIndex('userId', 'userId', { unique: false });
                    store.createIndex('ticketId', 'ticketId', { unique: false });
                    store.createIndex('date', 'jobStartDate', { unique: false });
                    store.createIndex('fieldStatus', 'jobFieldStatus', { unique: false });
                    store.createIndex('dispatchType', 'jobDispatchType', { unique: false });
                    store.createIndex('troubleType', 'jobTroubleType', { unique: false });
                }
                
                // Misc entries store
                if (!db.objectStoreNames.contains('miscEntries')) {
                    const store = db.createObjectStore('miscEntries', { keyPath: 'id', autoIncrement: true });
                    store.createIndex('userId', 'userId', { unique: false });
                    store.createIndex('date', 'miscStartDate', { unique: false });
                }
            };
        });
    }

    // Ensure single user exists
    async ensureUser() {
        const transaction = this.db.transaction(['users'], 'readwrite');
        const store = transaction.objectStore('users');
        
        return new Promise((resolve, reject) => {
            const request = store.getAll();
            request.onsuccess = () => {
                if (request.result.length === 0) {
                    const userId = 'user-' + Math.random().toString(36).substr(2, 9);
                    const user = { id: userId, userName: 'Field User', createdAt: new Date().toISOString() };
                    const addRequest = store.add(user);
                    addRequest.onsuccess = () => {
                        this.currentUserId = userId;
                        resolve(userId);
                    };
                } else {
                    this.currentUserId = request.result[0].id;
                    resolve(this.currentUserId);
                }
            };
            request.onerror = () => reject(request.error);
        });
    }

    // Ensure building exists
    async ensureBuilding() {
        const transaction = this.db.transaction(['buildings'], 'readwrite');
        const store = transaction.objectStore('buildings');
        
        return new Promise((resolve, reject) => {
            const request = store.getAll();
            request.onsuccess = () => {
                if (request.result.length === 0) {
                    const building = {
                        siteCode: 'SEA124',
                        buildingName: 'Main Building',
                        description: 'Primary work site',
                        createdAt: new Date().toISOString()
                    };
                    const addRequest = store.add(building);
                    addRequest.onsuccess = () => resolve(addRequest.result);
                } else {
                    resolve(request.result[0].id);
                }
            };
            request.onerror = () => reject(request.error);
        });
    }

    // Ensure ticket exists (one ticket = one building, enforced)
    async ensureTicket(ticketNumber, buildingId) {
        const transaction = this.db.transaction(['tickets'], 'readwrite');
        const store = transaction.objectStore('tickets');
        const index = store.index('ticketNumber');
        
        return new Promise((resolve, reject) => {
            const getRequest = index.get(ticketNumber);
            getRequest.onsuccess = () => {
                if (getRequest.result) {
                    // Ticket exists - enforce same building rule
                    if (getRequest.result.buildingId !== buildingId) {
                        console.warn(`Ticket ${ticketNumber} already exists with different building. Using existing building ${getRequest.result.buildingId}`);
                    }
                    resolve(getRequest.result);
                } else {
                    const ticket = {
                        ticketNumber,
                        buildingId,
                        createdAt: new Date().toISOString(),
                        updatedAt: new Date().toISOString()
                    };
                    const addRequest = store.add(ticket);
                    addRequest.onsuccess = () => resolve({ ...ticket, id: addRequest.result });
                    addRequest.onerror = () => reject(addRequest.error);
                }
            };
            getRequest.onerror = () => reject(getRequest.error);
        });
    }

    // Get all entries for a date
    async getEntriesForDate(date) {
        const ticketTransaction = this.db.transaction(['ticketEntries'], 'readonly');
        const ticketStore = ticketTransaction.objectStore('ticketEntries');
        const ticketIndex = ticketStore.index('date');
        
        const miscTransaction = this.db.transaction(['miscEntries'], 'readonly');
        const miscStore = miscTransaction.objectStore('miscEntries');
        const miscIndex = miscStore.index('date');
        
        return new Promise((resolve, reject) => {
            const ticketRequest = ticketIndex.getAll(date);
            const miscRequest = miscIndex.getAll(date);
            
            Promise.all([
                new Promise(res => { ticketRequest.onsuccess = () => res(ticketRequest.result); }),
                new Promise(res => { miscRequest.onsuccess = () => res(miscRequest.result); })
            ]).then(([ticketEntries, miscEntries]) => {
                const userTicketEntries = ticketEntries.filter(e => e.userId === this.currentUserId);
                const userMiscEntries = miscEntries.filter(e => e.userId === this.currentUserId);
                resolve([...userTicketEntries, ...userMiscEntries]);
            }).catch(reject);
        });
    }

    // Search entries across all fields
    async searchEntries(searchTerm) {
        const ticketTransaction = this.db.transaction(['ticketEntries'], 'readonly');
        const ticketStore = ticketTransaction.objectStore('ticketEntries');
        
        const miscTransaction = this.db.transaction(['miscEntries'], 'readonly');
        const miscStore = miscTransaction.objectStore('miscEntries');
        
        return new Promise((resolve, reject) => {
            const ticketRequest = ticketStore.getAll();
            const miscRequest = miscStore.getAll();
            
            Promise.all([
                new Promise(res => { ticketRequest.onsuccess = () => res(ticketRequest.result); }),
                new Promise(res => { miscRequest.onsuccess = () => res(miscRequest.result); })
            ]).then(([ticketEntries, miscEntries]) => {
                const allEntries = [...ticketEntries, ...miscEntries].filter(e => e.userId === this.currentUserId);
                const results = allEntries.filter(entry => 
                    Object.values(entry).some(value => 
                        String(value).toLowerCase().includes(searchTerm.toLowerCase())
                    )
                );
                resolve(results);
            }).catch(reject);
        });
    }

    // Get entries by ticket
    async getEntriesByTicket(ticketNumber) {
        const ticketsTransaction = this.db.transaction(['tickets'], 'readonly');
        const ticketsStore = ticketsTransaction.objectStore('tickets');
        const ticketsIndex = ticketsStore.index('ticketNumber');
        
        return new Promise((resolve, reject) => {
            const ticketRequest = ticketsIndex.get(ticketNumber);
            ticketRequest.onsuccess = () => {
                if (!ticketRequest.result) {
                    resolve([]);
                    return;
                }
                
                const entriesTransaction = this.db.transaction(['ticketEntries'], 'readonly');
                const entriesStore = entriesTransaction.objectStore('ticketEntries');
                const entriesIndex = entriesStore.index('ticketId');
                
                const entriesRequest = entriesIndex.getAll(ticketRequest.result.id);
                entriesRequest.onsuccess = () => {
                    const userEntries = entriesRequest.result.filter(e => e.userId === this.currentUserId);
                    resolve(userEntries);
                };
                entriesRequest.onerror = () => reject(entriesRequest.error);
            };
            ticketRequest.onerror = () => reject(ticketRequest.error);
        });
    }

    // Save ticket entry
    async saveTicketEntry(entryData) {
        entryData.userId = this.currentUserId;
        entryData.updatedAt = new Date().toISOString();
        
        const transaction = this.db.transaction(['ticketEntries'], 'readwrite');
        const store = transaction.objectStore('ticketEntries');
        
        return new Promise((resolve, reject) => {
            const request = store.put(entryData);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Save misc entry
    async saveMiscEntry(entryData) {
        entryData.userId = this.currentUserId;
        entryData.updatedAt = new Date().toISOString();
        
        const transaction = this.db.transaction(['miscEntries'], 'readwrite');
        const store = transaction.objectStore('miscEntries');
        
        return new Promise((resolve, reject) => {
            const request = store.put(entryData);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Delete entry
    async deleteEntry(entryId, entryType) {
        const storeName = entryType === 'ticket' ? 'ticketEntries' : 'miscEntries';
        const transaction = this.db.transaction([storeName], 'readwrite');
        const store = transaction.objectStore(storeName);
        
        return new Promise((resolve, reject) => {
            const request = store.delete(entryId);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Export all data
    async exportData() {
        const stores = ['users', 'buildings', 'devices', 'tickets', 'ticketEntries', 'miscEntries'];
        const transaction = this.db.transaction(stores, 'readonly');
        
        const promises = stores.map(storeName => {
            const store = transaction.objectStore(storeName);
            return new Promise(resolve => {
                const request = store.getAll();
                request.onsuccess = () => resolve({ [storeName]: request.result });
            });
        });
        
        const results = await Promise.all(promises);
        return Object.assign({}, ...results);
    }

    // Import data
    async importData(data) {
        const stores = ['users', 'buildings', 'devices', 'tickets', 'ticketEntries', 'miscEntries'];
        const transaction = this.db.transaction(stores, 'readwrite');
        
        for (const storeName of stores) {
            const store = transaction.objectStore(storeName);
            await store.clear();
            
            const items = data[storeName] || [];
            for (const item of items) {
                await store.add(item);
            }
        }
        
        await this.ensureUser();
    }
}

// Entry templates matching PostgreSQL schema
const createEmptyTicketEntry = (date, ticketId) => ({
    ticketId: ticketId,
    jobName: '',
    jobStartDate: date,
    jobStartTime: '',
    jobEndTime: '',
    jobParticipants: '',
    jobReferenceNumber: '',
    jobEscortDelay: '',
    jobHindrances: '',
    jobMaterialsUsed: '',
    jobMaterialsNeeded: '',
    jobAccessNeeded: '',
    jobProgrammingChanges: '',
    jobDispatchType: '',
    jobFieldStatus: '',
    jobFiledStatusNotes: '',
    jobFollowupRequired: '',
    jobDeviceNames: '',
    jobDeviceDetails: '',
    jobTroubleType: '',
    jobTroubleDescription: '',
    jobWorkDescription: '',
    jobTechnicalDetails: '',
    jobChangedFlag: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
});

const createEmptyMiscEntry = (date) => ({
    miscName: '',
    miscStartDate: date,
    miscStartTime: '',
    miscDescription: '',
    miscLocation: '',
    miscDuration: null,
    miscPriority: '',
    miscParticipants: '',
    miscNotes: '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
});

// Sample data generators
const sampleData = {
    siteCode: () => ['SEA124', 'PDX89', 'SFO45', 'LAX67', 'DEN23'][Math.floor(Math.random() * 5)],
    ticketNumber: () => 'T' + Math.floor(Math.random() * 900000 + 100000),
    poNumber: () => '2D-' + Math.floor(Math.random() * 90000000 + 10000000),
    bugNumber: () => 'P' + Math.floor(Math.random() * 900000000 + 100000000),
    priority: () => ['P1', 'P2', 'P3', 'P4'][Math.floor(Math.random() * 4)],
    deviceName: () => ['Reader Device', 'Door Contact', 'Motion Sensor', 'Card Reader', 'Access Panel'][Math.floor(Math.random() * 5)],
    deviceType: () => ['Reader', 'Door Contact', 'SAR', 'Mag Hold', 'ADA/Opener', 'Wave Sensor'][Math.floor(Math.random() * 6)],
    troubleType: () => ['Malfunction', 'DFO', 'Line Error', 'Other'][Math.floor(Math.random() * 4)],
    dispatchType: () => ['Sim-T', 'Corrigo', 'Spontaneous'][Math.floor(Math.random() * 3)],
    fieldStatus: () => ['Close', 'Pending', 'In Progress', 'Completed', 'On Hold'][Math.floor(Math.random() * 5)],
    time: () => {
        const hour = Math.floor(Math.random() * 8) + 8; // 8-15
        return `${hour.toString().padStart(2, '0')}:${['00', '15', '30', '45'][Math.floor(Math.random() * 4)]}`;
    },
    jobName: () => {
        const actions = ['Service Call', 'Maintenance', 'Repair', 'Installation', 'Inspection'];
        const codes = ['B-802641', 'A-451289', 'C-789456', 'D-123987'];
        return `${actions[Math.floor(Math.random() * actions.length)]} ${codes[Math.floor(Math.random() * codes.length)]}`;
    },
    troubleDescription: () => {
        const issues = ['Reader not responding', 'Door won\'t unlock', 'Alarm active', 'Card not reading', 'System offline', 'Wiring fault'];
        return issues[Math.floor(Math.random() * issues.length)];
    },
    workDescription: () => {
        const work = ['Replaced reader', 'Fixed wiring', 'Updated firmware', 'Cleaned contacts', 'Reset system', 'Tested functionality'];
        return work[Math.floor(Math.random() * work.length)];
    }
};