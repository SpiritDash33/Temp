// Type definitions for Work Management System

export interface JobEntry {
  id?: number;
  ticketId: number;
  jobNumber: string;
  buildingCode?: string;
  buildingAddress?: string;
  jobName: string;
  jobStartDate: string;
  jobStartTime: string;
  jobEndTime: string;
  jobParticipants?: string;
  jobReferenceNumber?: string;
  jobEscortDelay?: number;
  jobHindrances?: string;
  jobMaterialsUsed?: string;
  jobMaterialsNeeded?: string;
  jobAccessNeeded?: string;
  jobProgrammingChanges?: string;
  jobDispatchType: string;
  jobFieldStatus: string;
  jobFiledStatusNotes?: string;
  jobFollowupRequired: boolean;
  jobDeviceNames: string;
  jobDeviceDetails?: string;
  jobTroubleType?: string;
  jobTroubleDescription: string;
  jobWorkDescription: string;
  jobTechnicalDetails?: string;
  relatedTickets?: string;
  deviceType?: string;
  jobChangedFlag?: boolean;
  createdAt: string;
}

export interface MiscEntry {
  id?: number;
  miscName: string;
  miscStartDate: string;
  miscStartTime?: string;
  miscDescription: string;
  miscLocation?: string;
  miscDuration?: number;
  miscPriority?: string;
  miscParticipants?: string;
  miscNotes?: string;
  createdAt: string;
}

export interface CacheConfig {
  defaultTTL?: number;
  maxSize?: number;
  cleanupInterval?: number;
  enableStats?: boolean;
}

export interface CacheEntry<T = any> {
  data: T;
  metadata: CacheMetadata;
}

export interface CacheMetadata {
  createdAt: number;
  expiresAt: number;
  accessCount: number;
  lastAccessed: number;
}

export interface CacheStats {
  hits: number;
  misses: number;
  sets: number;
  deletes: number;
  evictions: number;
  cleanups: number;
  hitRate: string;
  cacheSize: number;
  memoryUsage: {
    estimatedBytes: number;
    estimatedKB: string;
    estimatedMB: string;
  };
}

export interface HealthCheck {
  healthy: boolean;
  checks: {
    cacheResponding: boolean;
    cleanupWorking: boolean;
    hitRateAcceptable: boolean;
    sizeWithinLimits: boolean;
    memoryReasonable: boolean;
  };
  stats: CacheStats;
  timestamp: string;
}

export interface ValidationResult {
  errors: string[];
  warnings: string[];
  isValid: boolean;
}

export interface ErrorEntry {
  id: string;
  timestamp: string;
  type: string;
  context?: string;
  message: string;
  stack?: string;
  userAgent: string;
  url: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  operation?: string;
  userVisible?: boolean;
}

export interface EventBusSubscription {
  event: string;
  callback: (data: any) => void;
  unsubscribe: () => void;
}

export interface WMSState {
  dbManager: any;
  currentJobId: number | null;
  currentJobEntry: JobEntry | MiscEntry | null;
  currentView: string;
  currentTaskType: string | null;
  focusedDate: string;
  jobs: (JobEntry | MiscEntry)[];
  reorderEnabled: boolean;
  theme: 'light' | 'dark';
}

export interface ServiceContainer {
  database: DatabaseService;
  job: JobService;
  email: EmailService;
  validation: ValidationService;
  ui: UIService;
  error: ErrorBoundaryService;
  cache: CacheService;
}

// Service interfaces
export interface ICacheService {
  get<T>(key: string, fetchFunction: () => Promise<T>, ttl?: number): Promise<T>;
  set<T>(key: string, value: T, ttl?: number): void;
  has(key: string): boolean;
  delete(key: string): boolean;
  clear(): void;
  getStats(): CacheStats;
  healthCheck(): HealthCheck;
  getCachedJobsForDate(date: string, fetchFunction: () => Promise<(JobEntry | MiscEntry)[]>): Promise<(JobEntry | MiscEntry)[]>;
  getCachedEntriesForDate(date: string, fetchFunction: () => Promise<(JobEntry | MiscEntry)[]>): Promise<(JobEntry | MiscEntry)[]>;
  getCachedJob(jobId: number, fetchFunction: () => Promise<JobEntry | MiscEntry>): Promise<JobEntry | MiscEntry>;
  getCachedSearchResults(query: string, type: string, fetchFunction: () => Promise<any[]>): Promise<any[]>;
}

export interface IValidationService {
  validateRequiredFields(jobData?: any): string[];
  highlightRequiredFields(): string[];
  validateJobData(jobData: any): ValidationResult;
  sanitizeInput(input: string): string;
  sanitizeFormData(formData: Record<string, any>): Record<string, any>;
  validateEmailData(emailData: any): ValidationResult;
}

export interface IErrorBoundaryService {
  handleError(error: Error | string, context?: string, options?: ErrorHandlingOptions): ErrorEntry;
  getErrorStats(): any;
  exportErrorLog(): any;
  clearErrorLog(): void;
  healthCheck(): any;
}

export interface ErrorHandlingOptions {
  severity?: 'low' | 'medium' | 'high' | 'critical';
  operation?: string;
  userVisible?: boolean;
  suppressRethrow?: boolean;
  recoveryFn?: (error: ErrorEntry) => void;
}

export interface IJobService {
  loadJobsForDate(date: string): Promise<(JobEntry | MiscEntry)[]>;
  getCurrentJobData(): Record<string, any>;
  getGeneralTaskData(): Record<string, any>;
  saveCurrentJob(): Promise<number>;
  saveGeneralTask(): Promise<number>;
  loadJobById(jobId: number): Promise<JobEntry | MiscEntry | undefined>;
  deleteJobById(jobId: number): Promise<void>;
  createNewJob(taskType?: string): Promise<void>;
  searchJobs(searchTerm: string): Promise<(JobEntry | MiscEntry)[]>;
  populateJobForm(jobData: JobEntry): void;
  populateGeneralForm(jobData: MiscEntry): void;
  clearJobForm(): void;
  clearGeneralForm(): void;
}

export interface IUIService {
  updateAllDisplays(): void;
  showView(viewName: string): void;
  showStatus(message: string, type?: 'info' | 'success' | 'error', duration?: number): void;
  initializeTheme(): void;
  setTheme(theme: 'light' | 'dark'): void;
  toggleTheme(): void;
  selectDate(dateStr: string): Promise<void>;
  navigateToPreviousMonth(): void;
  navigateToNextMonth(): void;
  navigateToCurrentMonth(): void;
  navigateToMonth(month: number, year: number): void;
  displaySearchResults(results: any[], containerId: string): void;
}

export interface IDatabaseService {
  init(): Promise<void>;
  getManager(): any;
  isInitialized(): boolean;
  getEntriesForDate(date: string): Promise<(JobEntry | MiscEntry)[]>;
  saveTicketEntry(entryData: JobEntry): Promise<number>;
  saveMiscEntry(entryData: MiscEntry): Promise<number>;
  deleteEntry(id: number, type: 'ticket' | 'misc'): Promise<void>;
  exportData(): Promise<any>;
  searchEntries(searchTerm: string): Promise<(JobEntry | MiscEntry)[]>;
}

export interface IEmailService {
  handleEmailImport(files: FileList): Promise<void>;
  parseEmailContent(emailContent: string, fileName: string): any;
  populateFormFromEmail(emailData: any): void;
}

export interface IEventBus {
  subscribe(event: string, callback: (data: any) => void): () => void;
  unsubscribe(event: string, callback: (data: any) => void): void;
  publish(event: string, data: any): void;
  clear(): void;
}

export interface IWMSApp {
  init(): Promise<void>;
  getState(): WMSState;
  getService<K extends keyof ServiceContainer>(serviceName: K): ServiceContainer[K];
  isInitialized(): boolean;
  getCurrentJobData(): Record<string, any>;
  saveCurrentJob(): Promise<number>;
  loadJobById(jobId: number): Promise<JobEntry | MiscEntry | undefined>;
  validateRequiredFields(jobData?: any): string[];
  handleFiles(files: FileList): Promise<void>;
}

// Test framework types
export interface TestAssertion {
  toBe(expected: any): TestAssertion;
  toEqual(expected: any): TestAssertion;
  toBeNull(): TestAssertion;
  toBeUndefined(): TestAssertion;
  toBeDefined(): TestAssertion;
  toBeTruthy(): TestAssertion;
  toBeFalsy(): TestAssertion;
  toThrow(expectedError?: string): TestAssertion;
  toResolve(): Promise<TestAssertion>;
  toReject(expectedError?: string): Promise<TestAssertion>;
  toBeInstanceOf(expectedClass: any): TestAssertion;
  toContain(expected: any): TestAssertion;
  toHaveLength(expectedLength: number): TestAssertion;
  toBeGreaterThan(expected: number): TestAssertion;
  toBeLessThan(expected: number): TestAssertion;
  toBeCloseTo(expected: number, precision?: number): TestAssertion;
}

export interface MockFunction {
  calls: any[][];
  returnValue: any;
  implementation: Function | null;
  mockReturnValue(value: any): MockFunction;
  mockImplementation(fn: Function): MockFunction;
  mockResolvedValue(value: any): MockFunction;
  mockRejectedValue(error: any): MockFunction;
  call(...args: any[]): any;
  toHaveBeenCalled(): void;
  toHaveBeenCalledTimes(times: number): void;
  toHaveBeenCalledWith(...expectedArgs: any[]): void;
}

export interface TestResults {
  passed: number;
  failed: number;
  total: number;
  errors: Array<{
    test: string;
    error: string;
    stack?: string;
  }>;
  startTime: number;
  endTime: number;
  duration: number;
}

export interface ITestFramework {
  describe(name: string, callback: () => void): void;
  it(description: string, testFn: () => void | Promise<void>): void;
  beforeEach(fn: () => void | Promise<void>): void;
  afterEach(fn: () => void | Promise<void>): void;
  beforeAll(fn: () => void | Promise<void>): void;
  afterAll(fn: () => void | Promise<void>): void;
  runTests(): Promise<TestResults>;
  expect(actual: any): TestAssertion;
}

// Global declarations for browser environment
declare global {
  interface Window {
    WMSApplication: IWMSApp;
    testRunner: ITestFramework;
    TestFramework: typeof TestFramework;
    MockFunction: typeof MockFunction;
    describe: (name: string, callback: () => void) => void;
    it: (description: string, testFn: () => void | Promise<void>) => void;
    beforeEach: (fn: () => void | Promise<void>) => void;
    afterEach: (fn: () => void | Promise<void>) => void;
    beforeAll: (fn: () => void | Promise<void>) => void;
    afterAll: (fn: () => void | Promise<void>) => void;
    expect: (actual: any) => TestAssertion;
    createMockFunction: () => MockFunction;
    runTests: () => Promise<TestResults>;
    initializeWMSApp: () => Promise<void>;
  }

  class CacheService implements ICacheService {
    constructor(eventBus: IEventBus, options?: CacheConfig);
    get<T>(key: string, fetchFunction: () => Promise<T>, ttl?: number): Promise<T>;
    set<T>(key: string, value: T, ttl?: number): void;
    has(key: string): boolean;
    delete(key: string): boolean;
    clear(): void;
    getStats(): CacheStats;
    healthCheck(): HealthCheck;
    getCachedJobsForDate(date: string, fetchFunction: () => Promise<(JobEntry | MiscEntry)[]>): Promise<(JobEntry | MiscEntry)[]>;
    getCachedEntriesForDate(date: string, fetchFunction: () => Promise<(JobEntry | MiscEntry)[]>): Promise<(JobEntry | MiscEntry)[]>;
    getCachedJob(jobId: number, fetchFunction: () => Promise<JobEntry | MiscEntry>): Promise<JobEntry | MiscEntry>;
    getCachedSearchResults(query: string, type: string, fetchFunction: () => Promise<any[]>): Promise<any[]>;
    destroy(): void;
  }

  class DatabaseService implements IDatabaseService {
    init(): Promise<void>;
    getManager(): any;
    isInitialized(): boolean;
    getEntriesForDate(date: string): Promise<(JobEntry | MiscEntry)[]>;
    saveTicketEntry(entryData: JobEntry): Promise<number>;
    saveMiscEntry(entryData: MiscEntry): Promise<number>;
    deleteEntry(id: number, type: 'ticket' | 'misc'): Promise<void>;
    exportData(): Promise<any>;
    searchEntries(searchTerm: string): Promise<(JobEntry | MiscEntry)[]>;
  }

  class JobService implements IJobService {
    constructor(databaseService: IDatabaseService, eventBus: IEventBus, cacheService?: ICacheService);
    loadJobsForDate(date: string): Promise<(JobEntry | MiscEntry)[]>;
    getCurrentJobData(): Record<string, any>;
    getGeneralTaskData(): Record<string, any>;
    saveCurrentJob(): Promise<number>;
    saveGeneralTask(): Promise<number>;
    loadJobById(jobId: number): Promise<JobEntry | MiscEntry | undefined>;
    deleteJobById(jobId: number): Promise<void>;
    createNewJob(taskType?: string): Promise<void>;
    searchJobs(searchTerm: string): Promise<(JobEntry | MiscEntry)[]>;
    populateJobForm(jobData: JobEntry): void;
    populateGeneralForm(jobData: MiscEntry): void;
    clearJobForm(): void;
    clearGeneralForm(): void;
  }

  class ValidationService implements IValidationService {
    constructor(requiredFields: string[], eventBus: IEventBus);
    validateRequiredFields(jobData?: any): string[];
    highlightRequiredFields(): string[];
    validateJobData(jobData: any): ValidationResult;
    sanitizeInput(input: string): string;
    sanitizeFormData(formData: Record<string, any>): Record<string, any>;
    validateEmailData(emailData: any): ValidationResult;
  }

  class ErrorBoundaryService implements IErrorBoundaryService {
    constructor(eventBus: IEventBus);
    handleError(error: Error | string, context?: string, options?: ErrorHandlingOptions): ErrorEntry;
    getErrorStats(): any;
    exportErrorLog(): any;
    clearErrorLog(): void;
    healthCheck(): any;
  }

  class UIService implements IUIService {
    constructor(eventBus: IEventBus);
    updateAllDisplays(): void;
    showView(viewName: string): void;
    showStatus(message: string, type?: 'info' | 'success' | 'error', duration?: number): void;
    initializeTheme(): void;
    setTheme(theme: 'light' | 'dark'): void;
    toggleTheme(): void;
    selectDate(dateStr: string): Promise<void>;
    navigateToPreviousMonth(): void;
    navigateToNextMonth(): void;
    navigateToCurrentMonth(): void;
    navigateToMonth(month: number, year: number): void;
    displaySearchResults(results: any[], containerId: string): void;
  }

  class EmailService implements IEmailService {
    constructor(jobService: IJobService, eventBus: IEventBus);
    handleEmailImport(files: FileList): Promise<void>;
    parseEmailContent(emailContent: string, fileName: string): any;
    populateFormFromEmail(emailData: any): void;
  }

  class EventBus implements IEventBus {
    subscribe(event: string, callback: (data: any) => void): () => void;
    unsubscribe(event: string, callback: (data: any) => void): void;
    publish(event: string, data: any): void;
    clear(): void;
  }

  class WMSApp implements IWMSApp {
    constructor();
    init(): Promise<void>;
    getState(): WMSState;
    getService<K extends keyof ServiceContainer>(serviceName: K): ServiceContainer[K];
    isInitialized(): boolean;
    getCurrentJobData(): Record<string, any>;
    saveCurrentJob(): Promise<number>;
    loadJobById(jobId: number): Promise<JobEntry | MiscEntry | undefined>;
    validateRequiredFields(jobData?: any): string[];
    handleFiles(files: FileList): Promise<void>;
  }

  class TestFramework implements ITestFramework {
    describe(name: string, callback: () => void): void;
    it(description: string, testFn: () => void | Promise<void>): void;
    beforeEach(fn: () => void | Promise<void>): void;
    afterEach(fn: () => void | Promise<void>): void;
    beforeAll(fn: () => void | Promise<void>): void;
    afterAll(fn: () => void | Promise<void>): void;
    runTests(): Promise<TestResults>;
    expect(actual: any): TestAssertion;
  }
}

export {};
