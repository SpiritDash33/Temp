// CacheService.test.js - Comprehensive tests for CacheService
describe('CacheService', () => {
    let cacheService;
    let mockEventBus;

    beforeEach(() => {
        // Create mock EventBus
        mockEventBus = {
            subscribe: createMockFunction(),
            unsubscribe: createMockFunction(),
            publish: createMockFunction()
        };

        // Create fresh CacheService instance
        cacheService = new CacheService(mockEventBus, {
            defaultTTL: 1000, // 1 second for testing
            maxSize: 3, // Small size for testing eviction
            cleanupInterval: 100, // Fast cleanup for testing
            enableStats: true
        });
    });

    afterEach(() => {
        // Clean up
        if (cacheService) {
            cacheService.destroy();
        }
    });

    describe('Basic Cache Operations', () => {
        it('should initialize with correct configuration', () => {
            expect(cacheService.config.defaultTTL).toBe(1000);
            expect(cacheService.config.maxSize).toBe(3);
            expect(cacheService.config.cleanupInterval).toBe(100);
            expect(cacheService.config.enableStats).toBe(true);
        });

        it('should set and get values', () => {
            cacheService.set('test-key', 'test-value');
            const result = cacheService.cache.get('test-key');
            expect(result).toBe('test-value');
        });

        it('should check if key exists', () => {
            cacheService.set('test-key', 'test-value');
            expect(cacheService.has('test-key')).toBe(true);
            expect(cacheService.has('nonexistent-key')).toBe(false);
        });

        it('should delete values', () => {
            cacheService.set('test-key', 'test-value');
            expect(cacheService.has('test-key')).toBe(true);
            
            const deleted = cacheService.delete('test-key');
            expect(deleted).toBe(true);
            expect(cacheService.has('test-key')).toBe(false);
        });

        it('should clear all values', () => {
            cacheService.set('key1', 'value1');
            cacheService.set('key2', 'value2');
            
            expect(cacheService.cache.size).toBe(2);
            cacheService.clear();
            expect(cacheService.cache.size).toBe(0);
        });
    });

    describe('TTL (Time To Live) Functionality', () => {
        it('should expire entries after TTL', async () => {
            cacheService.set('test-key', 'test-value', 50); // 50ms TTL
            expect(cacheService.has('test-key')).toBe(true);
            
            // Wait for expiration
            await new Promise(resolve => setTimeout(resolve, 100));
            expect(cacheService.has('test-key')).toBe(false);
        });

        it('should use default TTL when none specified', () => {
            cacheService.set('test-key', 'test-value');
            const metadata = cacheService.metadata.get('test-key');
            
            expect(metadata.expiresAt).toBeGreaterThan(Date.now());
            expect(metadata.expiresAt - metadata.createdAt).toBe(1000); // default TTL
        });

        it('should handle custom TTL correctly', () => {
            const customTTL = 500;
            cacheService.set('test-key', 'test-value', customTTL);
            const metadata = cacheService.metadata.get('test-key');
            
            expect(metadata.expiresAt - metadata.createdAt).toBe(customTTL);
        });
    });

    describe('Cache Eviction', () => {
        it('should evict oldest entry when max size is reached', () => {
            // Fill cache to max capacity
            cacheService.set('key1', 'value1');
            cacheService.set('key2', 'value2');
            cacheService.set('key3', 'value3');
            
            expect(cacheService.cache.size).toBe(3);
            
            // Add one more to trigger eviction
            cacheService.set('key4', 'value4');
            
            expect(cacheService.cache.size).toBe(3);
            expect(cacheService.has('key1')).toBe(false); // Oldest should be evicted
            expect(cacheService.has('key4')).toBe(true); // New one should be present
        });

        it('should track eviction statistics', () => {
            // Fill cache and trigger eviction
            cacheService.set('key1', 'value1');
            cacheService.set('key2', 'value2');
            cacheService.set('key3', 'value3');
            cacheService.set('key4', 'value4'); // This should trigger eviction
            
            const stats = cacheService.getStats();
            expect(stats.evictions).toBe(1);
        });
    });

    describe('Automatic Cleanup', () => {
        it('should clean up expired entries automatically', async () => {
            cacheService.set('short-lived', 'value', 50); // 50ms TTL
            cacheService.set('long-lived', 'value', 5000); // 5s TTL
            
            expect(cacheService.cache.size).toBe(2);
            
            // Wait for cleanup cycle
            await new Promise(resolve => setTimeout(resolve, 200));
            
            expect(cacheService.has('short-lived')).toBe(false);
            expect(cacheService.has('long-lived')).toBe(true);
        });

        it('should track cleanup statistics', async () => {
            cacheService.set('temp-key', 'value', 50);
            
            // Wait for cleanup
            await new Promise(resolve => setTimeout(resolve, 200));
            
            const stats = cacheService.getStats();
            expect(stats.cleanups).toBeGreaterThan(0);
        });
    });

    describe('High-Level Cache Methods', () => {
        it('should handle getCachedJobsForDate', async () => {
            const mockFetchFunction = createMockFunction()
                .mockResolvedValue([{ id: 1, name: 'test job' }]);
            
            const result = await cacheService.getCachedJobsForDate('2025-09-29', mockFetchFunction);
            
            expect(result).toEqual([{ id: 1, name: 'test job' }]);
            expect(mockFetchFunction.calls).toHaveLength(1);
            
            // Second call should use cache
            const result2 = await cacheService.getCachedJobsForDate('2025-09-29', mockFetchFunction);
            expect(result2).toEqual([{ id: 1, name: 'test job' }]);
            expect(mockFetchFunction.calls).toHaveLength(1); // Still only 1 call
        });

        it('should handle getCachedEntriesForDate', async () => {
            const mockFetchFunction = createMockFunction()
                .mockResolvedValue([{ id: 1, date: '2025-09-29' }]);
            
            const result = await cacheService.getCachedEntriesForDate('2025-09-29', mockFetchFunction);
            
            expect(result).toEqual([{ id: 1, date: '2025-09-29' }]);
            expect(mockFetchFunction.calls).toHaveLength(1);
        });

        it('should handle getCachedJob', async () => {
            const mockFetchFunction = createMockFunction()
                .mockResolvedValue({ id: 123, name: 'test job' });
            
            const result = await cacheService.getCachedJob(123, mockFetchFunction);
            
            expect(result).toEqual({ id: 123, name: 'test job' });
            expect(mockFetchFunction.calls).toHaveLength(1);
        });

        it('should handle getCachedSearchResults', async () => {
            const mockFetchFunction = createMockFunction()
                .mockResolvedValue([{ id: 1, match: true }]);
            
            const result = await cacheService.getCachedSearchResults('test query', 'general', mockFetchFunction);
            
            expect(result).toEqual([{ id: 1, match: true }]);
            expect(mockFetchFunction.calls).toHaveLength(1);
        });
    });

    describe('Event-Driven Cache Invalidation', () => {
        it('should set up event listeners during initialization', () => {
            expect(mockEventBus.subscribe.calls).toHaveLength(5);
            expect(mockEventBus.subscribe.calls[0][0]).toBe('job:saved');
            expect(mockEventBus.subscribe.calls[1][0]).toBe('job:deleted');
            expect(mockEventBus.subscribe.calls[2][0]).toBe('job:updated');
            expect(mockEventBus.subscribe.calls[3][0]).toBe('database:reset');
            expect(mockEventBus.subscribe.calls[4][0]).toBe('app:logout');
        });

        it('should invalidate cache on job data change', () => {
            // Set up some cached data
            cacheService.set('jobs:date:2025-09-29', [{ id: 1 }]);
            cacheService.set('entries:date:2025-09-29', [{ id: 1 }]);
            cacheService.set('job:123', { id: 123 });
            cacheService.set('calendar:something', 'data');
            
            // Simulate job data change event
            cacheService.handleJobDataChange({ 
                date: '2025-09-29', 
                jobId: 123 
            });
            
            // Check that relevant caches were invalidated
            expect(cacheService.has('jobs:date:2025-09-29')).toBe(false);
            expect(cacheService.has('entries:date:2025-09-29')).toBe(false);
            expect(cacheService.has('job:123')).toBe(false);
            expect(cacheService.has('calendar:something')).toBe(false);
        });

        it('should clear all cache on database reset', () => {
            cacheService.set('test-key', 'test-value');
            expect(cacheService.cache.size).toBe(1);
            
            // Simulate database reset
            cacheService.clear();
            
            expect(cacheService.cache.size).toBe(0);
        });
    });

    describe('Statistics and Monitoring', () => {
        it('should track hit and miss statistics', async () => {
            const mockFetchFunction = createMockFunction()
                .mockResolvedValue('test-data');
            
            // First call should be a miss
            await cacheService.get('test-key', mockFetchFunction);
            let stats = cacheService.getStats();
            expect(stats.misses).toBe(1);
            expect(stats.hits).toBe(0);
            
            // Second call should be a hit
            await cacheService.get('test-key', mockFetchFunction);
            stats = cacheService.getStats();
            expect(stats.hits).toBe(1);
            expect(stats.misses).toBe(1);
        });

        it('should calculate hit rate correctly', async () => {
            const mockFetchFunction = createMockFunction()
                .mockResolvedValue('test-data');
            
            // 1 miss
            await cacheService.get('test-key', mockFetchFunction);
            // 2 hits
            await cacheService.get('test-key', mockFetchFunction);
            await cacheService.get('test-key', mockFetchFunction);
            
            const stats = cacheService.getStats();
            expect(stats.hitRate).toBe('66.7%'); // 2 hits out of 3 total
        });

        it('should track memory usage estimation', () => {
            cacheService.set('test-key', 'test-value');
            cacheService.set('another-key', { complex: 'object', with: ['arrays'] });
            
            const stats = cacheService.getStats();
            expect(stats.memoryUsage).toBeDefined();
            expect(stats.memoryUsage.estimatedBytes).toBeGreaterThan(0);
            expect(stats.memoryUsage.estimatedKB).toBeDefined();
            expect(stats.memoryUsage.estimatedMB).toBeDefined();
        });
    });

    describe('Health Check', () => {
        it('should report healthy status for normal operation', () => {
            const health = cacheService.healthCheck();
            
            expect(health.healthy).toBe(true);
            expect(health.checks.cacheResponding).toBe(true);
            expect(health.checks.cleanupWorking).toBe(true);
            expect(health.checks.sizeWithinLimits).toBe(true);
        });

        it('should report unhealthy status when hit rate is too low', async () => {
            // Create many misses to lower hit rate
            const mockFetchFunction = createMockFunction()
                .mockResolvedValue('data');
            
            for (let i = 0; i < 20; i++) {
                await cacheService.get(`key-${i}`, mockFetchFunction);
            }
            
            const health = cacheService.healthCheck();
            // Should be healthy since each key was only accessed once (no hits)
            // The hit rate check should fail
            expect(health.checks.hitRateAcceptable).toBe(false);
        });
    });

    describe('Cache Key Builders', () => {
        it('should build correct job keys', () => {
            expect(cacheService.buildJobKey(123)).toBe('job:123');
        });

        it('should build correct date job keys', () => {
            expect(cacheService.buildDateJobsKey('2025-09-29')).toBe('jobs:date:2025-09-29');
        });

        it('should build correct date entries keys', () => {
            expect(cacheService.buildDateEntriesKey('2025-09-29')).toBe('entries:date:2025-09-29');
        });

        it('should build correct search keys', () => {
            const key = cacheService.buildSearchKey('test query', 'general');
            expect(key).toContain('search:general:');
        });

        it('should build correct calendar keys', () => {
            expect(cacheService.buildCalendarKey(2025, 9)).toBe('calendar:2025:9');
        });
    });

    describe('Export and Import', () => {
        it('should export cache data correctly', () => {
            cacheService.set('test-key', 'test-value');
            
            const exportData = cacheService.exportCache();
            
            expect(exportData.cache).toBeDefined();
            expect(exportData.metadata).toBeDefined();
            expect(exportData.stats).toBeDefined();
            expect(exportData.config).toBeDefined();
            expect(exportData.timestamp).toBeDefined();
            expect(exportData.cache['test-key']).toBe('test-value');
        });

        it('should import cache data correctly', () => {
            const exportData = {
                cache: { 'imported-key': 'imported-value' },
                metadata: { 
                    'imported-key': { 
                        createdAt: Date.now() - 1000,
                        expiresAt: Date.now() + 10000,
                        accessCount: 0,
                        lastAccessed: Date.now()
                    }
                }
            };
            
            const importedCount = cacheService.importCache(exportData);
            
            expect(importedCount).toBe(1);
            expect(cacheService.cache.get('imported-key')).toBe('imported-value');
        });

        it('should not import expired entries', () => {
            const exportData = {
                cache: { 'expired-key': 'expired-value' },
                metadata: { 
                    'expired-key': { 
                        createdAt: Date.now() - 10000,
                        expiresAt: Date.now() - 1000, // Already expired
                        accessCount: 0,
                        lastAccessed: Date.now()
                    }
                }
            };
            
            const importedCount = cacheService.importCache(exportData);
            
            expect(importedCount).toBe(0);
            expect(cacheService.has('expired-key')).toBe(false);
        });
    });

    describe('Error Handling', () => {
        it('should handle fetch function errors gracefully', async () => {
            const mockFetchFunction = createMockFunction()
                .mockRejectedValue(new Error('Fetch failed'));
            
            await expect(cacheService.get('test-key', mockFetchFunction)).toReject('Fetch failed');
        });

        it('should handle invalid import data', () => {
            expect(() => {
                cacheService.importCache({ invalid: 'data' });
            }).toThrow('Invalid cache export data');
        });
    });

    describe('Pattern Invalidation', () => {
        it('should invalidate multiple keys matching pattern', () => {
            cacheService.set('jobs:date:2025-09-29', 'data1');
            cacheService.set('jobs:date:2025-09-30', 'data2');
            cacheService.set('entries:date:2025-09-29', 'data3');
            cacheService.set('other:key', 'data4');
            
            cacheService.invalidatePattern('jobs:date:');
            
            expect(cacheService.has('jobs:date:2025-09-29')).toBe(false);
            expect(cacheService.has('jobs:date:2025-09-30')).toBe(false);
            expect(cacheService.has('entries:date:2025-09-29')).toBe(true);
            expect(cacheService.has('other:key')).toBe(true);
        });
    });
});
