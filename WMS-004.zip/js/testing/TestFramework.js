// TestFramework.js - Simple but comprehensive testing framework
class TestFramework {
    constructor() {
        this.tests = [];
        this.results = {
            passed: 0,
            failed: 0,
            total: 0,
            errors: []
        };
        this.currentSuite = null;
        this.beforeEachFn = null;
        this.afterEachFn = null;
        this.beforeAllFn = null;
        this.afterAllFn = null;
    }

    describe(name, callback) {
        const previousSuite = this.currentSuite;
        this.currentSuite = {
            name: name,
            tests: [],
            beforeEach: null,
            afterEach: null,
            beforeAll: null,
            afterAll: null
        };

        // Execute the test suite definition
        callback();

        // Add the suite to tests
        this.tests.push(this.currentSuite);
        this.currentSuite = previousSuite;
    }

    it(description, testFn) {
        if (!this.currentSuite) {
            throw new Error('Tests must be inside a describe block');
        }

        this.currentSuite.tests.push({
            description: description,
            testFn: testFn,
            async: testFn.constructor.name === 'AsyncFunction'
        });
    }

    beforeEach(fn) {
        if (this.currentSuite) {
            this.currentSuite.beforeEach = fn;
        } else {
            this.beforeEachFn = fn;
        }
    }

    afterEach(fn) {
        if (this.currentSuite) {
            this.currentSuite.afterEach = fn;
        } else {
            this.afterEachFn = fn;
        }
    }

    beforeAll(fn) {
        if (this.currentSuite) {
            this.currentSuite.beforeAll = fn;
        } else {
            this.beforeAllFn = fn;
        }
    }

    afterAll(fn) {
        if (this.currentSuite) {
            this.currentSuite.afterAll = fn;
        } else {
            this.afterAllFn = fn;
        }
    }

    async runTests() {
        console.log('🧪 Starting Test Suite');
        console.log('='.repeat(50));

        this.results = {
            passed: 0,
            failed: 0,
            total: 0,
            errors: [],
            startTime: Date.now()
        };

        // Run global beforeAll
        if (this.beforeAllFn) {
            await this.safeExecute(this.beforeAllFn, 'Global beforeAll');
        }

        // Run all test suites
        for (const suite of this.tests) {
            await this.runSuite(suite);
        }

        // Run global afterAll
        if (this.afterAllFn) {
            await this.safeExecute(this.afterAllFn, 'Global afterAll');
        }

        this.results.endTime = Date.now();
        this.results.duration = this.results.endTime - this.results.startTime;

        this.printResults();
        return this.results;
    }

    async runSuite(suite) {
        console.log(`\n📦 ${suite.name}`);
        console.log('-'.repeat(30));

        // Run suite beforeAll
        if (suite.beforeAll) {
            await this.safeExecute(suite.beforeAll, `${suite.name} beforeAll`);
        }

        // Run each test in the suite
        for (const test of suite.tests) {
            await this.runTest(suite, test);
        }

        // Run suite afterAll
        if (suite.afterAll) {
            await this.safeExecute(suite.afterAll, `${suite.name} afterAll`);
        }
    }

    async runTest(suite, test) {
        this.results.total++;
        const testName = `${suite.name} > ${test.description}`;

        try {
            // Run beforeEach hooks
            if (this.beforeEachFn) {
                await this.safeExecute(this.beforeEachFn, 'Global beforeEach');
            }
            if (suite.beforeEach) {
                await this.safeExecute(suite.beforeEach, `${suite.name} beforeEach`);
            }

            // Run the test
            const startTime = Date.now();
            if (test.async) {
                await test.testFn();
            } else {
                test.testFn();
            }
            const duration = Date.now() - startTime;

            this.results.passed++;
            console.log(`  ✅ ${test.description} ${duration}ms`);

            // Run afterEach hooks
            if (suite.afterEach) {
                await this.safeExecute(suite.afterEach, `${suite.name} afterEach`);
            }
            if (this.afterEachFn) {
                await this.safeExecute(this.afterEachFn, 'Global afterEach');
            }

        } catch (error) {
            this.results.failed++;
            this.results.errors.push({
                test: testName,
                error: error.message,
                stack: error.stack
            });
            console.log(`  ❌ ${test.description}`);
            console.log(`     Error: ${error.message}`);
        }
    }

    async safeExecute(fn, context) {
        try {
            if (fn.constructor.name === 'AsyncFunction') {
                await fn();
            } else {
                fn();
            }
        } catch (error) {
            console.warn(`Warning in ${context}: ${error.message}`);
        }
    }

    printResults() {
        console.log('\n' + '='.repeat(50));
        console.log('📊 Test Results');
        console.log('='.repeat(50));
        
        const passRate = this.results.total > 0 ? (this.results.passed / this.results.total * 100).toFixed(1) : 0;
        
        console.log(`Total Tests: ${this.results.total}`);
        console.log(`✅ Passed: ${this.results.passed}`);
        console.log(`❌ Failed: ${this.results.failed}`);
        console.log(`📈 Pass Rate: ${passRate}%`);
        console.log(`⏱️  Duration: ${this.results.duration}ms`);

        if (this.results.errors.length > 0) {
            console.log('\n💥 Failures:');
            this.results.errors.forEach((error, index) => {
                console.log(`\n${index + 1}. ${error.test}`);
                console.log(`   ${error.error}`);
                if (error.stack) {
                    console.log(`   Stack: ${error.stack.split('\n')[1]?.trim()}`);
                }
            });
        }

        console.log('\n' + '='.repeat(50));
    }

    // Assertion methods
    expect(actual) {
        return new TestAssertion(actual);
    }
}

// Assertion class for fluent testing
class TestAssertion {
    constructor(actual) {
        this.actual = actual;
    }

    toBe(expected) {
        if (this.actual !== expected) {
            throw new Error(`Expected ${this.actual} to be ${expected}`);
        }
        return this;
    }

    toEqual(expected) {
        if (JSON.stringify(this.actual) !== JSON.stringify(expected)) {
            throw new Error(`Expected ${JSON.stringify(this.actual)} to equal ${JSON.stringify(expected)}`);
        }
        return this;
    }

    toBeNull() {
        if (this.actual !== null) {
            throw new Error(`Expected ${this.actual} to be null`);
        }
        return this;
    }

    toBeUndefined() {
        if (this.actual !== undefined) {
            throw new Error(`Expected ${this.actual} to be undefined`);
        }
        return this;
    }

    toBeDefined() {
        if (this.actual === undefined) {
            throw new Error(`Expected ${this.actual} to be defined`);
        }
        return this;
    }

    toBeTruthy() {
        if (!this.actual) {
            throw new Error(`Expected ${this.actual} to be truthy`);
        }
        return this;
    }

    toBeFalsy() {
        if (this.actual) {
            throw new Error(`Expected ${this.actual} to be falsy`);
        }
        return this;
    }

    toThrow(expectedError) {
        try {
            if (typeof this.actual === 'function') {
                this.actual();
            }
            throw new Error(`Expected function to throw`);
        } catch (error) {
            if (expectedError && !error.message.includes(expectedError)) {
                throw new Error(`Expected function to throw "${expectedError}" but got "${error.message}"`);
            }
        }
        return this;
    }

    async toResolve() {
        try {
            await this.actual;
        } catch (error) {
            throw new Error(`Expected promise to resolve but it rejected with: ${error.message}`);
        }
        return this;
    }

    async toReject(expectedError) {
        try {
            await this.actual;
            throw new Error(`Expected promise to reject`);
        } catch (error) {
            if (expectedError && !error.message.includes(expectedError)) {
                throw new Error(`Expected promise to reject with "${expectedError}" but got "${error.message}"`);
            }
        }
        return this;
    }

    toBeInstanceOf(expectedClass) {
        if (!(this.actual instanceof expectedClass)) {
            throw new Error(`Expected ${this.actual} to be instance of ${expectedClass.name}`);
        }
        return this;
    }

    toContain(expected) {
        if (Array.isArray(this.actual)) {
            if (!this.actual.includes(expected)) {
                throw new Error(`Expected array ${JSON.stringify(this.actual)} to contain ${expected}`);
            }
        } else if (typeof this.actual === 'string') {
            if (!this.actual.includes(expected)) {
                throw new Error(`Expected string "${this.actual}" to contain "${expected}"`);
            }
        } else {
            throw new Error(`toContain can only be used with arrays or strings`);
        }
        return this;
    }

    toHaveLength(expectedLength) {
        if (!this.actual || !this.actual.length === undefined) {
            throw new Error(`Expected ${this.actual} to have length property`);
        }
        if (this.actual.length !== expectedLength) {
            throw new Error(`Expected length ${this.actual.length} to be ${expectedLength}`);
        }
        return this;
    }

    toBeGreaterThan(expected) {
        if (this.actual <= expected) {
            throw new Error(`Expected ${this.actual} to be greater than ${expected}`);
        }
        return this;
    }

    toBeLessThan(expected) {
        if (this.actual >= expected) {
            throw new Error(`Expected ${this.actual} to be less than ${expected}`);
        }
        return this;
    }

    toBeCloseTo(expected, precision = 2) {
        const diff = Math.abs(this.actual - expected);
        const threshold = Math.pow(10, -precision) / 2;
        if (diff >= threshold) {
            throw new Error(`Expected ${this.actual} to be close to ${expected} within ${precision} decimal places`);
        }
        return this;
    }
}

// Mock utilities
class MockFunction {
    constructor() {
        this.calls = [];
        this.returnValue = undefined;
        this.implementation = null;
    }

    mockReturnValue(value) {
        this.returnValue = value;
        return this;
    }

    mockImplementation(fn) {
        this.implementation = fn;
        return this;
    }

    mockResolvedValue(value) {
        this.implementation = () => Promise.resolve(value);
        return this;
    }

    mockRejectedValue(error) {
        this.implementation = () => Promise.reject(error);
        return this;
    }

    call(...args) {
        this.calls.push(args);
        
        if (this.implementation) {
            return this.implementation(...args);
        }
        
        return this.returnValue;
    }

    // Make the MockFunction callable
    valueOf() {
        return this.call.bind(this);
    }

    toHaveBeenCalled() {
        if (this.calls.length === 0) {
            throw new Error('Expected function to have been called');
        }
    }

    toHaveBeenCalledTimes(times) {
        if (this.calls.length !== times) {
            throw new Error(`Expected function to have been called ${times} times but was called ${this.calls.length} times`);
        }
    }

    toHaveBeenCalledWith(...expectedArgs) {
        const found = this.calls.some(call => 
            call.length === expectedArgs.length &&
            call.every((arg, index) => JSON.stringify(arg) === JSON.stringify(expectedArgs[index]))
        );
        
        if (!found) {
            throw new Error(`Expected function to have been called with ${JSON.stringify(expectedArgs)}`);
        }
    }
}

// Export for use
window.TestFramework = TestFramework;
window.MockFunction = MockFunction;

// Global test functions
window.describe = function(name, callback) {
    if (!window.testRunner) {
        window.testRunner = new TestFramework();
    }
    window.testRunner.describe(name, callback);
};

window.it = function(description, testFn) {
    if (!window.testRunner) {
        throw new Error('it() must be called within describe()');
    }
    window.testRunner.it(description, testFn);
};

window.beforeEach = function(fn) {
    if (!window.testRunner) {
        window.testRunner = new TestFramework();
    }
    window.testRunner.beforeEach(fn);
};

window.afterEach = function(fn) {
    if (!window.testRunner) {
        window.testRunner = new TestFramework();
    }
    window.testRunner.afterEach(fn);
};

window.beforeAll = function(fn) {
    if (!window.testRunner) {
        window.testRunner = new TestFramework();
    }
    window.testRunner.beforeAll(fn);
};

window.afterAll = function(fn) {
    if (!window.testRunner) {
        window.testRunner = new TestFramework();
    }
    window.testRunner.afterAll(fn);
};

window.expect = function(actual) {
    return new TestAssertion(actual);
};

window.createMockFunction = function() {
    return new MockFunction();
};

window.runTests = async function() {
    if (!window.testRunner) {
        console.log('No tests to run');
        return;
    }
    return await window.testRunner.runTests();
};
