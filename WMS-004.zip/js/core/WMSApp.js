// WMSApp.js - Main Application Module with Service Architecture
class WMSApp {
    constructor() {
        this.state = {
            dbManager: null,
            currentJobId: null,
            currentJobEntry: null,
            currentView: 'launch',
            currentTaskType: null,
            focusedDate: new Date().toISOString().split('T')[0],
            jobs: [],
            reorderEnabled: false,
            theme: 'light',
            lastJobSelectionWasSpecific: false // Track if user explicitly selected a job
        };

        this.services = {
            database: null,
            job: null,
            email: null,
            validation: null,
            ui: null,
            error: null,
            cache: null,
            formatting: null
        };

        this.config = {
            requiredFields: [
                'job_name', 'job_start_date', 'job_start_time', 'job_end_time',
                'job_dispatch_type', 'job_field_status', 'job_followup_required',
                'device_id', 'job_trouble_description', 'job_work_description'
            ],
            technicalDetailsTemplates: {
                reader: `[Reader]
Voltage to Reader: - metered at reader
HID or SafeTrust:
Card Reader Info: Type, Spacer?
V3 or V4 module
SafeTrust Info: Firmware & Dr#`,
                door: `[Door]
Fail safe or Fail Secure
Single Door or Double Door
Locking hardware: Schlage cassette or Corbin Russwin Cassette or Von Duprin crash bar
Type of hinge: 4.5" center wire, 5" offset wire or? DC: ¾ or 1", Magnasphere or GRI`,
                lock: `[Lock]
Voltage to lock: - metered at frame side of hinge`,
                rex: `[Rex]
Voltage to REX: - metered at frame side of hinge
REX Resistance: - metered at frame side of hinge and as close/direct to REX. I.E. OL, 16-23Ω Solid`
            }
        };

        this.eventBus = new EventBus();
        this.initialized = false;
    }

    async init() {
        try {
            console.log('🚀 Initializing WMS Application...');
            
            // Initialize error handling first
            this.services.error = new ErrorBoundaryService(this.eventBus);
            
            // Initialize core services
            await this.initializeServices();
            
            // Initialize UI
            await this.initializeUI();
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Load initial data
            await this.loadInitialData();
            
            this.initialized = true;
            console.log('✅ WMS Application initialized successfully');
            
            this.eventBus.publish('app:initialized', { timestamp: new Date() });
            
        } catch (error) {
            console.error('❌ WMS Application initialization failed:', error);
            this.services.error?.handleError(error, 'Application Initialization');
            throw error;
        }
    }

    async initializeServices() {
        // Cache service (initialize early so other services can use it)
        this.services.cache = new CacheService(this.eventBus);
        
        // Database service
        this.services.database = new DatabaseService();
        await this.services.database.init();
        this.state.dbManager = this.services.database.getManager();

        // Job service (pass cache service for performance optimization)
        this.services.job = new JobService(this.services.database, this.eventBus, this.services.cache);
        
        // Email service
        this.services.email = new EmailService(this.services.job, this.eventBus);
        
        // Validation service
        this.services.validation = new ValidationService(this.config.requiredFields, this.eventBus);
        
        // UI service
        this.services.ui = new UIService(this.eventBus);

        // Formatting service (for template-based formatting)
        this.services.formatting = new FormattingService(this.eventBus);

        // Set app reference on UIService so it can access app during initialization
        this.services.ui.setApp(this);

        console.log('✅ Core services initialized');
    }

    async initializeUI() {
        // Initialize theme
        this.services.ui.initializeTheme();
        
        // Set default date
        const dateInput = document.getElementById('job_start_date');
        if (dateInput) {
            dateInput.value = this.state.focusedDate;
        }
        
        console.log('✅ UI initialized');
    }

    setupEventListeners() {
        // Job-related events
        this.eventBus.subscribe('job:saved', this.handleJobSaved.bind(this));
        this.eventBus.subscribe('job:deleted', this.handleJobDeleted.bind(this));
        this.eventBus.subscribe('job:loaded', this.handleJobLoaded.bind(this));
        
        // UI events
        this.eventBus.subscribe('ui:dateChanged', this.handleDateChanged.bind(this));
        this.eventBus.subscribe('ui:viewChanged', this.handleViewChanged.bind(this));
        
        // Email events
        this.eventBus.subscribe('email:imported', this.handleEmailImported.bind(this));
        
        // Error events
        this.eventBus.subscribe('error:occurred', this.handleError.bind(this));
        
        console.log('✅ Event listeners configured');
    }

    async loadInitialData() {
        try {
            await this.services.job.loadJobsForDate(this.state.focusedDate);
            // Force immediate synchronous update on initialization
            await this.services.ui.performUpdate('all');
        } catch (error) {
            console.error('Failed to load initial data:', error);
            throw error;
        }
    }

    // Event Handlers
    async handleJobSaved(data) {
        await this.services.job.loadJobsForDate(this.state.focusedDate);
        this.services.ui.updateAllDisplays();
        this.services.ui.showStatus('Job saved successfully', 'success');
    }

    async handleJobDeleted(data) {
        const wasCurrentJob = this.state.currentJobId === data.jobId;

        if (wasCurrentJob) {
            this.state.currentJobId = null;
            this.state.currentJobEntry = null;
        }

        await this.services.job.loadJobsForDate(this.state.focusedDate);

        // If the deleted job was currently selected, auto-select the first available job
        if (wasCurrentJob && this.state.jobs.length > 0) {
            console.log(`📅 Deleted job was current, auto-selecting first job`);
            await this.autoSelectFirstJobIfNeeded();
        }

        this.services.ui.updateAllDisplays();
        this.services.ui.showStatus('Job deleted successfully', 'success');
    }

    handleJobLoaded(data) {
        this.state.currentJobId = data.job.id;
        this.state.currentJobEntry = data.job;
        this.services.ui.updateAllDisplays();
    }

    async handleDateChanged(data) {
        console.log(`📅 handleDateChanged called for date: ${data.date}`);
        console.log(`📅 Current job selection state:`, {
            currentJobId: this.state.currentJobId,
            lastJobSelectionWasSpecific: this.state.lastJobSelectionWasSpecific
        });

        this.state.focusedDate = data.date;
        await this.services.job.loadJobsForDate(data.date);

        // Auto-select first job if no job is currently selected and this wasn't a specific job selection
        if (!this.state.currentJobId && !this.state.lastJobSelectionWasSpecific && this.state.jobs.length > 0) {
            console.log(`📅 Auto-selecting first job for date ${data.date}`);
            await this.autoSelectFirstJobIfNeeded();
        }

        // Reset the specific selection flag after processing
        this.state.lastJobSelectionWasSpecific = false;

        this.services.ui.updateAllDisplays();
    }

    handleViewChanged(data) {
        this.state.currentView = data.view;
        this.state.currentTaskType = data.taskType;
        this.services.ui.showView(data.view);
    }

    handleEmailImported(data) {
        this.services.ui.showStatus(`Email imported: ${data.fileName}`, 'success');

        // Auto-select the newly imported job if no job is currently selected
        if (data.jobId && !this.state.currentJobId) {
            console.log(`📧 Auto-selecting newly imported job: ${data.jobId}`);
            setTimeout(() => {
                this.loadJobById(data.jobId);
            }, 100); // Small delay to ensure job is saved first
        }
    }

    handleError(data) {
        this.services.ui.showStatus(`Error: ${data.message}`, 'error');
    }

    // Public API methods
    getState() {
        return { ...this.state };
    }

    getService(serviceName) {
        return this.services[serviceName];
    }

    isInitialized() {
        return this.initialized;
    }

    // Calendar job selection method
    async selectCalendarJob(dateStr, jobId) {
        console.log(`📅 selectCalendarJob called: ${dateStr}, jobId: ${jobId}`);

        // Mark that this was a specific job selection to prevent auto-selection
        this.state.lastJobSelectionWasSpecific = true;

        try {
            // First switch to the correct date if different
            if (this.state.focusedDate !== dateStr) {
                console.log(`📅 Switching to date: ${dateStr}`);
                this.state.focusedDate = dateStr;

                // Load jobs for the new date
                await this.services.job.loadJobsForDate(dateStr);

                // Update calendar to show the selected date
                this.services.ui.queueUpdate('calendar');
            }

            // Then load the specific job
            console.log(`📅 Loading job: ${jobId}`);
            await this.loadJobById(jobId);

        } catch (error) {
            console.error('❌ Error in selectCalendarJob:', error);
            this.services.ui.showStatus(`Error loading job: ${error.message}`, 'error');
        }
    }

    // Auto-select first job when appropriate
    async autoSelectFirstJobIfNeeded() {
        if (this.state.jobs.length > 0) {
            const firstJob = this.state.jobs[0];
            console.log(`📅 Auto-selecting first job: ${firstJob.jobName || firstJob.miscName || 'Unnamed'}`);
            await this.loadJobById(firstJob.id);
        }
    }

    // Legacy compatibility - expose commonly used methods
    getCurrentJobData() {
        return this.services.job.getCurrentJobData();
    }

    async saveCurrentJob() {
        return await this.services.job.saveCurrentJob();
    }

    async loadJobById(jobId) {
        return await this.services.job.loadJobById(jobId);
    }

    validateRequiredFields(jobData = null) {
        return this.services.validation.validateRequiredFields(jobData);
    }

    async handleFiles(files) {
        return await this.services.email.handleEmailImport(files);
    }
}

// Event Bus for decoupled communication
class EventBus {
    constructor() {
        this.subscribers = new Map();
    }

    subscribe(event, callback) {
        if (!this.subscribers.has(event)) {
            this.subscribers.set(event, new Set());
        }
        this.subscribers.get(event).add(callback);
        return () => this.unsubscribe(event, callback);
    }

    unsubscribe(event, callback) {
        const callbacks = this.subscribers.get(event);
        if (callbacks) {
            callbacks.delete(callback);
        }
    }

    publish(event, data) {
        const callbacks = this.subscribers.get(event) || new Set();
        callbacks.forEach(callback => {
            try {
                callback(data);
            } catch (error) {
                console.error(`Error in event handler for ${event}:`, error);
            }
        });
    }

    clear() {
        this.subscribers.clear();
    }
}

// Global app instance
let WMSApplication = null;

// Initialize application when DOM is ready
function initializeWMSApp() {
    if (!WMSApplication) {
        WMSApplication = new WMSApp();
        window.WMSApplication = WMSApplication;
        return WMSApplication.init();
    }
    return Promise.resolve();
}

// Export for legacy compatibility
window.initializeWMSApp = initializeWMSApp;
