// CacheService.js - Data caching layer for performance optimization
class CacheService {
    constructor(eventBus, options = {}) {
        this.eventBus = eventBus;
        this.cache = new Map();
        this.metadata = new Map(); // Store TTL and other metadata
        
        // Configuration
        this.config = {
            defaultTTL: options.defaultTTL || 5 * 60 * 1000, // 5 minutes default
            maxSize: options.maxSize || 1000, // Maximum cache entries
            cleanupInterval: options.cleanupInterval || 60 * 1000, // 1 minute
            enableStats: options.enableStats !== false
        };

        // Statistics
        this.stats = {
            hits: 0,
            misses: 0,
            sets: 0,
            deletes: 0,
            evictions: 0,
            cleanups: 0
        };

        // Initialize cleanup timer
        this.cleanupTimer = null;
        this.startCleanupTimer();

        // Set up event listeners for cache invalidation
        this.setupEventListeners();

        console.log('✅ Cache Service initialized with config:', this.config);
    }

    setupEventListeners() {
        // Invalidate relevant caches when data changes
        this.eventBus.subscribe('job:saved', this.handleJobDataChange.bind(this));
        this.eventBus.subscribe('job:deleted', this.handleJobDataChange.bind(this));
        this.eventBus.subscribe('job:updated', this.handleJobDataChange.bind(this));
        
        // Clear all cache on major events
        this.eventBus.subscribe('database:reset', this.clear.bind(this));
        this.eventBus.subscribe('app:logout', this.clear.bind(this));
    }

    handleJobDataChange(data) {
        // Invalidate date-specific caches
        if (data.date) {
            this.invalidatePattern(`jobs:date:${data.date}`);
            this.invalidatePattern(`entries:date:${data.date}`);
        }
        
        // Invalidate job-specific caches
        if (data.jobId) {
            this.delete(`job:${data.jobId}`);
        }

        // Invalidate calendar-related caches
        this.invalidatePattern('calendar:');
        
        console.log('Cache invalidated for job data change:', data);
    }

    // Main cache operations
    async get(key, fetchFunction, ttl = null) {
        const cacheEntry = this.cache.get(key);
        const metadata = this.metadata.get(key);

        // Check if entry exists and is not expired
        if (cacheEntry && metadata && !this.isExpired(metadata)) {
            this.stats.hits++;
            console.log(`Cache HIT: ${key}`);
            return cacheEntry;
        }

        // Cache miss - fetch data
        this.stats.misses++;
        console.log(`Cache MISS: ${key}`);

        try {
            const data = await fetchFunction();
            this.set(key, data, ttl);
            return data;
        } catch (error) {
            console.error(`Cache fetch failed for ${key}:`, error);
            throw error;
        }
    }

    set(key, value, ttl = null) {
        // Check cache size and evict if necessary
        if (this.cache.size >= this.config.maxSize) {
            this.evictOldest();
        }

        const now = Date.now();
        const expirationTime = now + (ttl || this.config.defaultTTL);

        this.cache.set(key, value);
        this.metadata.set(key, {
            createdAt: now,
            expiresAt: expirationTime,
            accessCount: 0,
            lastAccessed: now
        });

        this.stats.sets++;
        console.log(`Cache SET: ${key} (expires at ${new Date(expirationTime).toISOString()})`);
    }

    delete(key) {
        const deleted = this.cache.delete(key) && this.metadata.delete(key);
        if (deleted) {
            this.stats.deletes++;
            console.log(`Cache DELETE: ${key}`);
        }
        return deleted;
    }

    has(key) {
        const metadata = this.metadata.get(key);
        return this.cache.has(key) && metadata && !this.isExpired(metadata);
    }

    clear() {
        const size = this.cache.size;
        this.cache.clear();
        this.metadata.clear();
        console.log(`Cache cleared: ${size} entries removed`);
    }

    // Utility methods
    isExpired(metadata) {
        return Date.now() > metadata.expiresAt;
    }

    evictOldest() {
        let oldestKey = null;
        let oldestTime = Date.now();

        for (const [key, metadata] of this.metadata) {
            if (metadata.lastAccessed < oldestTime) {
                oldestTime = metadata.lastAccessed;
                oldestKey = key;
            }
        }

        if (oldestKey) {
            this.delete(oldestKey);
            this.stats.evictions++;
            console.log(`Cache evicted oldest entry: ${oldestKey}`);
        }
    }

    invalidatePattern(pattern) {
        const keysToDelete = [];
        
        for (const key of this.cache.keys()) {
            if (key.includes(pattern)) {
                keysToDelete.push(key);
            }
        }

        keysToDelete.forEach(key => this.delete(key));
        
        if (keysToDelete.length > 0) {
            console.log(`Cache invalidated ${keysToDelete.length} entries matching pattern: ${pattern}`);
        }
    }

    cleanup() {
        const now = Date.now();
        const expiredKeys = [];

        for (const [key, metadata] of this.metadata) {
            if (this.isExpired(metadata)) {
                expiredKeys.push(key);
            }
        }

        expiredKeys.forEach(key => {
            this.cache.delete(key);
            this.metadata.delete(key);
        });

        if (expiredKeys.length > 0) {
            this.stats.cleanups++;
            console.log(`Cache cleanup: ${expiredKeys.length} expired entries removed`);
        }

        return expiredKeys.length;
    }

    startCleanupTimer() {
        if (this.cleanupTimer) {
            clearInterval(this.cleanupTimer);
        }

        this.cleanupTimer = setInterval(() => {
            this.cleanup();
        }, this.config.cleanupInterval);
    }

    stopCleanupTimer() {
        if (this.cleanupTimer) {
            clearInterval(this.cleanupTimer);
            this.cleanupTimer = null;
        }
    }

    // Statistics and monitoring
    getStats() {
        const hitRate = this.stats.hits + this.stats.misses > 0 
            ? (this.stats.hits / (this.stats.hits + this.stats.misses) * 100).toFixed(2)
            : 0;

        return {
            ...this.stats,
            hitRate: `${hitRate}%`,
            cacheSize: this.cache.size,
            memoryUsage: this.getMemoryUsage()
        };
    }

    getMemoryUsage() {
        // Rough estimate of memory usage
        let totalSize = 0;
        
        for (const [key, value] of this.cache) {
            totalSize += this.estimateSize(key) + this.estimateSize(value);
        }

        return {
            estimatedBytes: totalSize,
            estimatedKB: (totalSize / 1024).toFixed(2),
            estimatedMB: (totalSize / 1024 / 1024).toFixed(2)
        };
    }

    estimateSize(obj) {
        if (typeof obj === 'string') {
            return obj.length * 2; // UTF-16
        } else if (typeof obj === 'number') {
            return 8;
        } else if (typeof obj === 'boolean') {
            return 4;
        } else if (obj === null || obj === undefined) {
            return 0;
        } else if (Array.isArray(obj)) {
            return obj.reduce((sum, item) => sum + this.estimateSize(item), 0);
        } else if (typeof obj === 'object') {
            return Object.entries(obj).reduce((sum, [key, value]) => 
                sum + this.estimateSize(key) + this.estimateSize(value), 0);
        }
        return 100; // Default estimate for complex objects
    }

    // Cache key builders for common patterns
    buildJobKey(jobId) {
        return `job:${jobId}`;
    }

    buildDateJobsKey(date) {
        return `jobs:date:${date}`;
    }

    buildDateEntriesKey(date) {
        return `entries:date:${date}`;
    }

    buildSearchKey(query, type = 'general') {
        // Create a hash-like key for search queries
        const searchHash = btoa(JSON.stringify({ query, type })).replace(/[^a-zA-Z0-9]/g, '');
        return `search:${type}:${searchHash}`;
    }

    buildCalendarKey(year, month) {
        return `calendar:${year}:${month}`;
    }

    // High-level caching methods for common operations
    async getCachedJobsForDate(date, fetchFunction) {
        const key = this.buildDateJobsKey(date);
        return this.get(key, fetchFunction, 3 * 60 * 1000); // 3 minutes TTL for job lists
    }

    async getCachedEntriesForDate(date, fetchFunction) {
        const key = this.buildDateEntriesKey(date);
        return this.get(key, fetchFunction, 5 * 60 * 1000); // 5 minutes TTL for entries
    }

    async getCachedJob(jobId, fetchFunction) {
        const key = this.buildJobKey(jobId);
        return this.get(key, fetchFunction, 10 * 60 * 1000); // 10 minutes TTL for individual jobs
    }

    async getCachedSearchResults(query, type, fetchFunction) {
        const key = this.buildSearchKey(query, type);
        return this.get(key, fetchFunction, 2 * 60 * 1000); // 2 minutes TTL for search results
    }

    async getCachedCalendarData(year, month, fetchFunction) {
        const key = this.buildCalendarKey(year, month);
        return this.get(key, fetchFunction, 5 * 60 * 1000); // 5 minutes TTL for calendar data
    }

    // Development and debugging helpers
    exportCache() {
        const cacheData = {};
        const metadataData = {};

        for (const [key, value] of this.cache) {
            cacheData[key] = value;
        }

        for (const [key, metadata] of this.metadata) {
            metadataData[key] = metadata;
        }

        return {
            cache: cacheData,
            metadata: metadataData,
            stats: this.getStats(),
            config: this.config,
            timestamp: new Date().toISOString()
        };
    }

    importCache(exportedData) {
        if (!exportedData.cache || !exportedData.metadata) {
            throw new Error('Invalid cache export data');
        }

        this.clear();

        // Import non-expired entries only
        const now = Date.now();
        let importedCount = 0;

        for (const [key, value] of Object.entries(exportedData.cache)) {
            const metadata = exportedData.metadata[key];
            if (metadata && now < metadata.expiresAt) {
                this.cache.set(key, value);
                this.metadata.set(key, metadata);
                importedCount++;
            }
        }

        console.log(`Cache import completed: ${importedCount} entries imported`);
        return importedCount;
    }

    // Health check
    healthCheck() {
        const stats = this.getStats();
        const isHealthy = {
            cacheResponding: true,
            cleanupWorking: this.cleanupTimer !== null,
            hitRateAcceptable: parseFloat(stats.hitRate) > 10, // At least 10% hit rate
            sizeWithinLimits: this.cache.size < this.config.maxSize,
            memoryReasonable: parseFloat(stats.memoryUsage.estimatedMB) < 50 // Less than 50MB
        };

        const overall = Object.values(isHealthy).every(health => health === true);

        return {
            healthy: overall,
            checks: isHealthy,
            stats: stats,
            timestamp: new Date().toISOString()
        };
    }

    // Destructor
    destroy() {
        this.stopCleanupTimer();
        this.clear();
        
        // Remove event listeners
        this.eventBus.unsubscribe('job:saved', this.handleJobDataChange);
        this.eventBus.unsubscribe('job:deleted', this.handleJobDataChange);
        this.eventBus.unsubscribe('job:updated', this.handleJobDataChange);
        this.eventBus.unsubscribe('database:reset', this.clear);
        this.eventBus.unsubscribe('app:logout', this.clear);
        
        console.log('Cache Service destroyed');
    }
}
