// ErrorBoundaryService.js - Error handling and recovery
class ErrorBoundaryService {
    constructor(eventBus) {
        this.eventBus = eventBus;
        this.errorLog = [];
        this.maxLogEntries = 100;
        this.initialized = false;
        
        this.init();
    }

    init() {
        // Set up global error handlers
        this.setupGlobalErrorHandlers();
        
        // Set up unhandled promise rejection handler
        this.setupPromiseRejectionHandler();
        
        this.initialized = true;
        console.log('✅ Error Boundary Service initialized');
    }

    setupGlobalErrorHandlers() {
        // Global JavaScript errors
        window.addEventListener('error', (event) => {
            this.handleGlobalError({
                message: event.message,
                filename: event.filename,
                lineno: event.lineno,
                colno: event.colno,
                error: event.error,
                type: 'javascript'
            });
        });

        // Global unhandled promise rejections
        window.addEventListener('unhandledrejection', (event) => {
            this.handlePromiseRejection(event.reason, event.promise);
        });
    }

    setupPromiseRejectionHandler() {
        // Enhanced promise rejection handling
        const originalConsoleError = console.error;
        console.error = (...args) => {
            // Check if this looks like an unhandled promise rejection
            if (args[0] && typeof args[0] === 'string' && args[0].includes('Unhandled')) {
                this.handlePromiseRejection(args[1] || args[0]);
            }
            originalConsoleError.apply(console, args);
        };
    }

    handleGlobalError(errorInfo) {
        const errorEntry = {
            id: Date.now() + Math.random(),
            timestamp: new Date().toISOString(),
            type: errorInfo.type || 'javascript',
            message: errorInfo.message || 'Unknown error',
            filename: errorInfo.filename || 'unknown',
            lineno: errorInfo.lineno || 0,
            colno: errorInfo.colno || 0,
            stack: errorInfo.error?.stack || 'No stack trace available',
            userAgent: navigator.userAgent,
            url: window.location.href,
            severity: this.determineSeverity(errorInfo)
        };

        this.logError(errorEntry);
        
        // Only show user-facing errors for critical issues
        if (errorEntry.severity === 'critical') {
            this.showUserError(errorEntry);
        }

        // Publish error event
        this.eventBus.publish('error:global', errorEntry);
    }

    handlePromiseRejection(reason, promise = null) {
        const errorEntry = {
            id: Date.now() + Math.random(),
            timestamp: new Date().toISOString(),
            type: 'promise_rejection',
            message: reason?.message || reason || 'Unhandled promise rejection',
            stack: reason?.stack || 'No stack trace available',
            userAgent: navigator.userAgent,
            url: window.location.href,
            severity: 'high'
        };

        this.logError(errorEntry);
        
        // Show user error for promise rejections as they often indicate real issues
        this.showUserError(errorEntry);

        // Publish error event
        this.eventBus.publish('error:promise', errorEntry);
    }

    // Main error handling method for application errors
    handleError(error, context = 'Unknown', options = {}) {
        const errorEntry = {
            id: Date.now() + Math.random(),
            timestamp: new Date().toISOString(),
            type: 'application',
            context: context,
            message: error?.message || error || 'Unknown application error',
            stack: error?.stack || 'No stack trace available',
            userAgent: navigator.userAgent,
            url: window.location.href,
            severity: options.severity || this.determineSeverity(error),
            operation: options.operation || context,
            userVisible: options.userVisible !== false
        };

        this.logError(errorEntry);

        // Show user error if specified
        if (errorEntry.userVisible && errorEntry.severity !== 'low') {
            this.showUserError(errorEntry);
        }

        // Publish error event
        this.eventBus.publish('error:application', errorEntry);

        // Attempt recovery if recovery function provided
        if (options.recoveryFn) {
            this.attemptRecovery(errorEntry, options.recoveryFn);
        }

        return errorEntry;
    }

    determineSeverity(error) {
        const message = error?.message || error || '';
        const lowerMessage = message.toLowerCase();

        // Critical errors
        if (lowerMessage.includes('database') && lowerMessage.includes('failed')) {
            return 'critical';
        }
        if (lowerMessage.includes('initialization') && lowerMessage.includes('failed')) {
            return 'critical';
        }

        // High severity errors
        if (lowerMessage.includes('save') || lowerMessage.includes('load')) {
            return 'high';
        }
        if (lowerMessage.includes('import') || lowerMessage.includes('export')) {
            return 'high';
        }

        // Medium severity errors
        if (lowerMessage.includes('validation') || lowerMessage.includes('missing')) {
            return 'medium';
        }
        if (lowerMessage.includes('parse') || lowerMessage.includes('format')) {
            return 'medium';
        }

        // Default to medium
        return 'medium';
    }

    logError(errorEntry) {
        // Add to internal log
        this.errorLog.unshift(errorEntry);
        
        // Maintain max log size
        if (this.errorLog.length > this.maxLogEntries) {
            this.errorLog = this.errorLog.slice(0, this.maxLogEntries);
        }

        // Console logging with appropriate level
        switch (errorEntry.severity) {
            case 'critical':
                console.error('🚨 CRITICAL ERROR:', errorEntry);
                break;
            case 'high':
                console.error('❌ ERROR:', errorEntry);
                break;
            case 'medium':
                console.warn('⚠️ WARNING:', errorEntry);
                break;
            case 'low':
                console.info('ℹ️ INFO:', errorEntry);
                break;
            default:
                console.log('📝 LOG:', errorEntry);
        }

        // Store in localStorage for debugging (keep last 20)
        try {
            const storedErrors = JSON.parse(localStorage.getItem('wms_error_log') || '[]');
            storedErrors.unshift(errorEntry);
            const trimmed = storedErrors.slice(0, 20);
            localStorage.setItem('wms_error_log', JSON.stringify(trimmed));
        } catch (e) {
            // Ignore localStorage errors
        }
    }

    showUserError(errorEntry) {
        // Get UI service to show user-friendly error
        const app = window.WMSApplication;
        const uiService = app?.getService('ui');
        
        if (uiService) {
            const userMessage = this.getUserFriendlyMessage(errorEntry);
            uiService.showStatus(userMessage, 'error', 8000);
        } else {
            // Fallback to alert for critical errors
            if (errorEntry.severity === 'critical') {
                alert(`Critical Error: ${this.getUserFriendlyMessage(errorEntry)}`);
            }
        }
    }

    getUserFriendlyMessage(errorEntry) {
        const context = errorEntry.context || errorEntry.operation || 'operation';
        
        switch (errorEntry.severity) {
            case 'critical':
                return `System Error: The application encountered a critical error during ${context}. Please refresh the page and try again.`;
            case 'high':
                return `Error: Failed to complete ${context}. Please check your data and try again.`;
            case 'medium':
                return `Warning: Issue detected during ${context}. The operation may not have completed successfully.`;
            case 'low':
                return `Notice: Minor issue during ${context}.`;
            default:
                return `An unexpected error occurred during ${context}.`;
        }
    }

    attemptRecovery(errorEntry, recoveryFn) {
        try {
            console.log(`Attempting recovery for error: ${errorEntry.id}`);
            recoveryFn(errorEntry);
            
            // Log successful recovery
            this.logError({
                ...errorEntry,
                id: Date.now() + Math.random(),
                type: 'recovery_success',
                message: `Recovery successful for: ${errorEntry.message}`,
                severity: 'low'
            });
            
        } catch (recoveryError) {
            // Log recovery failure
            this.logError({
                ...errorEntry,
                id: Date.now() + Math.random(),
                type: 'recovery_failed',
                message: `Recovery failed for: ${errorEntry.message}. Recovery error: ${recoveryError.message}`,
                severity: 'high'
            });
        }
    }

    // Utility methods for wrapping operations with error handling
    static async wrap(operation, context = 'Unknown Operation', options = {}) {
        const app = window.WMSApplication;
        const errorService = app?.getService('error');
        
        try {
            return await operation();
        } catch (error) {
            if (errorService) {
                errorService.handleError(error, context, options);
            } else {
                console.error(`Error in ${context}:`, error);
            }
            
            // Re-throw unless options.suppressRethrow is true
            if (!options.suppressRethrow) {
                throw error;
            }
        }
    }

    // Get error statistics
    getErrorStats() {
        const stats = {
            total: this.errorLog.length,
            critical: 0,
            high: 0,
            medium: 0,
            low: 0,
            byType: {},
            recent: this.errorLog.slice(0, 5)
        };

        this.errorLog.forEach(error => {
            // Count by severity
            stats[error.severity] = (stats[error.severity] || 0) + 1;
            
            // Count by type
            stats.byType[error.type] = (stats.byType[error.type] || 0) + 1;
        });

        return stats;
    }

    // Export error log
    exportErrorLog() {
        const stats = this.getErrorStats();
        const exportData = {
            timestamp: new Date().toISOString(),
            stats: stats,
            errors: this.errorLog,
            system: {
                userAgent: navigator.userAgent,
                url: window.location.href,
                localStorage: this.getLocalStorageInfo()
            }
        };

        return exportData;
    }

    getLocalStorageInfo() {
        try {
            const info = {
                available: true,
                keys: Object.keys(localStorage),
                size: JSON.stringify(localStorage).length
            };
            return info;
        } catch (e) {
            return { available: false, error: e.message };
        }
    }

    // Clear error log
    clearErrorLog() {
        this.errorLog = [];
        localStorage.removeItem('wms_error_log');
        console.log('Error log cleared');
    }

    // Recovery strategies
    getRecoveryStrategies() {
        return {
            // Database recovery
            databaseError: () => {
                console.log('Attempting database recovery...');
                const app = window.WMSApplication;
                const dbService = app?.getService('database');
                if (dbService && !dbService.isInitialized()) {
                    return dbService.init();
                }
            },
            
            // Form recovery
            formError: () => {
                console.log('Attempting form recovery...');
                // Clear validation errors
                document.querySelectorAll('.required-empty').forEach(el => {
                    el.classList.remove('required-empty');
                });
            },
            
            // UI recovery
            uiError: () => {
                console.log('Attempting UI recovery...');
                const app = window.WMSApplication;
                const uiService = app?.getService('ui');
                if (uiService) {
                    uiService.updateAllDisplays();
                }
            }
        };
    }

    // Development helpers
    isDevelopment() {
        return window.location.hostname === 'localhost' || 
               window.location.hostname === '127.0.0.1' ||
               window.location.protocol === 'file:';
    }

    // Show error debug info in development
    showDebugInfo(errorEntry) {
        if (this.isDevelopment()) {
            console.group(`🐛 Debug Info for Error ${errorEntry.id}`);
            console.log('Error Entry:', errorEntry);
            console.log('Application State:', window.WMSApplication?.getState());
            console.log('Error Stats:', this.getErrorStats());
            console.groupEnd();
        }
    }
}
