// FormattingService.js - Template-based formatting infrastructure
// Maintains current behavior while providing template foundation

class FormattingService {
    constructor(eventBus) {
        this.eventBus = eventBus;
        // Use the DataMappingEngine from the core services
        if (typeof DataMappingEngine === 'undefined') {
            console.error('❌ DataMappingEngine not available - ensure DataMappingService.js is loaded first');
        }
        this.templates = this.initializeTemplates();
        this.fieldMappings = this.initializeFieldMappings();
    }

    // Initialize templates that match current hardcoded behavior exactly
    initializeTemplates() {
        return {
            // Daily Tasks (Culled) view - matches current UIService.js output exactly
            dailyTasksView: {
                template: `<div class="{{className}}">
<strong>Job: {{job_name}}</strong><br>
Number: {{job_number}}<br>
Date: {{job_start_date}} | {{job_start_time}} - {{job_end_time}}<br>
Status: {{job_field_status}}<br>
Device: {{device_id}} ({{device_type}})<br>
{{#if job_trouble_description}}Problem: {{job_trouble_description}}<br>{{/if}}
{{#if job_work_description}}Work: {{job_work_description}}<br>{{/if}}
</div>`,
                transformations: {
                    job_name: (value, jobData) => jobData.jobName || jobData.miscName || 'Unnamed Job',
                    job_number: (value, jobData) => jobData.jobNumber || jobData.ticketNumber || 'N/A',
                    job_start_date: (value, jobData) => jobData.jobStartDate || jobData.miscStartDate || 'N/A',
                    job_start_time: (value, jobData) => jobData.jobStartTime || jobData.miscStartTime || 'N/A',
                    job_end_time: (value, jobData) => jobData.jobEndTime || 'N/A',
                    job_field_status: (value, jobData) => jobData.jobFieldStatus || 'N/A',
                    device_id: (value, jobData) => jobData.jobDeviceNames || 'N/A',
                    device_type: (value, jobData) => jobData.deviceType || 'N/A',
                    job_trouble_description: (value, jobData) => jobData.jobTroubleDescription || '',
                    job_work_description: (value, jobData) => jobData.jobWorkDescription || ''
                }
            },

            // Clipboard format - matches TicketCopyPaste_Template.txt exactly
            clipboard: {
                template: `Job Name: {{jobName}}
Job Number: {{jobNumber}} Building: {{buildingCode}}
Address: {{buildingAddress}}

REF#: {{jobReferenceNumber}}
Escort Delay: {{jobEscortDelay}}
Start: {{jobStartTime}}
End: {{jobEndTime}}
With: {{jobParticipants}}
 
Material Used: {{jobMaterialsUsed}}
Material Needed: {{jobMaterialsNeeded}}
 
Hinderance: {{jobHindrances}}
Access Needed: {{jobAccessNeeded}}
Programming Changes: {{jobProgrammingChanges}}
 
Dispatched: {{jobDispatchType}}
Field Status: {{jobFieldStatus}}
Status Notes: {{jobFiledStatusNotes}}
 
Device Name: {{jobDeviceNames}}
Problem Description: {{jobTroubleDescription}}
Alarm Type: {{jobTroubleType}}
Device Details: {{jobDeviceDetails}}
 
Previous Associated Tickets: {{relatedTickets}}
 
Work Description: {{jobWorkDescription}}
 
Technical Details: {{jobTechnicalDetails}}`,
                transformations: {
                    jobName: (value, jobData) => jobData.jobName || jobData.miscName || '',
                    jobNumber: (value, jobData) => jobData.jobNumber || jobData.ticketNumber || '',
                    buildingCode: (value, jobData) => jobData.buildingCode || '',
                    buildingAddress: (value, jobData) => jobData.buildingAddress || '',
                    jobReferenceNumber: (value, jobData) => jobData.jobReferenceNumber || '',
                    jobEscortDelay: (value, jobData) => jobData.jobEscortDelay || '',
                    jobStartTime: (value, jobData) => jobData.jobStartTime || '',
                    jobEndTime: (value, jobData) => jobData.jobEndTime || '',
                    jobParticipants: (value, jobData) => jobData.jobParticipants || '',
                    jobMaterialsUsed: (value, jobData) => jobData.jobMaterialsUsed || '',
                    jobMaterialsNeeded: (value, jobData) => jobData.jobMaterialsNeeded || '',
                    jobHindrances: (value, jobData) => jobData.jobHindrances || '',
                    jobAccessNeeded: (value, jobData) => jobData.jobAccessNeeded || '',
                    jobProgrammingChanges: (value, jobData) => jobData.jobProgrammingChanges || '',
                    jobDispatchType: (value, jobData) => jobData.jobDispatchType || '',
                    jobFieldStatus: (value, jobData) => jobData.jobFieldStatus || '',
                    jobFiledStatusNotes: (value, jobData) => jobData.jobFiledStatusNotes || '',
                    jobDeviceNames: (value, jobData) => jobData.jobDeviceNames || '',
                    jobTroubleDescription: (value, jobData) => jobData.jobTroubleDescription || '',
                    jobTroubleType: (value, jobData) => jobData.jobTroubleType || '',
                    jobDeviceDetails: (value, jobData) => jobData.jobDeviceDetails || '',
                    relatedTickets: (value, jobData) => jobData.relatedTickets || '',
                    jobWorkDescription: (value, jobData) => jobData.jobWorkDescription || '',
                    jobTechnicalDetails: (value, jobData) => jobData.jobTechnicalDetails || ''
                }
            },

            // Summary format - matches current formatJobData() summary case exactly
            summary: {
                template: `Job: {{job_name}}
Number: {{job_number}}
Date: {{job_start_date}}
Status: {{job_field_status}}
Device: {{device_id}}
Problem: {{job_trouble_description}}
Work: {{job_work_description}}`,
                transformations: {
                    job_name: (value, jobData) => jobData.jobName || jobData.miscName || 'Unnamed',
                    job_number: (value, jobData) => jobData.jobNumber || 'N/A',
                    job_start_date: (value, jobData) => jobData.jobStartDate || jobData.miscStartDate || 'N/A',
                    job_field_status: (value, jobData) => jobData.jobFieldStatus || 'N/A',
                    device_id: (value, jobData) => jobData.jobDeviceNames || 'N/A',
                    job_trouble_description: (value, jobData) => jobData.jobTroubleDescription || 'N/A',
                    job_work_description: (value, jobData) => jobData.jobWorkDescription || 'N/A'
                }
            }
        };
    }

    // Field mappings between database, form, and display names
    initializeFieldMappings() {
        return {
            // Database field → Form field → Display name mappings
            jobName: {
                database: ['jobName', 'miscName'],
                form: ['job_name', 'general_name'],
                display: 'Job Name'
            },
            jobNumber: {
                database: ['jobNumber', 'ticketNumber'],
                form: ['job_number'],
                display: 'Job Number'
            },
            buildingCode: {
                database: ['buildingCode'],
                form: ['building_code'],
                display: 'Building'
            },
            buildingAddress: {
                database: ['buildingAddress'],
                form: ['building_address'],
                display: 'Address'
            },
            deviceId: {
                database: ['jobDeviceNames'],
                form: ['device_id'],
                display: 'Device Name'
            },
            deviceType: {
                database: ['deviceType'],
                form: ['device_type'],
                display: 'Device Type'
            },
            jobStartDate: {
                database: ['jobStartDate', 'miscStartDate'],
                form: ['job_start_date', 'general_start_date'],
                display: 'Start Date'
            },
            jobStartTime: {
                database: ['jobStartTime', 'miscStartTime'],
                form: ['job_start_time', 'general_start_time'],
                display: 'Start Time'
            },
            jobEndTime: {
                database: ['jobEndTime'],
                form: ['job_end_time'],
                display: 'End Time'
            },
            jobParticipants: {
                database: ['jobParticipants'],
                form: ['job_participants'],
                display: 'Participants'
            },
            jobDispatchType: {
                database: ['jobDispatchType'],
                form: ['job_dispatch_type'],
                display: 'Dispatched'
            },
            jobFieldStatus: {
                database: ['jobFieldStatus'],
                form: ['job_field_status'],
                display: 'Field Status'
            },
            jobFollowupRequired: {
                database: ['jobFollowupRequired'],
                form: ['job_followup_required'],
                display: 'Follow-Up Required'
            },
            jobFiledStatusNotes: {
                database: ['jobFiledStatusNotes'],
                form: ['job_filed_status_notes'],
                display: 'Status Notes'
            },
            jobMaterialsUsed: {
                database: ['jobMaterialsUsed'],
                form: ['job_materials_used'],
                display: 'Material Used'
            },
            jobMaterialsNeeded: {
                database: ['jobMaterialsNeeded'],
                form: ['job_materials_needed'],
                display: 'Material Needed'
            },
            jobReferenceNumber: {
                database: ['jobReferenceNumber'],
                form: ['job_reference_number'],
                display: 'Ref#'
            },
            jobEscortDelay: {
                database: ['jobEscortDelay'],
                form: ['job_escort_delay'],
                display: 'Escort Delay'
            },
            jobHindrances: {
                database: ['jobHindrances'],
                form: ['job_hindrances'],
                display: 'Hinderance'
            },
            jobAccessNeeded: {
                database: ['jobAccessNeeded'],
                form: ['job_access_needed'],
                display: 'Access Needed'
            },
            jobProgrammingChanges: {
                database: ['jobProgrammingChanges'],
                form: ['job_programming_changes'],
                display: 'Programming Changes'
            },
            jobDeviceDetails: {
                database: ['jobDeviceDetails'],
                form: ['job_device_details'],
                display: 'Device Details'
            },
            jobTroubleType: {
                database: ['jobTroubleType'],
                form: ['job_trouble_type'],
                display: 'Trouble Type'
            },
            jobTroubleDescription: {
                database: ['jobTroubleDescription'],
                form: ['job_trouble_description'],
                display: 'Problem Description'
            },
            jobWorkDescription: {
                database: ['jobWorkDescription'],
                form: ['job_work_description'],
                display: 'Work Description'
            },
            jobTechnicalDetails: {
                database: ['jobTechnicalDetails'],
                form: ['job_technical_details'],
                display: 'Technical Details'
            },
            relatedTickets: {
                database: ['relatedTickets'],
                form: ['related_tickets'],
                display: 'Related Tickets'
            }
        };
    }

    // Format job data using template - maintains current behavior exactly
    formatJobData(jobData, formatType) {
        const template = this.templates[formatType];
        if (!template) {
            throw new Error(`Unknown format type: ${formatType}`);
        }

        // Use the existing mapping engine for consistency
        if (typeof DataMappingEngine !== 'undefined') {
            return DataMappingEngine.applyTemplate(template.template, jobData, template.transformations);
        } else {
            // Fallback to simple template replacement if DataMappingEngine not available
            return this.simpleTemplateReplace(template.template, jobData, template.transformations);
        }
    }

    // Simple template replacement fallback
    simpleTemplateReplace(template, jobData, transformations = {}) {
        let result = template;

        // Apply transformations - create transformed values for all fields
        const transformedData = { ...jobData };
        for (const [field, transformFn] of Object.entries(transformations)) {
            // Apply transformation function to get the value
            transformedData[field] = transformFn(jobData[field], jobData);
        }

        // Replace template variables
        const variableRegex = /\{\{(\w+)\}\}/g;
        result = result.replace(variableRegex, (match, fieldName) => {
            return transformedData[fieldName] || '';
        });

        return result;
    }

    // Format multiple jobs for Daily Tasks view - matches current UIService.js output exactly
    formatDailyTasksView(jobs, validationService = null) {
        if (!jobs || jobs.length === 0) {
            return '<p>No jobs for this date.</p>';
        }

        let html = '';
        jobs.forEach(job => {
            const missingFields = validationService ? validationService.validateRequiredFields(job) : [];
            const hasRequired = missingFields.length === 0;
            const isCurrent = window.WMSApplication?.state.currentJobId === job.id;

            let className = 'daily-job-box';
            if (!hasRequired) className += ' missing-required';
            if (isCurrent) className += ' current-job';

            // Apply template with job data
            const jobHtml = this.formatJobData({
                ...job,
                className: className
            }, 'dailyTasksView');

            html += jobHtml;
        });

        return html;
    }

    // Get field mapping information
    getFieldMapping(fieldName) {
        return this.fieldMappings[fieldName] || null;
    }

    // Get all available templates
    getAvailableTemplates() {
        return Object.keys(this.templates);
    }

    // Get template configuration
    getTemplateConfig(templateName) {
        return this.templates[templateName] || null;
    }

    // Transform data between different naming conventions
    transformFieldNames(data, fromConvention, toConvention) {
        const transformed = { ...data };

        for (const [fieldKey, mapping] of Object.entries(this.fieldMappings)) {
            let sourceValue = null;

            // Get value from source convention
            if (fromConvention === 'database') {
                for (const dbField of mapping.database) {
                    if (data[dbField] !== undefined) {
                        sourceValue = data[dbField];
                        break;
                    }
                }
            } else if (fromConvention === 'form') {
                for (const formField of mapping.form) {
                    if (data[formField] !== undefined) {
                        sourceValue = data[formField];
                        break;
                    }
                }
            }

            // Set value in target convention
            if (sourceValue !== null) {
                if (toConvention === 'database') {
                    // Set in first available database field
                    if (mapping.database.length > 0) {
                        transformed[mapping.database[0]] = sourceValue;
                    }
                } else if (toConvention === 'form') {
                    // Set in first available form field
                    if (mapping.form.length > 0) {
                        transformed[mapping.form[0]] = sourceValue;
                    }
                } else if (toConvention === 'display') {
                    transformed[fieldKey] = sourceValue;
                }
            }
        }

        return transformed;
    }

    // Validate template syntax
    validateTemplate(templateName) {
        const template = this.templates[templateName];
        if (!template) {
            return { valid: false, error: `Template '${templateName}' not found` };
        }

        // Basic template validation - check for unmatched variables
        const variableRegex = /\{\{(\w+)\}\}/g;
        const variables = [];
        let match;

        while ((match = variableRegex.exec(template.template)) !== null) {
            variables.push(match[1]);
        }

        const missingTransforms = [];
        for (const variable of variables) {
            if (!template.transformations[variable]) {
                missingTransforms.push(variable);
            }
        }

        return {
            valid: missingTransforms.length === 0,
            errors: missingTransforms.length > 0 ? [`Missing transformations for: ${missingTransforms.join(', ')}`] : [],
            variables: variables,
            template: template.template
        };
    }
}
