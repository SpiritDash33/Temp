// UIService.js - UI management and performance optimizations
class UIService {
    constructor(eventBus) {
        this.eventBus = eventBus;
        this.updateQueue = new Set();
        this.frameRequested = false;
        this.statusTimeout = null;
        this.theme = 'light';
        this.app = null; // Will be set by WMSApp during initialization
        
        // Calendar state management
        const today = new Date();
        this.currentCalendarMonth = today.getMonth();
        this.currentCalendarYear = today.getFullYear();
    }

    // Set application reference (called by WMSApp after service creation)
    setApp(app) {
        this.app = app;
    }

    // UI Performance Optimizations - Batch Updates
    queueUpdate(component) {
        this.updateQueue.add(component);
        if (!this.frameRequested) {
            this.frameRequested = true;
            requestAnimationFrame(() => this.processUpdates());
        }
    }

    async processUpdates() {
        for (const component of this.updateQueue) {
            try {
                await this.performUpdate(component);
            } catch (error) {
                console.error(`Update failed for ${component}:`, error);
            }
        }
        
        this.updateQueue.clear();
        this.frameRequested = false;
    }

    async performUpdate(component) {
        switch (component) {
            case 'jobSummary':
                await this.updateJobSummary();
                break;
            case 'jobsList':
                await this.updateJobsList();
                break;
            case 'dailyJobs':
                this.updateDailyJobs();
                break;
            case 'calendar':
                await this.updateCalendar();
                break;
            case 'all':
                await this.updateJobSummary();
                await this.updateJobsList();
                this.updateDailyJobs();
                await this.updateCalendar();
                break;
            default:
                console.warn(`Unknown component for update: ${component}`);
        }
    }

    // Main UI update method
    updateAllDisplays() {
        this.queueUpdate('all');
    }

    // Individual update methods
    async updateJobSummary() {
        const app = window.WMSApplication;
        if (!app) return;

        const summaryDiv = document.getElementById('jobSummary');
        if (!summaryDiv) return;

        const jobs = app.state.jobs;
        const currentDate = app.state.focusedDate;

        if (jobs.length === 0) {
            summaryDiv.innerHTML = '<p>No jobs for this date.</p>';
            return;
        }

        const dayName = new Date(currentDate + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long' });
        const withPeople = [...new Set(jobs.filter(job => job.jobParticipants && job.jobParticipants.trim()).map(job => job.jobParticipants.trim()))];

        let summaryHTML = `<div class="job-summary-item">`;
        summaryHTML += `<strong>[${currentDate}] - ${dayName}</strong><br>`;
        summaryHTML += `hr. 8<br>`;
        if (withPeople.length > 0) {
            summaryHTML += `With: ${withPeople.join(', ')}<br>`;
        }

        const validationService = app.getService('validation');
        jobs.forEach(job => {
            const missingFields = validationService ? validationService.validateRequiredFields(job) : [];
            const hasRequired = missingFields.length === 0;
            const isCurrent = app.state.currentJobId === job.id;

            let className = 'job-link';
            if (!hasRequired) className += ' missing-required';
            if (isCurrent) className += ' current-job';

            const status = job.jobFieldStatus ? ` - ${job.jobFieldStatus}` : '';
            summaryHTML += `<a href="#" class="${className}" onclick="WMSApplication.loadJobById(${job.id}); return false;" style="display: block; margin: 5px 0;">${job.jobName || job.miscName || 'Unnamed Job'}${status}</a>`;
        });

        summaryHTML += `</div>`;
        summaryDiv.innerHTML = summaryHTML;
    }

    async updateJobsList() {
        const app = window.WMSApplication;
        if (!app) return;

        const jobsListDiv = document.getElementById('jobsList');
        if (!jobsListDiv) return;

        const jobs = app.state.jobs;
        const validationService = app.getService('validation');
        let listHTML = '';

        jobs.forEach((job, index) => {
            const missingFields = validationService ? validationService.validateRequiredFields(job) : [];
            const hasRequired = missingFields.length === 0;
            const isCurrent = app.state.currentJobId === job.id;

            let className = 'job-link';
            if (!hasRequired) className += ' missing-required';
            if (isCurrent) className += ' current-job';

            const dragHandle = app.state.reorderEnabled ? '<span style="cursor: grab; margin-right: 5px;">☰</span>' : '';

            const displayName = job.jobName || job.miscName || 'Unnamed Job';
            listHTML += `<div class="job-item" data-job-id="${job.id}" data-index="${index}" style="display: flex; align-items: center; margin: 5px 0;" ${app.state.reorderEnabled ? 'draggable="true"' : ''}>
                ${dragHandle}
                <a href="#" class="${className}" onclick="WMSApplication.loadJobById(${job.id}); return false;" style="flex: 1; margin: 0;">
                    ${displayName}
                </a>
                <span id="delete-${job.id}" onclick="WMSApplication.getService('ui').toggleDelete(${job.id})" style="margin-left: 5px; cursor: pointer; font-size: 16px;">🗑️</span>
                <span id="cancel-${job.id}" onclick="WMSApplication.getService('ui').cancelDelete(${job.id})" style="margin-left: 3px; cursor: pointer; font-size: 14px; display: none;">❌</span>
            </div>`;
        });

        jobsListDiv.innerHTML = listHTML || '<p>No jobs for this date.</p>';
        
        if (app.state.reorderEnabled) {
            this.setupDragAndDrop();
        }
    }

    updateDailyJobs() {
        const app = window.WMSApplication;
        if (!app) return;

        const dailyJobsDiv = document.getElementById('dailyJobs');
        if (!dailyJobsDiv) return;

        const jobs = app.state.jobs;
        const validationService = app.getService('validation');
        let dailyHTML = '';

        jobs.forEach(job => {
            const missingFields = validationService ? validationService.validateRequiredFields(job) : [];
            const hasRequired = missingFields.length === 0;
            const isCurrent = app.state.currentJobId === job.id;
            let className = 'daily-job-box';
            if (!hasRequired) className += ' missing-required';
            if (isCurrent) className += ' current-job';

            dailyHTML += `<div class="${className}" onclick="WMSApplication.loadJobById(${job.id})" style="cursor: pointer;">`;
            dailyHTML += `<strong>Job: ${job.jobName || job.miscName || 'Unnamed Job'}</strong><br>`;
            dailyHTML += `Number: ${job.jobNumber || job.ticketNumber || 'N/A'}<br>`;
            dailyHTML += `Date: ${job.jobStartDate || job.miscStartDate || 'N/A'} | ${job.jobStartTime || job.miscStartTime || 'N/A'} - ${job.jobEndTime || 'N/A'}<br>`;
            dailyHTML += `Status: ${job.jobFieldStatus || 'N/A'}<br>`;
            dailyHTML += `Device: ${job.jobDeviceNames || 'N/A'} (${job.deviceType || 'N/A'})<br>`;
            if (job.jobTroubleDescription) {
                dailyHTML += `Problem: ${job.jobTroubleDescription}<br>`;
            }
            if (job.jobWorkDescription) {
                dailyHTML += `Work: ${job.jobWorkDescription}<br>`;
            }
            dailyHTML += `</div>`;
        });

        dailyJobsDiv.innerHTML = dailyHTML || '<p>No jobs for this date.</p>';
    }

    async updateCalendar() {
        console.log('📅 updateCalendar called');
        const app = this.app || window.WMSApplication;
        if (!app) {
            console.error('❌ WMSApplication not available');
            return;
        }

        const calendarDiv = document.getElementById('calendar');
        if (!calendarDiv) {
            console.error('❌ Calendar div not found');
            return;
        }
        console.log('✅ Calendar div found');

        const databaseService = app.getService('database');
        const validationService = app.getService('validation');
        
        // Use tracked calendar month/year instead of always current month
        const firstDay = new Date(this.currentCalendarYear, this.currentCalendarMonth, 1);
        const startDate = new Date(firstDay);
        startDate.setDate(startDate.getDate() - firstDay.getDay());

        let calendarHTML = '';

        // Calendar navigation header - Update the section header display
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                           'July', 'August', 'September', 'October', 'November', 'December'];
        const today = new Date();
        const isCurrentMonth = this.currentCalendarMonth === today.getMonth() && this.currentCalendarYear === today.getFullYear();
        
        // Update month/year display in the section header
        const monthYearDisplay = document.getElementById('calendarMonthYear');
        if (monthYearDisplay) {
            monthYearDisplay.textContent = `${monthNames[this.currentCalendarMonth]} ${this.currentCalendarYear}`;
        }

        // Day headers
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        dayNames.forEach(day => {
            calendarHTML += `<div class="calendar-day-header">${day}</div>`;
        });

        // Get entries for visible date range
        const visibleDates = [];
        for (let i = 0; i < 42; i++) {
            const date = new Date(startDate);
            date.setDate(startDate.getDate() + i);
            visibleDates.push(date.toISOString().split('T')[0]);
        }

        try {
            // Use cache service if available for better performance
            const cacheService = app.getService('cache');
            let entriesByDate = {};
            
            if (cacheService) {
                // Use cached entries for better performance
                const entriesPromises = visibleDates.map(date => 
                    cacheService.getCachedEntriesForDate(date, () => 
                        databaseService.getEntriesForDate(date)
                    )
                );
                const entriesResults = await Promise.all(entriesPromises);
                visibleDates.forEach((date, index) => {
                    entriesByDate[date] = entriesResults[index];
                });
            } else {
                // Fallback to direct database calls
                const entriesPromises = visibleDates.map(date => databaseService.getEntriesForDate(date));
                const entriesResults = await Promise.all(entriesPromises);
                visibleDates.forEach((date, index) => {
                    entriesByDate[date] = entriesResults[index];
                });
            }

            // Calendar days
            for (let i = 0; i < 42; i++) {
                const date = new Date(startDate);
                date.setDate(startDate.getDate() + i);
                const dateStr = date.toISOString().split('T')[0];
                const dayJobs = entriesByDate[dateStr] || [];
                const isSelected = dateStr === app.state.focusedDate;
                
                // Check if day is in current month
                const isCurrentMonthDay = date.getMonth() === this.currentCalendarMonth;

                calendarHTML += `<div class="calendar-day ${!isCurrentMonthDay ? 'other-month' : ''}">`;
                calendarHTML += `<div class="calendar-day-number ${isSelected ? 'selected' : ''}" onclick="WMSApplication.getService('ui').selectDate('${dateStr}')" style="cursor: pointer;">${date.getDate()}</div>`;

                dayJobs.forEach(job => {
                    const missingFields = validationService ? validationService.validateRequiredFields(job) : [];
                    const hasRequired = missingFields.length === 0;
                    const isCurrent = app.state.currentJobId === job.id;
                    
                    let className = 'calendar-job';
                    if (!hasRequired) className += ' missing-required';
                    if (isCurrent) className += ' current-job';
                    
                    const displayText = job.buildingCode || job.ticketNumber || job.jobNumber || 'N/A';
                    const jobName = job.jobName || job.miscName || 'Unnamed';
                    calendarHTML += `<div class="${className}" onclick="WMSApplication.selectCalendarJob('${dateStr}', ${job.id})" title="${jobName}">${displayText}</div>`;
                });

                calendarHTML += `</div>`;
            }

            calendarDiv.innerHTML = calendarHTML;
            calendarDiv.className = 'calendar';
        } catch (error) {
            console.error('Failed to update calendar:', error);
            calendarDiv.innerHTML = '<p>Error loading calendar data</p>';
        }
    }

    async selectDate(dateStr) {
        console.log('🔍 selectDate called with:', dateStr);
        
        try {
            const app = window.WMSApplication;
            if (!app) {
                console.error('❌ WMSApplication not found');
                return;
            }
            
            console.log('✅ WMSApplication found, current state:', {
                currentView: app.state.currentView,
                currentJobId: app.state.currentJobId,
                focusedDate: app.state.focusedDate
            });

            // Auto-save current progress if in task view
            if ((app.state.currentView === 'jobTask' || app.state.currentView === 'generalTask') && app.state.currentJobId) {
                console.log('💾 Auto-saving current job before date change');
                const jobService = app.getService('job');
                if (jobService) {
                    await jobService.saveCurrentJob();
                }
            }
            
            console.log('📡 Publishing ui:dateChanged event');
            this.eventBus.publish('ui:dateChanged', { date: dateStr });
            console.log('✅ Date selection completed');
        } catch (error) {
            console.error('❌ Error in selectDate:', error);
            alert('Error selecting date: ' + error.message);
        }
    }

    // View management
    showView(viewName) {
        console.log(`🎯 showView called with: ${viewName}`);
        
        document.querySelectorAll('.view-content').forEach(view => {
            view.style.display = 'none';
        });

        const viewElement = document.getElementById(viewName + 'View') || document.getElementById(viewName + 'PageView');
        console.log(`🎯 Looking for view: ${viewName}View, found:`, !!viewElement);
        
        if (viewElement) {
            viewElement.style.display = 'block';
            console.log(`✅ Showing view: ${viewName}`);
        } else {
            console.error(`❌ View element not found for: ${viewName}`);
        }

        this.updateViewTitles(viewName);
    }

    updateViewTitles(viewName) {
        const titleEl = document.getElementById('dynamicViewTitle');
        const newBtn = document.getElementById('newBtn');
        const saveBtn = document.getElementById('saveBtn');

        switch(viewName) {
            case 'launch':
                if (titleEl) titleEl.textContent = 'Launch Page';
                if (newBtn) newBtn.style.display = 'none';
                if (saveBtn) saveBtn.style.display = 'none';
                break;
            case 'jobTask':
                if (titleEl) titleEl.textContent = 'Edit Job Task';
                if (newBtn) newBtn.style.display = 'inline-block';
                if (saveBtn) saveBtn.style.display = 'inline-block';
                break;
            case 'generalTask':
                if (titleEl) titleEl.textContent = 'Edit General Task';
                if (newBtn) newBtn.style.display = 'inline-block';
                if (saveBtn) saveBtn.style.display = 'inline-block';
                break;
            case 'search':
                if (titleEl) titleEl.textContent = 'Search Results';
                if (newBtn) newBtn.style.display = 'none';
                if (saveBtn) saveBtn.style.display = 'none';
                break;
            case 'advancedSearch':
                if (titleEl) titleEl.textContent = 'Advanced Search';
                if (newBtn) newBtn.style.display = 'none';
                if (saveBtn) saveBtn.style.display = 'none';
                break;
        }
    }

    // Status management
    showStatus(message, type = 'info', duration = 5000) {
        // Clear existing timeout
        if (this.statusTimeout) {
            clearTimeout(this.statusTimeout);
        }

        // Show status in import area or create temporary status
        const statusDiv = document.getElementById('importStatus') || this.createTemporaryStatus();
        const statusClass = type === 'error' ? 'import-error' : 'import-success';
        
        statusDiv.innerHTML = `<div class="import-status ${statusClass}">${message}</div>`;
        
        // Auto-hide after duration
        this.statusTimeout = setTimeout(() => {
            statusDiv.innerHTML = '';
        }, duration);

        console.log(`[${type.toUpperCase()}] ${message}`);
    }

    createTemporaryStatus() {
        const statusDiv = document.createElement('div');
        statusDiv.id = 'temporaryStatus';
        statusDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            max-width: 400px;
        `;
        document.body.appendChild(statusDiv);
        return statusDiv;
    }

    // Theme management
    initializeTheme() {
        const savedTheme = localStorage.getItem('wms_theme') || 'light';
        this.setTheme(savedTheme);
    }

    setTheme(theme) {
        this.theme = theme;
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('wms_theme', theme);
        this.updateThemeToggleIcon(theme);
    }

    toggleTheme() {
        const newTheme = this.theme === 'light' ? 'dark' : 'light';
        this.setTheme(newTheme);
    }

    updateThemeToggleIcon(theme) {
        const toggleBtn = document.getElementById('themeToggle');
        if (toggleBtn) {
            toggleBtn.textContent = theme === 'light' ? '🌙' : '☀️';
            toggleBtn.title = theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode';
        }
    }

    // Drag and drop functionality
    setupDragAndDrop() {
        const jobItems = document.querySelectorAll('.job-item');
        
        jobItems.forEach(item => {
            item.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('text/plain', e.target.dataset.index);
                e.target.style.opacity = '0.5';
            });
            
            item.addEventListener('dragend', (e) => {
                e.target.style.opacity = '1';
            });
            
            item.addEventListener('dragover', (e) => {
                e.preventDefault();
            });
            
            item.addEventListener('drop', async (e) => {
                e.preventDefault();
                const fromIndex = parseInt(e.dataTransfer.getData('text/plain'));
                const toIndex = parseInt(e.target.closest('.job-item').dataset.index);
                
                if (fromIndex !== toIndex) {
                    const app = window.WMSApplication;
                    if (app) {
                        // Reorder in memory
                        const movedJob = app.state.jobs.splice(fromIndex, 1)[0];
                        app.state.jobs.splice(toIndex, 0, movedJob);
                        
                        // Persist the new order to database
                        await this.saveJobsOrder(app.state.jobs);
                        
                        // Clear cache for the current date
                        const cacheService = app.getService('cache');
                        if (cacheService) {
                            cacheService.invalidatePattern(`jobs:date:${app.state.focusedDate}`);
                            cacheService.invalidatePattern(`entries:date:${app.state.focusedDate}`);
                        }
                        
                        this.updateAllDisplays();
                    }
                }
            });
        });
    }

    // Job deletion helpers (referenced in updateJobsList)
    toggleDelete(jobId) {
        const deleteIcon = document.getElementById(`delete-${jobId}`);
        const cancelIcon = document.getElementById(`cancel-${jobId}`);
        
        if (deleteIcon && deleteIcon.innerHTML === '🗑️') {
            deleteIcon.innerHTML = '✅';
            if (cancelIcon) cancelIcon.style.display = 'inline';
        } else {
            this.deleteJobById(jobId);
        }
    }

    cancelDelete(jobId) {
        const deleteIcon = document.getElementById(`delete-${jobId}`);
        const cancelIcon = document.getElementById(`cancel-${jobId}`);
        
        if (deleteIcon) deleteIcon.innerHTML = '🗑️';
        if (cancelIcon) cancelIcon.style.display = 'none';
    }

    async deleteJobById(jobId) {
        const app = window.WMSApplication;
        if (!app) return;

        const jobService = app.getService('job');
        if (jobService) {
            await jobService.deleteJobById(jobId);
        }
    }

    // Search results display
    displaySearchResults(results, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        if (results.length === 0) {
            container.innerHTML = '<p>No results found.</p>';
            return;
        }
        
        let html = '';
        results.forEach(result => {
            const name = result.jobName || result.miscName || 'Unnamed';
            const date = result.jobStartDate || result.miscStartDate || 'No date';
            html += `<div class="job-link" onclick="WMSApplication.loadJobById(${result.id})">
                <strong>${name}</strong><br>
                Date: ${date}<br>
                Type: ${result.jobName ? 'Job Task' : 'General Task'}
            </div>`;
        });
        container.innerHTML = html;
    }

    // Calendar Navigation Methods
    navigateToPreviousMonth() {
        this.currentCalendarMonth--;
        if (this.currentCalendarMonth < 0) {
            this.currentCalendarMonth = 11;
            this.currentCalendarYear--;
        }
        this.queueUpdate('calendar');
    }

    navigateToNextMonth() {
        this.currentCalendarMonth++;
        if (this.currentCalendarMonth > 11) {
            this.currentCalendarMonth = 0;
            this.currentCalendarYear++;
        }
        this.queueUpdate('calendar');
    }

    navigateToCurrentMonth() {
        const today = new Date();
        this.currentCalendarMonth = today.getMonth();
        this.currentCalendarYear = today.getFullYear();
        this.queueUpdate('calendar');
    }

    navigateToMonth(month, year) {
        if (month >= 0 && month <= 11 && year > 1900 && year < 3000) {
            this.currentCalendarMonth = month;
            this.currentCalendarYear = year;
            this.queueUpdate('calendar');
        }
    }

    // Get current calendar state (useful for other components)
    getCurrentCalendarState() {
        return {
            month: this.currentCalendarMonth,
            year: this.currentCalendarYear
        };
    }

    // Save jobs order to database
    async saveJobsOrder(jobs) {
        const app = window.WMSApplication;
        if (!app) return;

        const databaseService = app.getService('database');
        if (!databaseService) return;

        try {
            // Update displayOrder for each job and save to database
            for (let i = 0; i < jobs.length; i++) {
                const job = jobs[i];
                job.displayOrder = i;

                // Determine if it's a ticket entry or misc entry
                const isTicketEntry = job.jobName !== undefined;
                
                if (isTicketEntry) {
                    await databaseService.saveTicketEntry(job);
                } else {
                    await databaseService.saveMiscEntry(job);
                }
            }

            console.log('✅ Jobs order saved to database');
        } catch (error) {
            console.error('❌ Failed to save jobs order:', error);
            this.showStatus('Failed to save job order', 'error');
        }
    }
}
