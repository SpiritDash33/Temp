// ValidationService.js - Input validation and sanitization
class ValidationService {
    constructor(requiredFields, eventBus) {
        this.requiredFields = requiredFields;
        this.eventBus = eventBus;
        this.sanitizer = new InputSanitizer();
    }

    validateRequiredFields(jobData = null) {
        try {
            const data = jobData || this.getCurrentFormData();
            const missingFields = [];

            // Map of form field IDs (snake_case) to database field names (camelCase)
            const fieldMapping = {
                'job_name': 'jobName',
                'job_start_date': 'jobStartDate',
                'job_start_time': 'jobStartTime',
                'job_end_time': 'jobEndTime',
                'job_dispatch_type': 'jobDispatchType',
                'job_field_status': 'jobFieldStatus',
                'job_followup_required': 'jobFollowupRequired',
                'device_id': 'jobDeviceNames',
                'job_trouble_description': 'jobTroubleDescription',
                'job_work_description': 'jobWorkDescription'
            };

            this.requiredFields.forEach(field => {
                // Try snake_case field name first (for form data)
                let value = data[field];
                
                // If not found, try camelCase field name (for database objects)
                if (value === undefined && fieldMapping[field]) {
                    value = data[fieldMapping[field]];
                }
                
                // Check if value is missing or empty
                // Special handling for booleans - false is a valid value
                if (value === undefined || value === null) {
                    missingFields.push(field);
                } else if (typeof value === 'string' && value.trim() === '') {
                    missingFields.push(field);
                }
                // Note: boolean false is valid, so we don't add to missingFields
            });

            // Log only when there are jobs with missing fields being checked from database objects
            if (jobData && missingFields.length > 0) {
                console.log(`⚠️ Job "${jobData.jobName || jobData.miscName || 'Unknown'}" has missing fields:`, missingFields);
            }

            return missingFields;
        } catch (error) {
            this.eventBus.publish('error:occurred', { 
                message: error.message, 
                operation: 'validateRequiredFields' 
            });
            return [];
        }
    }

    getCurrentFormData() {
        const app = window.WMSApplication;
        if (!app) return {};
        
        const jobService = app.getService('job');
        return jobService ? jobService.getCurrentJobData() : {};
    }

    highlightRequiredFields() {
        const currentData = this.getCurrentFormData();
        const missingFields = this.validateRequiredFields(currentData);

        console.log('Required field validation - missing fields:', missingFields);

        this.requiredFields.forEach(field => {
            const element = document.getElementById(field);
            if (element) {
                const isMissing = missingFields.includes(field);
                if (isMissing) {
                    element.classList.add('required-empty');
                    console.log(`Added required-empty class to ${field}`);
                } else {
                    element.classList.remove('required-empty');
                    console.log(`Removed required-empty class from ${field}`);
                }
            } else {
                console.warn(`Element with ID '${field}' not found`);
            }
        });

        return missingFields;
    }

    // Enhanced validation with business rules
    validateJobData(jobData) {
        const errors = [];
        const warnings = [];

        // Basic required fields
        const missingRequired = this.validateRequiredFields(jobData);
        missingRequired.forEach(field => {
            errors.push(`${this.getFieldLabel(field)} is required`);
        });

        // Time validation
        if (jobData.job_start_time && jobData.job_end_time) {
            if (jobData.job_start_time >= jobData.job_end_time) {
                errors.push('End time must be after start time');
            }
        }

        // Date validation
        if (jobData.job_start_date) {
            const jobDate = new Date(jobData.job_start_date);
            const today = new Date();
            const daysDiff = (jobDate - today) / (1000 * 60 * 60 * 24);
            
            if (daysDiff > 30) {
                warnings.push('Job date is more than 30 days in the future');
            }
        }

        // Device validation
        if (!jobData.device_id && !jobData.job_trouble_description?.includes('general')) {
            warnings.push('Device ID should be specified for device-specific issues');
        }

        // Status validation
        if (jobData.job_field_status === 'close' && !jobData.job_work_description) {
            errors.push('Work description is required when closing a job');
        }

        return { errors, warnings, isValid: errors.length === 0 };
    }

    getFieldLabel(fieldId) {
        const labels = {
            'job_name': 'Job Name',
            'job_start_date': 'Start Date',
            'job_start_time': 'Start Time',
            'job_end_time': 'End Time',
            'job_dispatch_type': 'Dispatch Type',
            'job_field_status': 'Field Status',
            'job_followup_required': 'Follow-up Required',
            'device_id': 'Device ID',
            'job_trouble_description': 'Trouble Description',
            'job_work_description': 'Work Description'
        };
        return labels[fieldId] || fieldId;
    }

    // Sanitize user input
    sanitizeInput(input) {
        return this.sanitizer.sanitize(input);
    }

    sanitizeFormData(formData) {
        const sanitized = {};
        Object.entries(formData).forEach(([key, value]) => {
            if (typeof value === 'string') {
                sanitized[key] = this.sanitizer.sanitize(value);
            } else {
                sanitized[key] = value;
            }
        });
        return sanitized;
    }

    // Validate email data
    validateEmailData(emailData) {
        const errors = [];
        
        if (!emailData.job_name || emailData.job_name.trim() === '') {
            errors.push('Email must contain a job name or subject');
        }
        
        if (!emailData.job_trouble_description || emailData.job_trouble_description.trim() === '') {
            errors.push('Email must contain a problem description');
        }
        
        return { errors, isValid: errors.length === 0 };
    }
}

// Input Sanitization Class
class InputSanitizer {
    constructor() {
        // Basic HTML entities
        this.htmlEntities = {
            '&': '&',
            '<': '<',
            '>': '>',
            '"': '"',
            "'": '&#x27;',
            '/': '&#x2F;'
        };
        
        // SQL injection patterns
        this.sqlPatterns = [
            /(\b(ALTER|CREATE|DELETE|DROP|EXEC|EXECUTE|INSERT|MERGE|SELECT|UPDATE|UNION|USE)\b)/gi,
            /(script\s*:)|(javascript\s*:)|(vbscript\s*:)/gi,
            /(<\s*script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script\s*>)/gi
        ];
        
        // XSS patterns
        this.xssPatterns = [
            /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
            /<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi,
            /javascript\s*:/gi,
            /on\w+\s*=/gi
        ];
    }

    sanitize(input) {
        if (typeof input !== 'string') {
            return input;
        }

        let sanitized = input;
        
        // Remove potential XSS vectors
        this.xssPatterns.forEach(pattern => {
            sanitized = sanitized.replace(pattern, '');
        });
        
        // Remove potential SQL injection vectors  
        this.sqlPatterns.forEach(pattern => {
            sanitized = sanitized.replace(pattern, (match) => {
                return match.replace(/[&<>"'\/]/g, (s) => this.htmlEntities[s]);
            });
        });
        
        // Basic HTML entity encoding for remaining content
        sanitized = this.escapeHtml(sanitized);
        
        return sanitized.trim();
    }

    escapeHtml(text) {
        return text.replace(/[&<>"'\/]/g, (s) => this.htmlEntities[s]);
    }

    // More aggressive sanitization for critical fields
    strictSanitize(input) {
        if (typeof input !== 'string') {
            return input;
        }
        
        // Remove all HTML tags and scripts
        let sanitized = input
            .replace(/<[^>]*>/g, '')
            .replace(/javascript:/gi, '')
            .replace(/vbscript:/gi, '')
            .replace(/data:/gi, '');
        
        return this.escapeHtml(sanitized).trim();
    }

    // Domain-specific validation
    validateJobNumber(jobNumber) {
        // Allow AUTO-generated, standard formats, and common patterns
        const validPatterns = [
            /^AUTO-\d+-\d+$/,  // Auto-generated
            /^[PT]\d{6,12}$/,   // P or T followed by 6-12 digits
            /^SIM-T\s+\w+$/,    // SIM-T format
            /^[A-Z0-9\-_]{3,20}$/ // General alphanumeric
        ];
        
        return validPatterns.some(pattern => pattern.test(jobNumber));
    }

    validateDeviceId(deviceId) {
        // Device IDs should be alphanumeric with common separators
        return /^[A-Za-z0-9\-_\.\s]{1,100}$/.test(deviceId);
    }

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    validateDate(dateString) {
        const date = new Date(dateString);
        return date instanceof Date && !isNaN(date);
    }

    validateTime(timeString) {
        return /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/.test(timeString);
    }
}
