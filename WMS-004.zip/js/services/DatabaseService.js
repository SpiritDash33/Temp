// DatabaseService.js - Database operations wrapper
class DatabaseService {
    constructor() {
        this.manager = null;
        this.initialized = false;
    }

    async init() {
        try {
            this.manager = new TicketDBManager();
            await this.manager.init();
            this.initialized = true;
            console.log('✅ Database service initialized');
        } catch (error) {
            console.error('❌ Database service initialization failed:', error);
            throw new Error(`Database initialization failed: ${error.message}`);
        }
    }

    getManager() {
        if (!this.initialized) {
            throw new Error('Database service not initialized');
        }
        return this.manager;
    }

    // Wrapped methods with error handling
    async getEntriesForDate(date) {
        try {
            return await this.manager.getEntriesForDate(date);
        } catch (error) {
            console.error('Failed to get entries for date:', error);
            throw new Error(`Failed to load data for ${date}: ${error.message}`);
        }
    }

    async saveTicketEntry(entryData) {
        try {
            return await this.manager.saveTicketEntry(entryData);
        } catch (error) {
            console.error('Failed to save ticket entry:', error);
            throw new Error(`Failed to save job: ${error.message}`);
        }
    }

    async saveMiscEntry(entryData) {
        try {
            return await this.manager.saveMiscEntry(entryData);
        } catch (error) {
            console.error('Failed to save misc entry:', error);
            throw new Error(`Failed to save task: ${error.message}`);
        }
    }

    async deleteEntry(entryId, entryType) {
        try {
            return await this.manager.deleteEntry(entryId, entryType);
        } catch (error) {
            console.error('Failed to delete entry:', error);
            throw new Error(`Failed to delete ${entryType}: ${error.message}`);
        }
    }

    async searchEntries(searchTerm) {
        try {
            return await this.manager.searchEntries(searchTerm);
        } catch (error) {
            console.error('Failed to search entries:', error);
            throw new Error(`Search failed: ${error.message}`);
        }
    }

    async exportData() {
        try {
            return await this.manager.exportData();
        } catch (error) {
            console.error('Failed to export data:', error);
            throw new Error(`Export failed: ${error.message}`);
        }
    }

    async ensureTicket(ticketNumber, buildingId) {
        try {
            return await this.manager.ensureTicket(ticketNumber, buildingId);
        } catch (error) {
            console.error('Failed to ensure ticket:', error);
            throw new Error(`Failed to create/find ticket: ${error.message}`);
        }
    }

    isInitialized() {
        return this.initialized;
    }
}
