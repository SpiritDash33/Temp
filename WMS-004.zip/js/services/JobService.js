// JobService.js - Job management and business logic
class JobService {
    constructor(databaseService, eventBus, cacheService = null) {
        this.database = databaseService;
        this.eventBus = eventBus;
        this.cache = cacheService; // Use the advanced CacheService
    }

    // Job data operations
    async loadJobsForDate(date) {
        try {
            let jobs;
            
            if (this.cache) {
                // Use advanced CacheService
                jobs = await this.cache.getCachedJobsForDate(date, () => 
                    this.database.getEntriesForDate(date)
                );
            } else {
                // Fallback to direct database call
                jobs = await this.database.getEntriesForDate(date);
            }
            
            // Update global state for legacy compatibility
            if (window.WMSApplication) {
                window.WMSApplication.state.jobs = jobs;
            }
            
            return jobs;
        } catch (error) {
            this.eventBus.publish('error:occurred', { 
                message: error.message, 
                operation: 'loadJobsForDate' 
            });
            throw error;
        }
    }

    getCurrentJobData() {
        const form = document.getElementById('jobForm');
        if (!form) return {};
        
        const formData = {};
        const inputs = form.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            formData[input.id] = input.value;
        });
        
        return formData;
    }

    getGeneralTaskData() {
        const form = document.getElementById('generalForm');
        if (!form) return {};
        
        const formData = {};
        const inputs = form.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            formData[input.id] = input.value;
        });
        
        return formData;
    }

    async saveCurrentJob() {
        try {
            const app = window.WMSApplication;
            if (!app) throw new Error('Application not initialized');

            if (app.state.currentTaskType === 'general') {
                return await this.saveGeneralTask();
            }

            const jobData = this.getCurrentJobData();
            const newJobNumber = jobData.job_number || `AUTO-${Date.now()}`;

            // Ensure correct ticket exists
            const ticket = await this.database.ensureTicket(newJobNumber, 1);

            const entryData = {
                ticketId: ticket.id,
                jobNumber: newJobNumber,
                buildingCode: jobData.building_code,
                buildingAddress: jobData.building_address,
                jobName: jobData.job_name,
                jobStartDate: jobData.job_start_date,
                jobStartTime: jobData.job_start_time,
                jobEndTime: jobData.job_end_time,
                jobParticipants: jobData.job_participants,
                jobReferenceNumber: jobData.job_reference_number,
                jobEscortDelay: jobData.job_escort_delay,
                jobHindrances: jobData.job_hindrances,
                jobMaterialsUsed: jobData.job_materials_used,
                jobMaterialsNeeded: jobData.job_materials_needed,
                jobAccessNeeded: jobData.job_access_needed,
                jobProgrammingChanges: jobData.job_programming_changes,
                jobDispatchType: jobData.job_dispatch_type,
                jobFieldStatus: jobData.job_field_status,
                jobFiledStatusNotes: jobData.job_filed_status_notes,
                jobFollowupRequired: jobData.job_followup_required === 'yes',
                jobDeviceNames: jobData.device_id,
                jobDeviceDetails: jobData.job_device_details,
                jobTroubleType: jobData.job_trouble_type,
                jobTroubleDescription: jobData.job_trouble_description,
                jobWorkDescription: jobData.job_work_description,
                jobTechnicalDetails: jobData.job_technical_details,
                relatedTickets: jobData.related_tickets,
                deviceType: jobData.device_type,
                jobChangedFlag: false,
                createdAt: app.state.currentJobEntry ? app.state.currentJobEntry.createdAt : new Date().toISOString()
            };

            if (app.state.currentJobId) {
                entryData.id = app.state.currentJobId;
            }

            const savedEntryId = await this.database.saveTicketEntry(entryData);
            app.state.currentJobId = savedEntryId;

            // Clear cache for affected date using new CacheService
            if (this.cache) {
                this.eventBus.publish('job:saved', { 
                    jobId: savedEntryId, 
                    jobData: entryData,
                    date: jobData.job_start_date
                });
            } else {
                this.eventBus.publish('job:saved', { 
                    jobId: savedEntryId, 
                    jobData: entryData 
                });
            }

            return savedEntryId;

        } catch (error) {
            this.eventBus.publish('error:occurred', { 
                message: error.message, 
                operation: 'saveCurrentJob' 
            });
            throw error;
        }
    }

    async saveGeneralTask() {
        try {
            const app = window.WMSApplication;
            const generalData = this.getGeneralTaskData();

            const entryData = {
                miscName: generalData.general_name,
                miscStartDate: generalData.general_start_date,
                miscStartTime: generalData.general_start_time,
                miscDescription: generalData.general_description,
                miscLocation: generalData.general_location,
                miscDuration: null,
                miscPriority: generalData.general_priority,
                miscParticipants: '',
                miscNotes: generalData.general_notes,
                createdAt: app.state.currentJobEntry ? app.state.currentJobEntry.createdAt : new Date().toISOString()
            };

            if (app.state.currentJobId) {
                entryData.id = app.state.currentJobId;
            }

            const savedId = await this.database.saveMiscEntry(entryData);
            app.state.currentJobId = savedId;

            // Clear cache for affected date using new CacheService
            if (this.cache) {
                this.eventBus.publish('job:saved', { 
                    jobId: savedId, 
                    jobData: entryData,
                    date: generalData.general_start_date
                });
            } else {
                this.eventBus.publish('job:saved', { 
                    jobId: savedId, 
                    jobData: entryData 
                });
            }

            return savedId;

        } catch (error) {
            this.eventBus.publish('error:occurred', { 
                message: error.message, 
                operation: 'saveGeneralTask' 
            });
            throw error;
        }
    }

    async loadJobById(jobId) {
        try {
            const app = window.WMSApplication;
            if (!app) throw new Error('Application not initialized');

            console.log(`🔍 Loading job by ID: ${jobId}`);

            // Find job in current jobs first
            let job = app.state.jobs.find(j => j.id === jobId);

            if (!job) {
                console.log(`🔍 Job not found in current jobs, searching all entries`);
                // Search all dates for this job using database service
                const allEntries = await this.database.exportData();
                const allJobs = [...(allEntries.ticketEntries || []), ...(allEntries.miscEntries || [])];
                job = allJobs.find(j => j.id === jobId);

                if (job) {
                    console.log(`✅ Found job in all entries:`, job);
                    // Switch to the job's date and reload
                    const jobDate = job.jobStartDate || job.miscStartDate;
                    if (jobDate && jobDate !== app.state.focusedDate) {
                        console.log(`📅 Switching to job's date: ${jobDate}`);
                        // Update focused date first
                        app.state.focusedDate = jobDate;

                        // Load jobs for the new date
                        await this.loadJobsForDate(jobDate);

                        // Update the date input field
                        const dateInput = document.getElementById('job_start_date');
                        if (dateInput) {
                            dateInput.value = jobDate;
                        }

                        // Update calendar display
                        const uiService = app.getService('ui');
                        if (uiService) {
                            uiService.queueUpdate('calendar');
                        }
                    }
                } else {
                    throw new Error(`Job with ID ${jobId} not found`);
                }
            } else {
                console.log(`✅ Found job in current jobs:`, job);
            }

            if (job) {
                console.log(`📋 Publishing job:loaded event for job: ${job.jobName || job.miscName || 'Unnamed'}`);

                // Populate the form with job data
                if (job.jobName) {
                    // It's a job task
                    app.state.currentTaskType = 'job';
                    this.populateJobForm(job);
                    this.eventBus.publish('ui:viewChanged', {
                        view: 'jobTask',
                        taskType: 'job'
                    });
                    
                    // Trigger validation highlighting after form is populated
                    setTimeout(() => {
                        const validationService = app.getService('validation');
                        if (validationService) {
                            validationService.highlightRequiredFields();
                        }
                    }, 50); // Small delay to ensure form is fully rendered
                } else if (job.miscName) {
                    // It's a general task
                    app.state.currentTaskType = 'general';
                    this.populateGeneralForm(job);
                    this.eventBus.publish('ui:viewChanged', {
                        view: 'generalTask',
                        taskType: 'general'
                    });
                    
                    // Trigger validation highlighting after form is populated (for general tasks too)
                    setTimeout(() => {
                        const validationService = app.getService('validation');
                        if (validationService) {
                            validationService.highlightRequiredFields();
                        }
                    }, 50); // Small delay to ensure form is fully rendered
                }

                // Update current job state
                app.state.currentJobId = job.id;
                app.state.currentJobEntry = job;

                // Publish the loaded event
                this.eventBus.publish('job:loaded', { job });

                // Update all displays
                const uiService = app.getService('ui');
                if (uiService) {
                    uiService.updateAllDisplays();
                }

                console.log(`✅ Job loaded successfully: ${job.jobName || job.miscName || 'Unnamed'}`);
            }

            return job;

        } catch (error) {
            console.error(`❌ Error loading job ${jobId}:`, error);
            this.eventBus.publish('error:occurred', {
                message: error.message,
                operation: 'loadJobById'
            });
            throw error;
        }
    }

    async deleteJobById(jobId) {
        try {
            const app = window.WMSApplication;
            const job = app.state.jobs.find(j => j.id === jobId);
            const jobType = job && job.jobName ? 'ticket' : 'misc';
            const jobDate = job ? (job.jobStartDate || job.miscStartDate) : null;
            
            await this.database.deleteEntry(jobId, jobType);
            
            this.eventBus.publish('job:deleted', { jobId, jobType, date: jobDate });
            
        } catch (error) {
            this.eventBus.publish('error:occurred', { 
                message: error.message, 
                operation: 'deleteJobById' 
            });
            throw error;
        }
    }

    async createNewJob(taskType = 'job') {
        try {
            const app = window.WMSApplication;
            
            // Save current job if it exists
            if (app.state.currentJobId) {
                await this.saveCurrentJob();
            }
            
            // Clear current job state
            app.state.currentJobId = null;
            app.state.currentJobEntry = null;
            
            // Clear the form before switching view
            if (taskType === 'general') {
                this.clearGeneralForm();
                this.eventBus.publish('ui:viewChanged', { 
                    view: 'generalTask', 
                    taskType: 'general' 
                });
            } else {
                this.clearJobForm();
                this.eventBus.publish('ui:viewChanged', { 
                    view: 'jobTask', 
                    taskType: 'job' 
                });
                
                // Trigger validation highlighting after form is cleared (to show required empty fields)
                setTimeout(() => {
                    const validationService = app.getService('validation');
                    if (validationService) {
                        validationService.highlightRequiredFields();
                    }
                }, 50); // Small delay to ensure form is fully rendered
            }
            
        } catch (error) {
            this.eventBus.publish('error:occurred', { 
                message: error.message, 
                operation: 'createNewJob' 
            });
            throw error;
        }
    }

    async searchJobs(searchTerm) {
        try {
            const results = await this.database.searchEntries(searchTerm);
            return results;
        } catch (error) {
            this.eventBus.publish('error:occurred', { 
                message: error.message, 
                operation: 'searchJobs' 
            });
            throw error;
        }
    }

    // Form population helpers
    populateJobForm(jobData) {
        const mapping = {
            'job_name': jobData.jobName || '',
            'job_number': jobData.jobNumber || jobData.ticketNumber || '',
            'building_code': jobData.buildingCode || '',
            'building_address': jobData.buildingAddress || '',
            'device_id': jobData.jobDeviceNames || '',
            'device_type': jobData.deviceType || '',
            'job_start_date': jobData.jobStartDate || '',
            'job_start_time': jobData.jobStartTime || '',
            'job_end_time': jobData.jobEndTime || '',
            'job_participants': jobData.jobParticipants || '',
            'job_dispatch_type': jobData.jobDispatchType || '',
            'job_field_status': jobData.jobFieldStatus || '',
            'job_followup_required': jobData.jobFollowupRequired === true ? 'yes' : (jobData.jobFollowupRequired === false ? 'no' : ''),
            'job_filed_status_notes': jobData.jobFiledStatusNotes || '',
            'job_materials_used': jobData.jobMaterialsUsed || '',
            'job_materials_needed': jobData.jobMaterialsNeeded || '',
            'job_reference_number': jobData.jobReferenceNumber || '',
            'job_escort_delay': jobData.jobEscortDelay || '',
            'job_hindrances': jobData.jobHindrances || '',
            'job_access_needed': jobData.jobAccessNeeded || '',
            'job_programming_changes': jobData.jobProgrammingChanges || '',
            'job_device_details': jobData.jobDeviceDetails || '',
            'job_trouble_type': jobData.jobTroubleType || '',
            'job_trouble_description': jobData.jobTroubleDescription || '',
            'job_work_description': jobData.jobWorkDescription || '',
            'job_technical_details': jobData.jobTechnicalDetails || '',
            'related_tickets': jobData.relatedTickets || ''
        };

        Object.entries(mapping).forEach(([fieldId, value]) => {
            const element = document.getElementById(fieldId);
            if (element) {
                element.value = value;
            }
        });
    }

    populateGeneralForm(jobData) {
        const mapping = {
            'general_name': jobData.miscName || '',
            'general_start_date': jobData.miscStartDate || '',
            'general_start_time': jobData.miscStartTime || '',
            'general_description': jobData.miscDescription || '',
            'general_location': jobData.miscLocation || '',
            'general_priority': jobData.miscPriority || '',
            'general_notes': jobData.miscNotes || ''
        };

        Object.entries(mapping).forEach(([fieldId, value]) => {
            const element = document.getElementById(fieldId);
            if (element) {
                element.value = value;
            }
        });
    }

    clearJobForm() {
        const form = document.getElementById('jobForm');
        if (form) {
            form.reset();
            
            // Set auto job number and current date
            const timestamp = Date.now();
            const randomNum = Math.floor(Math.random() * 1000);
            const jobNumberEl = document.getElementById('job_number');
            if (jobNumberEl) {
                jobNumberEl.value = `AUTO-${timestamp}-${randomNum}`;
            }
            
            const dateEl = document.getElementById('job_start_date');
            if (dateEl) {
                const app = window.WMSApplication;
                dateEl.value = app ? app.state.focusedDate : new Date().toISOString().split('T')[0];
            }
        }
    }

    clearGeneralForm() {
        const form = document.getElementById('generalForm');
        if (form) {
            form.reset();
            
            const dateEl = document.getElementById('general_start_date');
            if (dateEl) {
                const app = window.WMSApplication;
                dateEl.value = app ? app.state.focusedDate : new Date().toISOString().split('T')[0];
            }
        }
    }
}
