// EmailService.js - Email import and processing
class EmailService {
    constructor(jobService, eventBus) {
        this.jobService = jobService;
        this.eventBus = eventBus;
        this.emailParser = null;
        this.initialized = false;
    }

    async init() {
        try {
            // Initialize EmailParser if available
            if (typeof EmailParser !== 'undefined') {
                this.emailParser = new EmailParser({ 
                    debug: false,
                    enableRecovery: false,
                    enableAdvancedMIME: false,
                    enableSMIME: false
                });
                this.initialized = true;
            } else {
                console.warn('EmailParser not available - email import will be limited');
            }
        } catch (error) {
            console.error('EmailService initialization failed:', error);
        }
    }

    async handleEmailImport(files) {
        if (!this.initialized) {
            await this.init();
        }

        console.log(`📧 Processing ${files.length} email files`);
        
        const results = [];
        
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            console.log(`Processing file ${i + 1}/${files.length}: ${file.name}`);
            
            try {
                this.eventBus.publish('ui:statusUpdate', { 
                    message: `Processing ${file.name} (${i + 1}/${files.length})...`,
                    type: 'info' 
                });

                const emailData = await this.parseEmailFile(file);
                console.log(`File ${i + 1} email structure:`, emailData);
                
                const jobData = await this.extractStructuredEmailData(emailData);
                console.log(`File ${i + 1} job data:`, jobData);
                
                // Create job from email data
                const jobId = await this.createJobFromEmail(jobData, file.name);
                
                results.push({
                    fileName: file.name,
                    success: true,
                    jobId: jobId,
                    jobData: jobData
                });
                
                this.eventBus.publish('email:imported', { 
                    fileName: file.name,
                    jobId: jobId,
                    success: true
                });

            } catch (error) {
                console.error(`File ${i + 1} processing failed:`, error);
                
                results.push({
                    fileName: file.name,
                    success: false,
                    error: error.message
                });
                
                this.eventBus.publish('ui:statusUpdate', { 
                    message: `Failed to import ${file.name}: ${error.message}`,
                    type: 'error' 
                });
            }
        }
        
        const successCount = results.filter(r => r.success).length;
        this.eventBus.publish('ui:statusUpdate', { 
            message: `Import complete: ${successCount}/${files.length} files processed successfully`,
            type: successCount === files.length ? 'success' : 'warning'
        });
        
        return results;
    }

    async parseEmailFile(file) {
        if (this.emailParser) {
            return await this.emailParser.parse(file);
        } else {
            // Fallback parsing without EmailParser library
            return await this.basicEmailParse(file);
        }
    }

    async basicEmailParse(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                try {
                    const content = e.target.result;
                    const emailData = {
                        subject: this.extractSubject(content),
                        body: { text: content },
                        metadata: { fileInfo: { name: file.name } }
                    };
                    resolve(emailData);
                } catch (error) {
                    reject(error);
                }
            };
            
            reader.onerror = () => reject(new Error('File reading failed'));
            reader.readAsText(file);
        });
    }

    extractSubject(content) {
        const subjectMatch = content.match(/^Subject:\s*(.+)$/m);
        return subjectMatch ? subjectMatch[1].trim() : 'Email Import';
    }

    async extractStructuredEmailData(emailData) {
        // Get clean plain text using enhanced approach
        const bodyText = this.getCleanEmailText(emailData);
        const subject = emailData.subject || '';
        
        console.log('Extracting from cleaned body text:', bodyText.substring(0, 500));
        
        return {
            job_number: this.extractFieldValue(bodyText, ['SIM-T Ticket:', 'Service Call Number:', 'Bug Service Call:']) || 
                       this.extractJobNumberFromFilename(emailData.metadata?.fileInfo?.name) || 
                       `EMAIL-${Date.now()}`,
            job_name: this.extractJobName(subject, bodyText, emailData.metadata?.fileInfo?.name),
            device_name: this.extractFieldValue(bodyText, ['Device Name:']),
            device_type: this.extractFieldValue(bodyText, ['Device Type:']),
            job_trouble_description: this.extractMultiLineField(bodyText, 'Problem Description:', ['Coordination Details:', 'Bug Service Call:', '____', '---']),
            building_code: this.extractFieldValue(bodyText, ['Work Site:', 'WorkSite:', 'Site:']),
            building_address: this.extractFieldValue(bodyText, ['Work Site Address:', 'Site Address:', 'Address:']),
            job_trouble_type: this.extractFieldValue(bodyText, ['Alarm Type:', 'Trouble Type:']),
            priority: this.extractFieldValue(bodyText, ['Priority:']),
            summary: this.extractFieldValue(bodyText, ['Summary of Fault:', 'Trouble Summary:']),
            warranty: this.extractFieldValue(bodyText, ['Covered Under Warranty:']),
            po_number: this.extractFieldValue(bodyText, ['PO:', 'Service PO#']),
            coordination_details: this.extractMultiLineField(bodyText, 'Coordination Details:', ['Bug Service Call:', '____', '---'])
        };
    }

    getCleanEmailText(emailData) {
        let text = '';
        
        // Try different text sources in order of preference
        if (emailData.plainText) {
            text = emailData.plainText;
        } else if (emailData.body?.text) {
            text = emailData.body.text;
        } else if (emailData.body?.html) {
            text = this.htmlToPlainText(emailData.body.html);
        } else if (emailData.attachments && emailData.attachments.length > 0) {
            for (const attachment of emailData.attachments) {
                if (attachment.embeddedMessage) {
                    if (attachment.embeddedMessage.body?.text) {
                        text = attachment.embeddedMessage.body.text;
                        break;
                    } else if (attachment.embeddedMessage.body?.html) {
                        text = this.htmlToPlainText(attachment.embeddedMessage.body.html);
                        break;
                    }
                }
            }
        }
        
        console.log('Final extracted text length:', text.length);
        
        // If no text found, prompt user
        if (!text || text.trim().length === 0) {
            const userText = prompt('Email parsing failed. Please copy and paste the email content from Outlook:');
            if (userText) {
                text = userText;
            }
        }
        
        return this.preserveLineBreaks(text);
    }

    htmlToPlainText(html) {
        if (!html) return '';
        
        return html
            .replace(/<br\s*\/?>/gi, '\n')
            .replace(/<\/p>/gi, '\n\n')
            .replace(/<[^>]+>/g, '')
            .replace(/&nbsp;/g, ' ')
            .replace(/</g, '<')
            .replace(/>/g, '>')
            .replace(/&/g, '&')
            .replace(/"/g, '"')
            .replace(/&#039;/g, "'");
    }

    preserveLineBreaks(text) {
        if (!text || typeof text !== 'string') return text || '';
        
        return text
            .replace(/\r\n/g, '\n')  // Convert Windows line endings
            .replace(/\r/g, '\n');   // Convert Mac line endings
    }

    extractFieldValue(text, fieldLabels) {
        for (const label of fieldLabels) {
            const regex = new RegExp(`${this.escapeRegex(label)}\\s*([^\\r\\n]+)`, 'i');
            const match = text.match(regex);
            if (match && match[1]) {
                return match[1].trim();
            }
        }
        return '';
    }

    extractMultiLineField(text, fieldLabel, stopPatterns = []) {
        const regex = new RegExp(`${this.escapeRegex(fieldLabel)}\\s*([\\s\\S]*?)(?=${stopPatterns.map(this.escapeRegex).join('|')}|$)`, 'i');
        const match = text.match(regex);
        if (match && match[1]) {
            return match[1].trim().replace(/[ \t]+/g, ' ').replace(/\n\s*\n/g, '\n');
        }
        return '';
    }

    escapeRegex(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    extractJobNumberFromFilename(fileName = '') {
        if (fileName) {
            const match = fileName.match(/[P]\d{9}/i);
            if (match) return match[0];
        }
        return '';
    }

    extractJobName(subject, bodyText, fileName = '') {
        // Try subject first
        if (subject && subject.trim()) {
            return subject.replace(/^(Service Call:|Re:|Fwd?:|FW:)\s*/gi, '').trim();
        }
        
        // Extract from body text
        const serviceCallMatch = bodyText.match(/Service Call:\s*([^\n\r]+?)(?:\s+PO:|\n|\r|$)/i);
        if (serviceCallMatch) {
            return serviceCallMatch[1].trim();
        }
        
        // Fallback to filename
        if (fileName && fileName.includes('Service Call_')) {
            const fileMatch = fileName.match(/Service Call_\s*(.+?)\.msg$/i);
            if (fileMatch) {
                return fileMatch[1].trim().replace(/_/g, ' ');
            }
        }
        
        return 'Email Import';
    }

    async createJobFromEmail(emailData, fileName) {
        try {
            const app = window.WMSApplication;
            if (!app) throw new Error('Application not initialized');

            console.log(`Creating job from email: ${fileName}`, emailData);

            // Create a new job entry directly without using the form
            const jobNumber = emailData.job_number || `EMAIL-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

            // Ensure correct ticket exists
            const databaseService = app.getService('database');
            const ticket = await databaseService.ensureTicket(jobNumber, 1);

            const entryData = {
                ticketId: ticket.id,
                jobNumber: jobNumber,
                buildingCode: emailData.building_code || '',
                buildingAddress: emailData.building_address || '',
                jobName: emailData.job_name || 'Email Import',
                jobStartDate: app.state.focusedDate,
                jobStartTime: '',
                jobEndTime: '',
                jobParticipants: '',
                jobReferenceNumber: '',
                jobEscortDelay: '',
                jobHindrances: '',
                jobMaterialsUsed: '',
                jobMaterialsNeeded: '',
                jobAccessNeeded: '',
                jobProgrammingChanges: '',
                jobDispatchType: emailData.job_number && emailData.job_number.includes('SIM-T') ? 'Sim-T' : '',
                jobFieldStatus: '',
                jobFiledStatusNotes: '',
                jobFollowupRequired: '',
                jobDeviceNames: emailData.device_name || emailData.device_id || '',
                jobDeviceDetails: '',
                jobTroubleType: emailData.job_trouble_type || '',
                jobTroubleDescription: emailData.job_trouble_description || '',
                jobWorkDescription: '',
                jobTechnicalDetails: '',
                relatedTickets: '',
                deviceType: emailData.device_type || '',
                jobChangedFlag: false,
                createdAt: new Date().toISOString()
            };

            // Save directly to database
            const jobId = await databaseService.saveTicketEntry(entryData);

            // Clear cache for the current date to force refresh
            const cacheService = app.getService('cache');
            if (cacheService) {
                cacheService.invalidatePattern(`jobs:date:${app.state.focusedDate}`);
                cacheService.invalidatePattern(`entries:date:${app.state.focusedDate}`);
            }

            // Publish events to update UI
            this.eventBus.publish('job:saved', {
                jobId: jobId,
                jobData: entryData,
                date: app.state.focusedDate
            });

            console.log(`✅ Job created from ${fileName}: ${jobNumber} (ID: ${jobId})`);

            return jobId;

        } catch (error) {
            console.error('Failed to create job from email:', error);
            throw error;
        }
    }

    populateFormFromEmail(emailData) {
        console.log('Populating form with email data:', emailData);
        
        // Map extracted email fields to form fields
        const fieldMapping = {
            'job_number': emailData.job_number,
            'job_name': emailData.job_name,
            'device_id': emailData.device_name,
            'device_type': emailData.device_type,
            'job_trouble_description': emailData.job_trouble_description,
            'building_code': emailData.building_code,
            'building_address': emailData.building_address,
            'job_trouble_type': emailData.job_trouble_type
        };
        
        Object.entries(fieldMapping).forEach(([fieldId, value]) => {
            if (value) {
                const element = document.getElementById(fieldId);
                if (element) {
                    element.value = value;
                }
            }
        });
        
        // Set default dispatch type for email imports
        if (emailData.job_number && emailData.job_number.includes('SIM-T')) {
            const dispatchEl = document.getElementById('job_dispatch_type');
            if (dispatchEl) {
                dispatchEl.value = 'Sim-T';
            }
        }
        
        // Set current date
        const app = window.WMSApplication;
        const dateEl = document.getElementById('job_start_date');
        if (dateEl && app) {
            dateEl.value = app.state.focusedDate;
        }
        
        // Auto-resize textareas
        const textareas = document.querySelectorAll('textarea');
        textareas.forEach(textarea => {
            if (textarea.value) {
                textarea.style.height = 'auto';
                textarea.style.height = textarea.scrollHeight + 'px';
            }
        });
        
        // Trigger validation
        const validationService = app?.getService('validation');
        if (validationService) {
            validationService.highlightRequiredFields();
        }
    }

    // Handle email import from external sources (Email Inspector, etc.)
    handleEmailImportMessage(event) {
        console.log('📧 Received postMessage:', event.data);

        if (event.data && event.data.type === 'EMAIL_IMPORT_DATA') {
            try {
                const emailData = event.data.data;
                console.log('📧 Processing email import data:', emailData);

                this.eventBus.publish('ui:statusUpdate', { 
                    message: 'Processing imported email data...',
                    type: 'info' 
                });

                this.populateFormFromEmail(emailData);
                
                // Auto-save after population
                setTimeout(async () => {
                    try {
                        await this.jobService.saveCurrentJob();
                        this.eventBus.publish('ui:statusUpdate', { 
                            message: 'Email data imported successfully from Email Inspector!',
                            type: 'success' 
                        });
                    } catch (error) {
                        this.eventBus.publish('error:occurred', { 
                            message: error.message, 
                            operation: 'saveEmailImport' 
                        });
                    }
                }, 100);

                localStorage.removeItem('emailInspectorData');
                console.log('✅ Email import completed successfully');

            } catch (error) {
                console.error('❌ Email import failed:', error);
                this.eventBus.publish('error:occurred', { 
                    message: error.message, 
                    operation: 'handleEmailImportMessage' 
                });
            }
        }
    }

    // Check for stored email data on initialization
    async checkForStoredEmailData() {
        const emailData = localStorage.getItem('emailInspectorData');
        if (emailData) {
            console.log('📧 Found email import data in localStorage');
            try {
                const parsedData = JSON.parse(emailData);
                console.log('📧 Processing stored email data:', parsedData);

                this.eventBus.publish('ui:statusUpdate', { 
                    message: 'Processing stored email data...',
                    type: 'info' 
                });
                
                this.populateFormFromEmail(parsedData);
                await this.jobService.saveCurrentJob();

                this.eventBus.publish('ui:statusUpdate', { 
                    message: 'Email data imported successfully from Email Inspector!',
                    type: 'success' 
                });

                localStorage.removeItem('emailInspectorData');
                console.log('✅ localStorage email import completed successfully');

            } catch (error) {
                console.error('❌ localStorage email import failed:', error);
                this.eventBus.publish('error:occurred', { 
                    message: error.message, 
                    operation: 'checkForStoredEmailData' 
                });
                localStorage.removeItem('emailInspectorData');
            }
        }
    }
}
