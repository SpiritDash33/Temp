class DBStorage {
    constructor() {
        this.dbName = 'ServiceLogDB';
        this.version = 1;
        this.db = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.version);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve();
            };
            
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                if (!db.objectStoreNames.contains('jobs')) {
                    const store = db.createObjectStore('jobs', { keyPath: 'id' });
                    store.createIndex('job_start_date', 'job_start_date', { unique: false });
                    store.createIndex('job_name', 'job_name', { unique: false });
                }
            };
        });
    }

    async saveJob(jobData) {
        const transaction = this.db.transaction(['jobs'], 'readwrite');
        const store = transaction.objectStore('jobs');
        return store.put(jobData);
    }

    async getAllJobs() {
        const transaction = this.db.transaction(['jobs'], 'readonly');
        const store = transaction.objectStore('jobs');
        return new Promise((resolve, reject) => {
            const request = store.getAll();
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getJobById(id) {
        const transaction = this.db.transaction(['jobs'], 'readonly');
        const store = transaction.objectStore('jobs');
        return new Promise((resolve, reject) => {
            const request = store.get(id);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async deleteJob(id) {
        const transaction = this.db.transaction(['jobs'], 'readwrite');
        const store = transaction.objectStore('jobs');
        return store.delete(id);
    }

    async getJobsByDate(date) {
        const transaction = this.db.transaction(['jobs'], 'readonly');
        const store = transaction.objectStore('jobs');
        const index = store.index('job_start_date');
        return new Promise((resolve, reject) => {
            const request = index.getAll(date);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
}