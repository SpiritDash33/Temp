/**
 * Enhanced EML Parser with Header Reconstruction and MIME Recovery
 * Extends base EML parser with corruption recovery and error handling
 * Handles broken MIME structures, malformed headers, and partial emails
 */
class EnhancedEMLParser extends EMLParser {
    constructor(options = {}) {
        super();

        this.headerRecoveryOptions = {
            reconstructHeaders: options.reconstructHeaders || false,
            lenientParsing: options.lenientParsing || false,
            skipCorruptedHeaders: options.skipCorruptedHeaders !== false,
            repairMultpart: options.repairMultpart || false,
            autoDetectBoundaries: options.autoDetectBoundaries || false,
            healBrokenMIME: options.healBrokenMIME !== false,
            maximumHeaderFailures: options.maximumHeaderFailures || 20
        };

        this.corruptedHeaders = new Map();
        this.headerFailureCount = 0;
        this.mimeRecoveryLog = [];
        this.boundaryRecoveryAttempts = 0;
    }

    async parseFile(file, recoveryContext = null) {
        // Reset recovery state for new file
        this.resetEMLRecoveryState();

        this.mimeRecoveryLog.push({
            level: 'info',
            message: 'Starting enhanced EML parsing with recovery options',
            recoveryOptions: this.headerRecoveryOptions
        });

        try {
            // Enhanced parsing with recovery
            const email = await this.parseEMLWithRecovery(file);

            // Add recovery metadata
            email.mimeRecovery = {
                activated: true,
                corruptedHeaders: Object.fromEntries(this.corruptedHeaders),
                recoveryLog: this.mimeRecoveryLog,
                headerRecoveryRate: this.calculateHeaderRecoveryRate(email),
                recoveryResults: this.getMIMERecoveryResults()
            };

            this.mimeRecoveryLog.push({
                level: 'success',
                message: 'EML recovery completed',
                summary: {
                    totalHeaders: email.headers.size,
                    corruptedHeaders: this.corruptedHeaders.size,
                    mimePartsRecovered: email.attachments.length,
                    success: true
                }
            });

            return email;

        } catch (error) {
            this.mimeRecoveryLog.push({
                level: 'error',
                message: `EML recovery failed: ${error.message}`,
                failurePoint: 'main_parsing'
            });

            // Return minimal recovery if possible
            return this.createMinimalRecoveryEmail(file, error);
        }
    }

    async parseEMLWithRecovery(file) {
        let content;

        try {
            content = await file.text();
        } catch (error) {
            throw new Error(`File reading failed: ${error.message}`);
        }

        // Enhanced MIME parsing with recovery
        return await this.parseEMLContentWithRecovery(content);
    }

    async parseEMLContentWithRecovery(content) {
        if (!content || typeof content !== 'string') {
            throw new Error('Invalid EML content');
        }

        try {
            // Phase 1: Enhanced header parsing with recovery
            const { headers, bodyStart } = this.parseHeadersWithRecovery(content);

            // Phase 2: Enhanced MIME body parsing
            const bodyContent = content.substring(bodyStart);

            // Create email object
            const email = this.createEmailFromHeaders(headers);

            // Phase 3: Process MIME body with recovery
            const processedBody = await this.processMIMEBodyWithRecovery(bodyContent, headers, email);

            // Phase 4: Merge and validate
            this.mergeProcessedBody(email, processedBody);

            return email;

        } catch (error) {
            this.mimeRecoveryLog.push({
                level: 'error',
                message: `Content parsing failed: ${error.message}`,
                recoveryAttempt: this.headerRecoveryOptions.reconstructHeaders
            });

            throw error;
        }
    }

    parseHeadersWithRecovery(content) {
        const headers = new Map();
        let currentPos = 0;
        let validHeaders = 0;
        let skippedHeaders = 0;

        // Find first empty line (header/body separator)
        const bodySeparatorMatch = content.match(/(?:\r?\n){2}/);
        const maxHeaderEnd = bodySeparatorMatch ? bodySeparatorMatch.index : Math.min(20480, content.length); // 20KB max headers

        while (currentPos < maxHeaderEnd) {
            try {
                const headerResult = this.parseSingleHeaderWithRecovery(content, currentPos, maxHeaderEnd);

                if (headerResult.header) {
                    const { name, value } = headerResult.header;

                    // Handle duplicate headers
                    if (headers.has(name)) {
                        const existing = headers.get(name);
                        if (Array.isArray(existing)) {
                            existing.push(value);
                        } else {
                            headers.set(name, [existing, value]);
                        }
                    } else {
                        headers.set(name, value);
                    }

                    validHeaders++;
                } else if (headerResult.isCorruptedLine) {
                    skippedHeaders++;
                    this.logCorruptedHeader(headerResult.rawLine, 'unparseable_line');
                }

                if (headerResult.endsHeaders) break;

                // Move to next line
                currentPos = headerResult.nextPos;

            } catch (error) {
                this.logCorruptedHeader('<unknown>', `parsing_error: ${error.message}`);
                skippedHeaders++;

                // Try to find next potential header line
                const nextLineMatch = content.substr(currentPos + 1).match(/\r?\n([^\r\n]+)/);
                if (nextLineMatch) {
                    currentPos += 1 + nextLineMatch.index;
                } else {
                    break;
                }
            }

            // Prevent infinite loops
            if (currentPos >= maxHeaderEnd || skippedHeaders > this.headerRecoveryOptions.maximumHeaderFailures) {
                break;
            }
        }

        // Try header reconstruction if needed
        if (this.headerRecoveryOptions.reconstructHeaders &&
            (headers.size === 0 || this.corruptedHeaders.size > 0)) {
            this.reconstructMissingHeaders(headers, content);
        }

        const bodyStart = Math.min(currentPos + 2, content.length); // +2 for \r?\n\r?\n

        this.mimeRecoveryLog.push({
            level: 'info',
            message: `Header parsing completed: ${headers.size} valid, ${skippedHeaders} skipped`,
            corruptedHeaders: this.corruptedHeaders.size
        });

        return { headers, bodyStart };
    }

    parseSingleHeaderWithRecovery(content, startPos, maxPos) {
        // Find end of current line
        let lineEnd = content.indexOf('\n', startPos);
        if (lineEnd === -1 || lineEnd > maxPos) {
            lineEnd = maxPos;
        }

        const currentLine = content.substring(startPos, lineEnd);

        // Check for header continuation (starts with whitespace)
        if (currentLine.match(/^\s+/)) {
            return {
                header: null,
                nextPos: lineEnd + 1,
                isCorruptedLine: false,
                endsHeaders: false,
                rawLine: currentLine
            };
        }

        // Check for empty line (end of headers)
        if (currentLine.trim() === '') {
            return {
                header: null,
                nextPos: lineEnd + 1,
                isCorruptedLine: false,
                endsHeaders: true,
                rawLine: currentLine
            };
        }

        // Try normal header parsing first
        const colonIndex = currentLine.indexOf(':');
        if (colonIndex > 0) {
            const name = currentLine.substring(0, colonIndex).trim();
            const value = currentLine.substring(colonIndex + 1).trim();

            if (name && value) {
                // Validate header name (basic validation)
                if (this.isValidHeaderName(name)) {
                    return {
                        header: { name, value },
                        nextPos: lineEnd + 1,
                        isCorruptedLine: false,
                        endsHeaders: false,
                        rawLine: currentLine
                    };
                }
            }
        }

        // Header parsing failed - try recovery
        if (this.headerRecoveryOptions.reconstructHeaders) {
            const recovery = this.attemptHeaderRecovery(currentLine);

            if (recovery) {
                return {
                    header: recovery.header,
                    nextPos: lineEnd + 1,
                    isCorruptedLine: false,
                    endsHeaders: false,
                    rawLine: currentLine
                };
            }
        }

        // Header is unrecoverable
        return {
            header: null,
            nextPos: lineEnd + 1,
            isCorruptedLine: true,
            endsHeaders: false,
            rawLine: currentLine
        };
    }

    attemptHeaderRecovery(line) {
        // Try various header recovery strategies

        // Strategy 1: Common typo fixes
        const commonTypos = {
            'form:': 'From:',
            'to:': 'To:',
            'subject:': 'Subject:',
            'date:': 'Date:'
        };

        for (const [typo, correction] of Object.entries(commonTypos)) {
            if (line.toLowerCase().startsWith(typo.toLowerCase())) {
                const correctedLine = correction + line.substring(typo.length);
                const colonIndex = correctedLine.indexOf(':');
                if (colonIndex > 0) {
                    const name = correctedLine.substring(0, colonIndex).trim();
                    const value = correctedLine.substring(colonIndex + 1).trim();

                    this.mimeRecoveryLog.push({
                        level: 'info',
                        message: `Header recovered from typo: "${line.trim()}" -> "${correctedLine}"`
                    });

                    return {
                        header: { name, value },
                        recoveredFrom: 'typographic_correction'
                    };
                }
            }
        }

        // Strategy 2: Missing colon reconstruction
        if (line.length < 80 && !line.includes(':') && line.match(/^[A-Za-z-_\s]+$/)) {
            // Look for email-like patterns to identify field
            if (line.match(/[@.]/) || this.looksLikeEmailAddress(line.trim())) {
                this.mimeRecoveryLog.push({
                    level: 'info',
                    message: `Header recovered - missing colon: "${line}" -> "To:${line}"`
                });

                return {
                    header: { name: 'To', value: line.trim() },
                    recoveredFrom: 'missing_colon'
                };
            }
        }

        return null;
    }

    looksLikeEmailAddress(text) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(text);
    }

    isValidHeaderName(name) {
        // RFC 5322 header name validation
        return /^[A-Za-z0-9-]+(\([^\)]*\))?$/.test(name) ||
               name.length > 0 && name.length <= 100; // Lenient fallback
    }

    reconstructMissingHeaders(headers, content) {
        // Try to reconstruct essential headers from email content

        // Try to find Subject in content
        if (!headers.has('Subject')) {
            const subjectMatch = content.match(/Subject:\s*([^\r\n]*)/i);
            if (subjectMatch) {
                headers.set('Subject', subjectMatch[1].trim());
                this.mimeRecoveryLog.push({
                    level: 'info',
                    message: 'Subject header reconstructed from content'
                });
            }
        }

        // Try to find From in content
        if (!headers.has('From')) {
            const fromMatch = content.match(/From:\s*([^\r\n]*)/i);
            if (fromMatch) {
                headers.set('From', fromMatch[1].trim());
                this.mimeRecoveryLog.push({
                    level: 'info',
                    message: 'From header reconstructed from content'
                });
            }
        }

        // Try to find Date in content
        if (!headers.has('Date')) {
            const dateMatch = content.match(/Date:\s*([^\r\n]*)/i);
            if (dateMatch) {
                headers.set('Date', dateMatch[1].trim());
                this.mimeRecoveryLog.push({
                    level: 'info',
                    message: 'Date header reconstructed from content'
                });
            }
        }

        // Add MIME-Version if missing
        if (!headers.has('MIME-Version')) {
            headers.set('MIME-Version', '1.0');
        }

        // Add Content-Type if missing
        if (!headers.has('Content-Type')) {
            headers.set('Content-Type', 'text/plain; charset=us-ascii');
        }
    }

    logCorruptedHeader(line, reason) {
        this.corruptedHeaders.set(line.trim(), reason);
        this.headerFailureCount++;

        this.mimeRecoveryLog.push({
            level: 'warning',
            message: `Corrupted header: "${line.trim()}" - ${reason}`,
            corruptedLine: line.trim(),
            reason: reason
        });
    }

    createEmailFromHeaders(headers) {
        const email = this.createBlankEmail();

        // Extract basic headers
        this.extractBasicHeadersRecovery(headers, email);

        return email;
    }

    createBlankEmail() {
        return {
            subject: '',
            from: { name: '', email: '' },
            to: [],
            cc: [],
            bcc: [],
            date: null,
            body: { text: '', html: '', enriched: '' },
            attachments: [],
            threads: [],
            headers: new Map(),
            metadata: {
                messageId: '',
                inReplyTo: '',
                references: '',
                contentType: 'text/plain',
                transferEncoding: '7bit',
                charset: 'us-ascii',
                boundary: '',
                mimeVersion: ''
            }
        };
    }

    async processMIMEBodyWithRecovery(bodyContent, headers, email) {
        try {
            // Try normal MIME processing first
            const contentTypeHeader = headers.get('Content-Type') || 'text/plain';
            const contentType = this.parseContentType(contentTypeHeader);

            return await this.processMessageBody(bodyContent, contentType, headers);

        } catch (error) {
            if (!this.headerRecoveryOptions.repairMultpart) {
                throw error;
            }

            this.mimeRecoveryLog.push({
                level: 'warning',
                message: `MIME processing failed: ${error.message}, attempting repair`
            });

            return this.processMIMEBodyWithRepair(bodyContent, headers);
        }
    }

    async processMIMEBodyWithRepair(bodyContent, headers) {
        const result = {
            text: '',
            html: '',
            enriched: '',
            attachments: [],
            threads: []
        };

        // Try to auto-detect and repair MIME structure
        const repairedContent = this.repairMIMEBody(bodyContent, headers);

        if (repairedContent.trim() !== bodyContent.trim()) {
            this.mimeRecoveryLog.push({
                level: 'info',
                message: 'MIME body structure repaired',
                originalLength: bodyContent.length,
                repairedLength: repairedContent.length
            });
        }

        // Try to parse the repaired content
        const contentTypeHeader = headers.get('Content-Type') || 'text/plain';
        const contentType = this.parseContentType(contentTypeHeader);

        try {
            const repairResult = await this.processMessageBody(repairedContent, contentType, headers);
            return repairResult;
        } catch (repairError) {
            this.mimeRecoveryLog.push({
                level: 'warning',
                message: `MIME repair failed: ${repairError.message}, falling back to plain text`
            });

            // Fallback: treat as plain text
            result.text = this.convertCharset(repairedContent, 'us-ascii') || repairedContent;
            return result;
        }
    }

    repairMIMEBody(content, headers) {
        let repaired = content;

        // Fix 1: Try to reconstruct missing boundary markers
        if (this.headerRecoveryOptions.autoDetectBoundaries) {
            repaired = this.repairMIMEBoundaries(repaired, headers);
        }

        // Fix 2: Try to fix truncated Content-Type headers
        repaired = this.repairContentTypeHeaders(repaired);

        // Fix 3: Try to fix encoding issues
        repaired = this.repairMIMEEncoding(repaired);

        // Fix 4: Try to reconstruct basic MIME structure if completely broken
        if (!repaired.includes('--') && repaired.length > 1000) {
            repaired = this.reconstructBasicMIMEStructure(repaired);
        }

        return repaired;
    }

    repairMIMEBoundaries(content, headers) {
        // Try to auto-detect multipart boundaries
        const boundaryRegex = /boundary="([^"]+)"/i;
        const boundaryMatch = content.match(boundaryRegex);

        if (!boundaryMatch) {
            // Try to generate boundary from content patterns
            const boundary = this.generateBoundaryFromContent(content);

            if (boundary) {
                this.mimeRecoveryLog.push({
                    level: 'info',
                    message: `Generated boundary for corrupted MIME: "${boundary}"`
                });

                // Add boundary to Content-Type if missing
                if (!headers.has('Content-Type')) {
                    headers.set('Content-Type', `multipart/mixed; boundary="${boundary}"`);
                }

                return this.insertBoundaryMarkers(content, boundary);
            }
        }

        return content;
    }

    generateBoundaryFromContent(content) {
        // Look for common boundary-like patterns in content
        const patterns = [
            /-{15,}.*-{15,}/g,  // Long dash sequences
            /Content-Type:/gi,   // Multiple Content-Type headers
            /=[\w]{10,}=/g      // Base64 padding patterns
        ];

        // Find natural separation points
        const lines = content.split(/\r?\n/);
        const boundaries = [];

        for (let i = 0; i < lines.length - 1; i++) {
            const line = lines[i].trim();

            // Look for lines that could be boundaries
            if (line.startsWith('--') && line.length > 10 && line.length < 100 &&
                /^[A-Za-z0-9_\-=]+$/.test(line.substring(2))) {
                boundaries.push(line);
            }
        }

        // Use the most common pattern as boundary
        if (boundaries.length > 0) {
            return boundaries[0];
        }

        // Generate synthetic boundary
        return `----=_NextPart_${Date.now().toString(36)}`;
    }

    insertBoundaryMarkers(content, boundary) {
        // Try to intelligently insert boundary markers
        const lines = content.split(/\r?\n/);
        const markedLines = [];
        let inAttachment = false;

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];

            // Look for Content-Type to mark attachment starts
            if (line.toLowerCase().startsWith('content-type:')) {
                if (inAttachment) {
                    // End previous attachment
                    markedLines.push('', `${boundary}--`);
                }

                // Start new attachment
                markedLines.push(`${boundary}`, line);
                inAttachment = true;
            } else {
                markedLines.push(line);
            }
        }

        // Close final boundary if needed
        if (inAttachment) {
            markedLines.push('', `${boundary}--`);
        }

        return markedLines.join('\r\n');
    }

    repairContentTypeHeaders(content) {
        // Look for lines that look like they should have Content-Type
        const lines = content.split(/\r?\n/);
        const repaired = [];

        for (let i = 0; i < lines.length; i++) {
            let line = lines[i];

            // Look for broken Content-Type headers
            if (line.toLowerCase().includes('content-type') &&
                !line.includes(':') &&
                line.length < 100) {

                // Try to reconstruct header
                if (line.toLowerCase().includes('application') ||
                    line.toLowerCase().includes('text') ||
                    line.toLowerCase().includes('multipart')) {

                    line = `Content-Type: ${line}`;
                    this.mimeRecoveryLog.push({
                        level: 'info',
                        message: `Reconstructed Content-Type header: ${line}`
                    });
                }
            }

            // Look for consecutive content without headers
            if (line === '' && i > 0 && repaired[repaired.length - 1] !== '') {
                // Check if next non-empty lines look like content
                let nextNonEmptyIndex = i + 1;
                while (nextNonEmptyIndex < lines.length && lines[nextNonEmptyIndex].trim() === '') {
                    nextNonEmptyIndex++;
                }

                if (nextNonEmptyIndex < lines.length) {
                    const nextLine = lines[nextNonEmptyIndex];

                    // Add Content-Type if it looks like we're missing it
                    if (nextLine.length > 0 && !nextLine.toLowerCase().match(/^(content|mime|transfer)-/)) {
                        repaired.push('', 'Content-Type: text/plain; charset=us-ascii');
                        this.mimeRecoveryLog.push({
                            level: 'info',
                            message: 'Added missing Content-Type header'
                        });
                    }
                }
            }

            repaired.push(line);
        }

        return repaired.join('\r\n');
    }

    repairMIMEEncoding(content) {
        // Try to fix common encoding issues
        let repaired = content;

        // Fix truncated base64
        if (repaired.match(/^([A-Za-z0-9+/=]+)=*$/) &&
            repaired.includes('=') &&
            repaired.length % 4 !== 0) {

            // Pad base64 to correct length
            const padding = (4 - (repaired.length % 4)) % 4;
            repaired += '='.repeat(padding);

            this.mimeRecoveryLog.push({
                level: 'info',
                message: `Fixed base64 padding (${padding} padding chars added)`
            });
        }

        return repaired;
    }

    reconstructBasicMIMEStructure(content) {
        // For completely broken MIME, try to reconstruct basic structure
        const boundary = `----=_BrokenMIME_${Date.now()}`;

        const reconstructed =
            `Content-Type: multipart/mixed; boundary="${boundary}"\r\n\r\n` +
            `--${boundary}\r\n` +
            `Content-Type: text/plain; charset=us-ascii\r\n\r\n` +
            content +
            `\r\n--${boundary}--\r\n`;

        this.mimeRecoveryLog.push({
            level: 'info',
            message: 'Reconstructed basic MIME structure for completely broken content'
        });

        return reconstructed;
    }

    mergeProcessedBody(email, processedBody) {
        email.body.text = processedBody.text || '';
        email.body.html = processedBody.html || '';
        email.body.enriched = processedBody.enriched || '';
        email.attachments = processedBody.attachments || [];
        email.threads = processedBody.threads || [];
    }

    calculateHeaderRecoveryRate(email) {
        const totalHeaders = email.headers.size;
        const corruptedHeaders = this.corruptedHeaders.size;

        if (totalHeaders === 0) return 100;

        const recoveredHeaders = totalHeaders; // Recovery already accounted for
        return Math.round((recoveredHeaders / (totalHeaders + corruptedHeaders)) * 100);
    }

    getMIMERecoveryResults() {
        return {
            headerFailures: this.headerFailureCount,
            corruptedHeaders: this.corruptedHeaders.size,
            boundaryRecoveryAttempts: this.boundaryRecoveryAttempts,
            recoveryEffective: this.corruptedHeaders.size <= this.headerRecoveryOptions.maximumHeaderFailures,
            mimeStructureRepaired: this.mimeRecoveryLog.some(log => log.message.includes('repaired'))
        };
    }

    createMinimalRecoveryEmail(file, error) {
        // Create a minimal email object when everything fails
        const minimal = this.createBlankEmail();

        minimal.subject = 'Email Recovery Failed';
        minimal.body.text = `Failed to parse email file: ${file.name}\nError: ${error.message}`;
        minimal.metadata.recoveryFailed = true;
        minimal.metadata.originalError = error.message;

        return minimal;
    }

    resetEMLRecoveryState() {
        this.corruptedHeaders.clear();
        this.headerFailureCount = 0;
        this.mimeRecoveryLog = [];
        this.boundaryRecoveryAttempts = 0;
    }
}

// Browser/Node.js compatibility
if (typeof window !== 'undefined') {
    window.EnhancedEMLParser = EnhancedEMLParser;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = EnhancedEMLParser;
}
