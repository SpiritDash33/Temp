/**
 * Synthetic Email File Generator
 * Creates RFC5322/MIME compliant test files for comprehensive parser testing
 */
class SyntheticFileGenerator {
    constructor(options = {}) {
        this.debug = options.debug || false;
        this.outputDir = options.outputDir || '/TestSuite/SyntheticTests/';
        
        // Test data templates
        this.domains = ['example.com', 'test.org', 'sample.net', 'demo.edu'];
        this.names = ['John Doe', 'Jane Smith', 'Alice Johnson', 'Bob Wilson', 'Carol Brown'];
        this.subjects = [
            'Meeting Reminder',
            'Project Status Update', 
            'Weekly Report',
            'Document Review',
            'System Notification'
        ];
        
        if (this.debug) {
            console.log('SyntheticFileGenerator initialized');
        }
    }

    /**
     * Generate complete test suite
     */
    async generateTestSuite() {
        console.log('🏗️  Generating Synthetic Test Suite...');
        
        const categories = {
            core: this.generateCoreTests.bind(this),
            advanced: this.generateAdvancedTests.bind(this),
            streaming: this.generateStreamingTests.bind(this),
            smime: this.generateSMIMETests.bind(this),
            errors: this.generateErrorTests.bind(this)
        };
        
        const generatedFiles = [];
        
        for (const [category, generator] of Object.entries(categories)) {
            console.log(`📂 Generating ${category} tests...`);
            const files = await generator();
            generatedFiles.push(...files);
        }
        
        console.log(`✅ Generated ${generatedFiles.length} synthetic test files`);
        return generatedFiles;
    }

    /**
     * Generate core RFC5322/MIME tests
     */
    async generateCoreTests() {
        const tests = [
            {
                name: 'simple-text.eml',
                generator: () => this.createSimpleTextEmail({
                    subject: 'Simple Text Email Test',
                    from: { name: 'Test Sender', email: 'sender@example.com' },
                    to: [{ name: 'Test Recipient', email: 'recipient@example.com' }],
                    body: 'This is a simple text email for basic RFC5322 parsing validation.\n\nIt contains multiple lines and basic formatting.'
                })
            },
            {
                name: 'multipart-alternative.eml',
                generator: () => this.createMultipartAlternativeEmail({
                    subject: 'Multipart Alternative Test',
                    from: { name: 'HTML Sender', email: 'html@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    textBody: 'This is the plain text version of the email.',
                    htmlBody: '<html><body><h1>HTML Version</h1><p>This is the <b>HTML</b> version of the email.</p></body></html>'
                })
            },
            {
                name: 'multipart-mixed.eml',
                generator: () => this.createMultipartMixedEmail({
                    subject: 'Multipart Mixed with Attachments',
                    from: { email: 'attachments@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'This email contains multiple attachments for testing.',
                    attachments: [
                        {
                            filename: 'test-document.txt',
                            contentType: 'text/plain',
                            content: 'This is a test document attachment.\nIt contains sample text data.'
                        },
                        {
                            filename: 'data.json',
                            contentType: 'application/json',
                            content: '{"test": true, "data": [1, 2, 3], "message": "JSON test file"}'
                        }
                    ]
                })
            },
            {
                name: 'nested-multipart.eml',
                generator: () => this.createNestedMultipartEmail({
                    subject: 'Nested Multipart Structure Test',
                    from: { email: 'nested@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    depth: 3
                })
            },
            {
                name: 'unicode-content.eml',
                generator: () => this.createUnicodeEmail({
                    subject: 'Unicode Content Test 🌍',
                    from: { name: '测试发送者', email: 'unicode@example.com' },
                    to: [{ name: 'Recipient', email: 'recipient@example.com' }],
                    body: 'This email contains Unicode content:\n\n' +
                           '🚀 Rocket emoji\n' +
                           '中文内容 (Chinese content)\n' +
                           'العربية (Arabic content)\n' +
                           'русский (Russian content)\n' +
                           '日本語 (Japanese content)'
                })
            },
            {
                name: 'quoted-printable.eml',
                generator: () => this.createQuotedPrintableEmail({
                    subject: 'Quoted-Printable Encoding Test',
                    from: { email: 'encoding@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'This email tests Quoted-Printable encoding.\n\n' +
                           'Special characters: =20 (space), =3D (equals), =0A (newline)\n' +
                           'Long lines that need to be wrapped and encoded properly.'
                })
            }
        ];

        return this.generateTestFiles(tests, 'Core');
    }

    /**
     * Generate advanced MIME tests
     */
    async generateAdvancedTests() {
        const tests = [
            // Nested Email Tests
            {
                name: 'nested-eml-message.eml',
                generator: () => this.createNestedEmailMessage({
                    subject: 'Forwarded Email with Nested Message',
                    from: { name: 'Email Forwarder', email: 'forwarder@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'Please see the forwarded email below.',
                    nestedEmail: {
                        subject: 'Original Message Subject',
                        from: { name: 'Original Sender', email: 'original@example.com' },
                        to: [{ email: 'first-recipient@example.com' }],
                        body: 'This is the content of the original nested email message.',
                        date: '2025-09-16T10:30:00Z'
                    }
                })
            },
            {
                name: 'deeply-nested-emails.eml',
                generator: () => this.createDeeplyNestedEmails({
                    subject: 'Email Thread with Deep Nesting',
                    nestingLevels: 4,
                    threadSubject: 'Re: Important Project Discussion'
                })
            },
            {
                name: 'embedded-msg-attachment.eml',
                generator: () => this.createEmbeddedMSGAttachment({
                    subject: 'Email with Embedded MSG File',
                    from: { email: 'msg-sender@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'This email contains an embedded .msg file as an attachment.',
                    embeddedMsgSubject: 'Embedded Message Content',
                    embeddedMsgBody: 'This content is inside the embedded MSG file.'
                })
            },

            // Rich HTML Content Tests
            {
                name: 'rich-html-email.eml',
                generator: () => this.createRichHTMLEmail({
                    subject: 'Rich HTML Email with Complex Content',
                    from: { name: 'HTML Newsletter', email: 'newsletter@example.com' },
                    to: [{ email: 'subscriber@example.com' }],
                    htmlFeatures: ['tables', 'css', 'images', 'links', 'forms']
                })
            },
            {
                name: 'html-with-embedded-images.eml',
                generator: () => this.createHTMLWithEmbeddedImages({
                    subject: 'HTML Email with Inline Images',
                    from: { email: 'marketing@example.com' },
                    to: [{ email: 'customer@example.com' }],
                    imageCount: 3
                })
            },
            {
                name: 'html-multipart-related.eml',
                generator: () => this.createHTMLMultipartRelated({
                    subject: 'Complex HTML Email Structure',
                    from: { email: 'complex@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    relatedParts: ['css', 'images', 'scripts']
                })
            },

            // XML Content Tests
            {
                name: 'xml-data-attachment.eml',
                generator: () => this.createXMLDataEmail({
                    subject: 'Email with XML Data',
                    from: { email: 'data@example.com' },
                    to: [{ email: 'analyst@example.com' }],
                    xmlType: 'generic',
                    xmlContent: this.generateSampleXML()
                })
            },
            {
                name: 'rss-feed-attachment.eml',
                generator: () => this.createXMLDataEmail({
                    subject: 'RSS Feed Data',
                    from: { email: 'feeds@example.com' },
                    to: [{ email: 'subscriber@example.com' }],
                    xmlType: 'rss',
                    xmlContent: this.generateRSSFeed()
                })
            },
            {
                name: 'soap-xml-message.eml',
                generator: () => this.createXMLDataEmail({
                    subject: 'SOAP XML Message',
                    from: { email: 'webservice@example.com' },
                    to: [{ email: 'client@example.com' }],
                    xmlType: 'soap',
                    xmlContent: this.generateSOAPMessage()
                })
            },

            // Mixed Content Tests
            {
                name: 'html-xml-mixed.eml',
                generator: () => this.createMixedContentEmail({
                    subject: 'Mixed HTML and XML Content',
                    from: { email: 'mixed@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    contentTypes: ['html', 'xml', 'pdf']
                })
            },

            // Traditional Advanced MIME Tests
            {
                name: 'calendar-ics.eml',
                generator: () => this.createCalendarEmail({
                    subject: 'Meeting Invitation',
                    from: { name: 'Calendar System', email: 'calendar@example.com' },
                    to: [{ email: 'attendee@example.com' }],
                    event: {
                        summary: 'Project Review Meeting',
                        dtstart: '20251017T140000Z',
                        dtend: '20251017T150000Z',
                        location: 'Conference Room A',
                        description: 'Monthly project review and planning session'
                    }
                })
            },
            {
                name: 'vcard-contact.eml',
                generator: () => this.createVCardEmail({
                    subject: 'Contact Information',
                    from: { name: 'Contact Manager', email: 'contacts@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    contact: {
                        fn: 'John Business',
                        org: 'Example Corp',
                        email: 'john.business@example.com',
                        tel: '+1-555-123-4567',
                        title: 'Senior Manager'
                    }
                })
            },
            {
                name: 'pdf-attachment.eml',
                generator: () => this.createPDFAttachmentEmail({
                    subject: 'Document Attachment Test',
                    from: { email: 'documents@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'Please find the attached PDF document for review.',
                    pdfContent: this.generateSyntheticPDF()
                })
            },
            {
                name: 'image-attachment.eml',
                generator: () => this.createImageAttachmentEmail({
                    subject: 'Image Attachment Test',
                    from: { email: 'images@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'This email contains a test image attachment.',
                    imageContent: this.generateSyntheticImage()
                })
            }
        ];

        return this.generateTestFiles(tests, 'Advanced-MIME');
    }

    /**
     * Generate streaming performance tests
     */
    async generateStreamingTests() {
        const tests = [
            {
                name: 'large-body-1mb.eml',
                generator: () => this.createLargeBodyEmail({
                    subject: 'Large Body Test (1MB)',
                    targetSize: 1 * 1024 * 1024 // 1MB
                })
            },
            {
                name: 'large-body-10mb.eml',
                generator: () => this.createLargeBodyEmail({
                    subject: 'Large Body Test (10MB - Streaming)',
                    targetSize: 10 * 1024 * 1024 // 10MB
                })
            },
            {
                name: 'many-attachments-50.eml',
                generator: () => this.createManyAttachmentsEmail({
                    subject: 'Many Attachments Test (50 files)',
                    attachmentCount: 50,
                    attachmentSize: 1024 // 1KB each
                })
            },
            {
                name: 'deep-nested-mime.eml',
                generator: () => this.createDeepNestedEmail({
                    subject: 'Deep MIME Nesting Test',
                    nestingDepth: 8
                })
            }
        ];

        return this.generateTestFiles(tests, 'Streaming');
    }

    /**
     * Generate S/MIME cryptographic tests
     */
    async generateSMIMETests() {
        const tests = [
            {
                name: 'smime-signed.eml',
                generator: () => this.createSMIMESignedEmail({
                    subject: 'S/MIME Signed Email Test',
                    from: { email: 'secure@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'This email is digitally signed for authenticity verification.'
                })
            },
            {
                name: 'smime-detached-signature.eml',
                generator: () => this.createSMIMEDetachedEmail({
                    subject: 'S/MIME Detached Signature Test',
                    from: { email: 'secure@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'This email has a detached PKCS#7 signature.'
                })
            }
        ];

        return this.generateTestFiles(tests, 'SMIME');
    }

    /**
     * Generate error handling tests
     */
    async generateErrorTests() {
        const tests = [
            {
                name: 'malformed-headers.eml',
                generator: () => this.createMalformedHeaderEmail()
            },
            {
                name: 'invalid-boundary.eml',
                generator: () => this.createInvalidBoundaryEmail()
            },
            {
                name: 'corrupted-base64.eml',
                generator: () => this.createCorruptedBase64Email()
            },
            {
                name: 'truncated-file.eml',
                generator: () => this.createTruncatedEmail()
            }
        ];

        return this.generateTestFiles(tests, 'Error-Conditions');
    }

    /**
     * Generate test files from definitions
     */
    async generateTestFiles(testDefinitions, category) {
        const generatedFiles = [];
        
        for (const testDef of testDefinitions) {
            try {
                const content = await testDef.generator();
                const filePath = `${this.outputDir}${category}/${testDef.name}`;
                
                generatedFiles.push({
                    name: testDef.name,
                    path: filePath,
                    content: content,
                    category: category
                });
                
                if (this.debug) {
                    console.log(`  ✅ Generated: ${testDef.name}`);
                }
                
            } catch (error) {
                console.warn(`  ⚠️  Failed to generate ${testDef.name}: ${error.message}`);
            }
        }
        
        return generatedFiles;
    }

    // ============================================================================
    // EMAIL GENERATORS
    // ============================================================================

    createSimpleTextEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: text/plain; charset=utf-8
Content-Transfer-Encoding: 8bit

${options.body}

-- 
Generated synthetic test email`;
    }

    createMultipartAlternativeEmail(options) {
        const boundary = this.generateBoundary();
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/alternative; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8
Content-Transfer-Encoding: 8bit

${options.textBody}

--${boundary}
Content-Type: text/html; charset=utf-8
Content-Transfer-Encoding: 8bit

${options.htmlBody}

--${boundary}--`;
    }

    createMultipartMixedEmail(options) {
        const boundary = this.generateBoundary();
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        
        let email = `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8
Content-Transfer-Encoding: 8bit

${options.body}

`;

        // Add attachments
        for (const attachment of options.attachments) {
            const encodedContent = this.encodeBase64(attachment.content);
            
            email += `--${boundary}
Content-Type: ${attachment.contentType}; name="${attachment.filename}"
Content-Disposition: attachment; filename="${attachment.filename}"
Content-Transfer-Encoding: base64

${encodedContent}

`;
        }
        
        email += `--${boundary}--`;
        return email;
    }

    createLargeBodyEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        
        // Generate large text content
        const baseText = 'This is a synthetic large email body designed to test streaming parser functionality. ';
        const repetitions = Math.ceil(options.targetSize / baseText.length);
        const largeBody = baseText.repeat(repetitions);
        
        return `From: streaming-test@example.com
To: recipient@example.com
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: text/plain; charset=utf-8
Content-Transfer-Encoding: 8bit

${largeBody}

-- 
End of large synthetic email body (Size: ~${Math.round(options.targetSize / 1024)}KB)`;
    }

    createCalendarEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        const icsContent = this.generateICSCalendar(options.event);
        const encodedICS = this.encodeBase64(icsContent);
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

Please find the attached calendar invitation.

--${boundary}
Content-Type: text/calendar; method=REQUEST; name="meeting.ics"
Content-Disposition: attachment; filename="meeting.ics"
Content-Transfer-Encoding: base64

${encodedICS}

--${boundary}--`;
    }

    createSMIMESignedEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        // Mock PKCS#7 signature (not real cryptographic signature)
        const mockSignature = this.generateMockPKCS7Signature();
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/signed; protocol="application/pkcs7-signature"; micalg="sha256"; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

${options.body}

This message is digitally signed for testing purposes.

--${boundary}
Content-Type: application/pkcs7-signature; name="smime.p7s"
Content-Disposition: attachment; filename="smime.p7s"
Content-Transfer-Encoding: base64

${mockSignature}

--${boundary}--`;
    }

    // ============================================================================
    // UTILITY METHODS
    // ============================================================================

    generateMessageId() {
        const timestamp = Date.now();
        const random = Math.random().toString(36).substring(2);
        return `synthetic-${timestamp}-${random}@testgen.local`;
    }

    generateRFC5322Date() {
        return new Date().toUTCString();
    }

    generateBoundary() {
        const timestamp = Date.now().toString(36);
        const random = Math.random().toString(36).substring(2);
        return `----=_NextPart_SyntheticTest_${timestamp}_${random}`;
    }

    formatAddress(addr) {
        if (addr.name) {
            return `"${addr.name}" <${addr.email}>`;
        }
        return addr.email;
    }

    encodeBase64(content) {
        // Simple Base64 encoding for test content
        if (typeof btoa !== 'undefined') {
            return btoa(content).replace(/(.{76})/g, '$1\n');
        }
        
        // Fallback for Node.js environments
        return Buffer.from(content, 'utf-8').toString('base64').replace(/(.{76})/g, '$1\n');
    }

    generateICSCalendar(event) {
        const uid = this.generateMessageId();
        const dtstamp = new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
        
        return `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Synthetic Test Generator//Test Calendar//EN
BEGIN:VEVENT
UID:${uid}
DTSTAMP:${dtstamp}
DTSTART:${event.dtstart}
DTEND:${event.dtend}
SUMMARY:${event.summary}
DESCRIPTION:${event.description}
LOCATION:${event.location}
END:VEVENT
END:VCALENDAR`;
    }

    generateMockPKCS7Signature() {
        // SYNTHETIC TEST DATA ONLY - NOT A REAL CRYPTOGRAPHIC SIGNATURE
        // This is mock data for parser testing - contains no real credentials
        const mockData = `MIIGDAYJKoZIhvcNAQcCoIIF/TCCBfkCAQExDzANBglghkgBZQMEAgEFADALBgkq
hkiG9w0BBwGgggTnMIIE4zCCA8ugAwIBAgIJAMExample123456MA0GCSqGSIb3DQEB
CwUAMIGJMQswCQYDVQQGEwJVUzELMAkGA1UECAwCQ0ExFjAUBgNVBAcMDVNhbiBG
cmFuY2lzY28xEzARBgNVBAoMCkV4YW1wbGUgT3JnMRMwEQYDVQQLDApJVCBTeXN0
ZW1zMSswKQYDVQQDDCJTeW50aGV0aWMgVGVzdCBDQSAoTk9UIFJFQUwgU0lHTmF0
dXJlKTAeFw0yNTA5MTcwNDAwMDBaFw0yNjA5MTcwNDAwMDBaMIGJMQswCQYDVQQG
EwJVUzELMAkGA1UECAwCQ0ExFjAUBgNVBAcMDVNhbiBGcmFuY2lzY28xEzARBgNV
BAoMCkV4YW1wbGUgT3JnMRMwEQYDVQQLDApJVCBTeXN0ZW1zMSswKQYDVQQDDCJT
eW50aGV0aWMgVGVzdCBDQSAoTk9UIFJFQUwgU0lHTmF0dXJlKQ==`;
        
        return mockData.replace(/(.{76})/g, '$1\n');
    }

    generateSyntheticPDF() {
        // Minimal PDF structure for testing
        return `%PDF-1.4
%âãÏÓ
1 0 obj
<<
/Type /Pages
/Kids [2 0 R]
/Count 1
/MediaBox [0 0 612 792]
>>
endobj

2 0 obj
<<
/Type /Page
/Parent 1 0 R
/Contents 3 0 R
>>
endobj

3 0 obj
<<
/Length 44
>>
stream
BT
/F1 12 Tf
100 700 Td
(Synthetic Test PDF) Tj
ET
endstream
endobj

xref
0 4
0000000000 65535 f 
0000000009 00000 n 
0000000074 00000 n 
0000000120 00000 n 
trailer
<<
/Size 4
/Root 1 0 R
>>
startxref
224
%%EOF`;
    }

    generateSyntheticImage() {
        // Minimal PNG structure (1x1 transparent pixel)
        const pngBytes = [
            137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 0, 1, 0, 0, 0, 1,
            8, 6, 0, 0, 0, 31, 21, 196, 137, 0, 0, 0, 11, 73, 68, 65, 84, 120, 156, 99, 248, 15,
            0, 0, 1, 0, 1, 53, 174, 157, 25, 0, 0, 0, 0, 73, 69, 78, 68, 174, 66, 96, 130
        ];
        
        return String.fromCharCode(...pngBytes);
    }

    // ============================================================================
    // MISSING METHODS IMPLEMENTATION
    // ============================================================================

    createNestedMultipartEmail(options) {
        const boundary1 = this.generateBoundary();
        const boundary2 = this.generateBoundary();
        const boundary3 = this.generateBoundary();
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary1}"

--${boundary1}
Content-Type: text/plain; charset=utf-8

This is the main body of a nested multipart email.

--${boundary1}
Content-Type: multipart/alternative; boundary="${boundary2}"

--${boundary2}
Content-Type: text/plain; charset=utf-8

This is the plain text version of the nested alternative part.

--${boundary2}
Content-Type: multipart/related; boundary="${boundary3}"

--${boundary3}
Content-Type: text/html; charset=utf-8

<html><body><h1>Nested HTML Content</h1><p>This is deeply nested content.</p></body></html>

--${boundary3}
Content-Type: image/png; name="nested.png"
Content-Disposition: inline; filename="nested.png"
Content-Transfer-Encoding: base64

${this.encodeBase64(this.generateSyntheticImage())}

--${boundary3}--

--${boundary2}--

--${boundary1}--`;
    }

    createUnicodeEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: =?UTF-8?B?${this.encodeBase64(options.subject)}?=
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: text/plain; charset=utf-8
Content-Transfer-Encoding: 8bit

${options.body}

-- 
Unicode test signature with emojis: 🧪📧✨`;
    }

    createQuotedPrintableEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        
        // Simple quoted-printable encoding
        const qpBody = options.body
            .replace(/=/g, '=3D')
            .replace(/ $/gm, '=20')
            .replace(/(.{76})/g, '$1=\n');
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: text/plain; charset=utf-8
Content-Transfer-Encoding: quoted-printable

${qpBody}

-- =
Generated quoted-printable test email`;
    }

    createVCardEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        const vCardContent = this.generateVCard(options.contact);
        const encodedVCard = this.encodeBase64(vCardContent);
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

Please find the attached contact information.

--${boundary}
Content-Type: text/vcard; name="contact.vcf"
Content-Disposition: attachment; filename="contact.vcf"
Content-Transfer-Encoding: base64

${encodedVCard}

--${boundary}--`;
    }

    createPDFAttachmentEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        const encodedPDF = this.encodeBase64(options.pdfContent);
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

${options.body}

--${boundary}
Content-Type: application/pdf; name="document.pdf"
Content-Disposition: attachment; filename="document.pdf"
Content-Transfer-Encoding: base64

${encodedPDF}

--${boundary}--`;
    }

    createImageAttachmentEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        const encodedImage = this.encodeBase64(options.imageContent);
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

${options.body}

--${boundary}
Content-Type: image/png; name="test.png"
Content-Disposition: attachment; filename="test.png"
Content-Transfer-Encoding: base64

${encodedImage}

--${boundary}--`;
    }

    createManyAttachmentsEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        let email = `From: many-attachments@example.com
To: recipient@example.com
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

This email contains ${options.attachmentCount} attachments for testing purposes.

`;

        // Generate many small attachments
        for (let i = 1; i <= options.attachmentCount; i++) {
            const content = `This is attachment ${i} with some test data.`.repeat(Math.ceil(options.attachmentSize / 50));
            const encodedContent = this.encodeBase64(content.substring(0, options.attachmentSize));
            
            email += `--${boundary}
Content-Type: text/plain; name="attachment${i}.txt"
Content-Disposition: attachment; filename="attachment${i}.txt"
Content-Transfer-Encoding: base64

${encodedContent}

`;
        }
        
        email += `--${boundary}--`;
        return email;
    }

    createDeepNestedEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        
        let email = `From: nested-test@example.com
To: recipient@example.com
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0`;

        let currentBoundary = this.generateBoundary();
        email += `\nContent-Type: multipart/mixed; boundary="${currentBoundary}"

--${currentBoundary}
Content-Type: text/plain; charset=utf-8

This email has ${options.nestingDepth} levels of MIME nesting.

`;

        // Create nested structure
        for (let level = 1; level < options.nestingDepth; level++) {
            const nextBoundary = this.generateBoundary();
            email += `--${currentBoundary}
Content-Type: multipart/alternative; boundary="${nextBoundary}"

--${nextBoundary}
Content-Type: text/plain; charset=utf-8

Nesting level ${level}

`;
            currentBoundary = nextBoundary;
        }

        // Close all boundaries
        for (let level = options.nestingDepth - 1; level >= 1; level--) {
            email += `--${currentBoundary}--

`;
        }
        
        return email;
    }

    createSMIMEDetachedEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        const mockSignature = this.generateMockPKCS7Signature();
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

${options.body}

--${boundary}
Content-Type: application/pkcs7-signature; name="smime.p7s"
Content-Disposition: attachment; filename="smime.p7s"
Content-Description: S/MIME Detached Signature
Content-Transfer-Encoding: base64

${mockSignature}

--${boundary}--`;
    }

    createMalformedHeaderEmail() {
        return `From: malformed@example.com
To: recipient@example.com
Subject: Malformed Header Test
This-Is-Not-A-Valid-Header-Missing-Colon Test
Date Wed, 17 Sep 2025 04:00:00 -0700
Message-ID: <malformed@example.com>
MIME-Version: 1.0
Content-Type: text/plain

This email has intentionally malformed headers for testing error handling.`;
    }

    createInvalidBoundaryEmail() {
        return `From: boundary-test@example.com
To: recipient@example.com
Subject: Invalid Boundary Test
Date: Wed, 17 Sep 2025 04:00:00 -0700
Message-ID: <boundary@example.com>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="INVALID_BOUNDARY"

--WRONG_BOUNDARY
Content-Type: text/plain

This part uses the wrong boundary marker.

--ANOTHER_WRONG_BOUNDARY
Content-Type: text/plain

This part also uses the wrong boundary marker.

--INVALID_BOUNDARY--`;
    }

    createCorruptedBase64Email() {
        return `From: base64-test@example.com
To: recipient@example.com
Subject: Corrupted Base64 Test
Date: Wed, 17 Sep 2025 04:00:00 -0700
Message-ID: <base64@example.com>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="----=_BASE64_TEST"

------=_BASE64_TEST
Content-Type: text/plain

This email contains corrupted Base64 data.

------=_BASE64_TEST
Content-Type: application/octet-stream; name="corrupted.dat"
Content-Transfer-Encoding: base64

VGhpcyBpcyBub3QgdmFsaWQgQmFzZTY0ISEhISEh!!!INVALID!!!BASE64!!!DATA

------=_BASE64_TEST--`;
    }

    createTruncatedEmail() {
        return `From: truncated@example.com
To: recipient@example.com
Subject: Truncated Email Test
Date: Wed, 17 Sep 2025 04:00:00 -0700
Message-ID: <truncated@example.com>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="----=_TRUNCATED"

------=_TRUNCATED
Content-Type: text/plain

This email is intentionally truncated to test error handling.

------=_TRUNCATED
Content-Type: application/octet-stream
Content-Transfer-Encoding: base64

VGhpcyBhdHRhY2htZW50IGlzIGluY29tcGxldGU`;
        // Intentionally truncated - missing closing boundary
    }

    generateVCard(contact) {
        return `BEGIN:VCARD
VERSION:3.0
FN:${contact.fn}
ORG:${contact.org}
TITLE:${contact.title}
EMAIL:${contact.email}
TEL:${contact.tel}
END:VCARD`;
    }

    // ============================================================================
    // ADVANCED FEATURE GENERATORS (Nested, HTML, XML)
    // ============================================================================

    /**
     * Create email with nested message/rfc822 attachment
     */
    createNestedEmailMessage(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        // Generate the nested email content
        const nestedEmail = this.createSimpleTextEmail({
            subject: options.nestedEmail.subject,
            from: { name: options.nestedEmail.from.name || '', email: options.nestedEmail.from.email },
            to: options.nestedEmail.to,
            body: options.nestedEmail.body
        });
        
        const encodedNestedEmail = this.encodeBase64(nestedEmail);
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

${options.body}

--${boundary}
Content-Type: message/rfc822; name="original-message.eml"
Content-Disposition: attachment; filename="original-message.eml"
Content-Transfer-Encoding: base64

${encodedNestedEmail}

--${boundary}--`;
    }

    /**
     * Create deeply nested email thread structure
     */
    createDeeplyNestedEmails(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        let email = `From: thread-starter@example.com
To: recipient@example.com
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

This is the beginning of a deeply nested email thread with ${options.nestingLevels} levels.

`;

        // Create nested messages recursively
        for (let level = 1; level <= options.nestingLevels; level++) {
            const nestedSubject = `Re: ${options.threadSubject} (Level ${level})`;
            const nestedFrom = `level${level}@example.com`;
            const nestedBody = `This is level ${level} of the nested email thread.\n\nOriginal message follows below...`;
            
            const nestedEmail = this.createSimpleTextEmail({
                subject: nestedSubject,
                from: { email: nestedFrom },
                to: [{ email: 'recipient@example.com' }],
                body: nestedBody
            });
            
            const encodedNested = this.encodeBase64(nestedEmail);
            
            email += `--${boundary}
Content-Type: message/rfc822; name="thread-level-${level}.eml"
Content-Disposition: attachment; filename="thread-level-${level}.eml"
Content-Transfer-Encoding: base64

${encodedNested}

`;
        }
        
        email += `--${boundary}--`;
        return email;
    }

    /**
     * Create email with embedded MSG file attachment
     */
    createEmbeddedMSGAttachment(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        // Create a mock MSG file structure (simplified)
        const mockMSGContent = this.generateMockMSGFile({
            subject: options.embeddedMsgSubject,
            body: options.embeddedMsgBody
        });
        
        const encodedMSG = this.encodeBase64(mockMSGContent);
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

${options.body}

--${boundary}
Content-Type: application/vnd.ms-outlook; name="embedded-message.msg"
Content-Disposition: attachment; filename="embedded-message.msg"
Content-Transfer-Encoding: base64

${encodedMSG}

--${boundary}--`;
    }

    /**
     * Create rich HTML email with complex features
     */
    createRichHTMLEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        const htmlContent = this.generateRichHTML(options.htmlFeatures);
        const plainTextContent = this.htmlToPlainText(htmlContent);
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/alternative; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

${plainTextContent}

--${boundary}
Content-Type: text/html; charset=utf-8

${htmlContent}

--${boundary}--`;
    }

    /**
     * Create HTML email with embedded images
     */
    createHTMLWithEmbeddedImages(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const outerBoundary = this.generateBoundary();
        const relatedBoundary = this.generateBoundary();
        
        let htmlContent = `<!DOCTYPE html>
<html>
<head><title>${options.subject}</title></head>
<body>
<h1>Email with Embedded Images</h1>
<p>This email demonstrates inline image embedding:</p>
`;

        // Add image references
        for (let i = 1; i <= options.imageCount; i++) {
            htmlContent += `<p>Image ${i}: <img src="cid:image${i}" alt="Test Image ${i}" /></p>\n`;
        }
        
        htmlContent += `</body></html>`;
        
        let email = `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${outerBoundary}"

--${outerBoundary}
Content-Type: multipart/related; boundary="${relatedBoundary}"

--${relatedBoundary}
Content-Type: text/html; charset=utf-8

${htmlContent}

`;

        // Add embedded images
        for (let i = 1; i <= options.imageCount; i++) {
            const imageData = this.encodeBase64(this.generateSyntheticImage());
            
            email += `--${relatedBoundary}
Content-Type: image/png; name="image${i}.png"
Content-ID: <image${i}>
Content-Disposition: inline; filename="image${i}.png"
Content-Transfer-Encoding: base64

${imageData}

`;
        }
        
        email += `--${relatedBoundary}--

--${outerBoundary}--`;
        
        return email;
    }

    /**
     * Create multipart/related HTML email
     */
    createHTMLMultipartRelated(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        const htmlContent = `<!DOCTYPE html>
<html>
<head>
    <title>${options.subject}</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .header { background-color: #f0f0f0; padding: 20px; }
        .content { margin: 20px; }
        .footer { font-size: 12px; color: #666; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Complex HTML Email Structure</h1>
    </div>
    <div class="content">
        <p>This email demonstrates multipart/related structure with:</p>
        <ul>
            <li>Embedded CSS styles</li>
            <li>Related images and resources</li>
            <li>Complex HTML structure</li>
        </ul>
        <p><img src="cid:related-image" alt="Related Image" /></p>
    </div>
    <div class="footer">
        <p>Generated for EmailParser testing</p>
    </div>
</body>
</html>`;
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/related; boundary="${boundary}"

--${boundary}
Content-Type: text/html; charset=utf-8

${htmlContent}

--${boundary}
Content-Type: image/png; name="related-image.png"
Content-ID: <related-image>
Content-Disposition: inline; filename="related-image.png"
Content-Transfer-Encoding: base64

${this.encodeBase64(this.generateSyntheticImage())}

--${boundary}--`;
    }

    /**
     * Create email with XML data attachment
     */
    createXMLDataEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        const xmlContent = options.xmlContent;
        const encodedXML = this.encodeBase64(xmlContent);
        const filename = `${options.xmlType}-data.xml`;
        
        return `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

This email contains ${options.xmlType} XML data for testing advanced MIME parsing.

--${boundary}
Content-Type: application/xml; name="${filename}"
Content-Disposition: attachment; filename="${filename}"
Content-Transfer-Encoding: base64

${encodedXML}

--${boundary}--`;
    }

    /**
     * Create email with mixed content types
     */
    createMixedContentEmail(options) {
        const messageId = this.generateMessageId();
        const date = this.generateRFC5322Date();
        const boundary = this.generateBoundary();
        
        let email = `From: ${this.formatAddress(options.from)}
To: ${options.to.map(addr => this.formatAddress(addr)).join(', ')}
Subject: ${options.subject}
Date: ${date}
Message-ID: <${messageId}>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="${boundary}"

--${boundary}
Content-Type: text/plain; charset=utf-8

This email contains multiple content types for comprehensive testing:
- HTML content
- XML data  
- PDF document
- Various attachments

`;

        // Add HTML content
        if (options.contentTypes.includes('html')) {
            const htmlContent = this.generateRichHTML(['tables', 'css']);
            email += `--${boundary}
Content-Type: text/html; charset=utf-8
Content-Disposition: inline; filename="content.html"

${htmlContent}

`;
        }

        // Add XML content
        if (options.contentTypes.includes('xml')) {
            const xmlContent = this.generateSampleXML();
            const encodedXML = this.encodeBase64(xmlContent);
            email += `--${boundary}
Content-Type: application/xml; name="data.xml"
Content-Disposition: attachment; filename="data.xml"
Content-Transfer-Encoding: base64

${encodedXML}

`;
        }

        // Add PDF content
        if (options.contentTypes.includes('pdf')) {
            const pdfContent = this.generateSyntheticPDF();
            const encodedPDF = this.encodeBase64(pdfContent);
            email += `--${boundary}
Content-Type: application/pdf; name="document.pdf"
Content-Disposition: attachment; filename="document.pdf"
Content-Transfer-Encoding: base64

${encodedPDF}

`;
        }
        
        email += `--${boundary}--`;
        return email;
    }

    // ============================================================================
    // CONTENT GENERATORS
    // ============================================================================

    /**
     * Generate mock MSG file content
     */
    generateMockMSGFile(options) {
        // This is a simplified MSG file structure for testing
        // In reality, MSG files are complex OLE compound documents
        return `MOCK_MSG_FILE_HEADER
Subject: ${options.subject}
Body: ${options.body}
MSG_END`;
    }

    /**
     * Generate rich HTML content
     */
    generateRichHTML(features) {
        let html = `<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Rich HTML Email Content</title>`;

        // Add CSS if requested
        if (features.includes('css')) {
            html += `
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; }
        .content { padding: 20px; }
        .highlight { background-color: #ffff99; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>`;
        }

        html += `
</head>
<body>
    <div class="header">
        <h1>🧪 Rich HTML Email Test</h1>
        <p>Comprehensive HTML feature testing</p>
    </div>
    <div class="content">
        <h2>Text Formatting</h2>
        <p>This email tests various <strong>HTML features</strong> including:</p>
        <ul>
            <li><em>Italic text</em> and <strong>bold text</strong></li>
            <li><span class="highlight">Highlighted text</span></li>
            <li><a href="https://example.com">External links</a></li>
        </ul>`;

        // Add table if requested
        if (features.includes('tables')) {
            html += `
        <h2>Data Table</h2>
        <table>
            <thead>
                <tr>
                    <th>Feature</th>
                    <th>Status</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>HTML Parsing</td>
                    <td>✅ Active</td>
                    <td>Full support</td>
                </tr>
                <tr>
                    <td>CSS Styles</td>
                    <td>✅ Active</td>
                    <td>Inline and embedded</td>
                </tr>
                <tr>
                    <td>Images</td>
                    <td>⚠️ Testing</td>
                    <td>Embedded and external</td>
                </tr>
            </tbody>
        </table>`;
        }

        // Add images if requested
        if (features.includes('images')) {
            html += `
        <h2>Image Content</h2>
        <p>Embedded image: <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==" alt="Test" /></p>
        <p>External image: <img src="https://via.placeholder.com/150x50/0066CC/FFFFFF?text=Test" alt="Placeholder" /></p>`;
        }

        // Add links if requested
        if (features.includes('links')) {
            html += `
        <h2>Navigation Links</h2>
        <p>Various link types:</p>
        <ul>
            <li><a href="https://example.com">External link</a></li>
            <li><a href="mailto:test@example.com">Email link</a></li>
            <li><a href="#section1">Internal anchor</a></li>
        </ul>`;
        }

        // Add forms if requested
        if (features.includes('forms')) {
            html += `
        <h2>Form Elements</h2>
        <form action="#" method="post">
            <p>
                <label for="name">Name:</label><br>
                <input type="text" id="name" name="name" placeholder="Enter your name">
            </p>
            <p>
                <label for="email">Email:</label><br>
                <input type="email" id="email" name="email" placeholder="email@example.com">
            </p>
            <p>
                <input type="submit" value="Submit">
            </p>
        </form>`;
        }

        html += `
    </div>
    <footer style="padding: 20px; background-color: #f9f9f9; font-size: 12px; color: #666;">
        <p>Generated by EmailParser Synthetic Test Suite</p>
    </footer>
</body>
</html>`;

        return html;
    }

    /**
     * Convert HTML to plain text
     */
    htmlToPlainText(html) {
        return html
            .replace(/<style[^>]*>.*?<\/style>/gis, '')
            .replace(/<script[^>]*>.*?<\/script>/gis, '')
            .replace(/<br\s*\/?>/gi, '\n')
            .replace(/<\/p>/gi, '\n\n')
            .replace(/<[^>]+>/g, '')
            .replace(/&nbsp;/g, ' ')
            .replace(/</g, '<')
            .replace(/>/g, '>')
            .replace(/&/g, '&')
            .replace(/\s+/g, ' ')
            .trim();
    }

    /**
     * Generate sample XML content
     */
    generateSampleXML() {
        return `<?xml version="1.0" encoding="UTF-8"?>
<testData xmlns="http://example.com/test" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <metadata>
        <title>Sample XML Test Data</title>
        <description>Generated XML content for EmailParser testing</description>
        <created>2025-09-17T04:30:00Z</created>
        <version>1.0</version>
    </metadata>
    <dataElements>
        <element id="1" type="string">
            <name>Test Element One</name>
            <value>Sample string value</value>
            <attributes category="primary" status="active" />
        </element>
        <element id="2" type="number">
            <name>Test Element Two</name>
            <value>42</value>
            <attributes category="secondary" status="inactive" />
        </element>
        <element id="3" type="date">
            <name>Test Element Three</name>
            <value>2025-09-17</value>
            <attributes category="tertiary" status="pending" />
        </element>
    </dataElements>
    <configuration>
        <settings>
            <debug>true</debug>
            <maxElements>100</maxElements>
            <timeout>5000</timeout>
        </settings>
        <features>
            <feature name="validation" enabled="true" />
            <feature name="compression" enabled="false" />
            <feature name="encryption" enabled="true" />
        </features>
    </configuration>
</testData>`;
    }

    /**
     * Generate RSS feed XML
     */
    generateRSSFeed() {
        return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
    <channel>
        <title>EmailParser Test Feed</title>
        <description>Sample RSS feed for XML parsing tests</description>
        <link>https://example.com/test-feed</link>
        <language>en-US</language>
        <pubDate>Wed, 17 Sep 2025 04:30:00 GMT</pubDate>
        <lastBuildDate>Wed, 17 Sep 2025 04:30:00 GMT</lastBuildDate>
        <atom:link href="https://example.com/test-feed.xml" rel="self" type="application/rss+xml" />
        
        <item>
            <title>EmailParser Test Suite Release</title>
            <description>Comprehensive testing framework for email parsing capabilities</description>
            <link>https://example.com/news/test-suite-release</link>
            <guid>https://example.com/news/test-suite-release</guid>
            <pubDate>Wed, 17 Sep 2025 04:30:00 GMT</pubDate>
            <category>Technology</category>
            <author>test@example.com (Test Author)</author>
        </item>
        
        <item>
            <title>Advanced MIME Support</title>
            <description>New support for complex MIME structures and nested content</description>
            <link>https://example.com/news/advanced-mime</link>
            <guid>https://example.com/news/advanced-mime</guid>
            <pubDate>Tue, 16 Sep 2025 12:00:00 GMT</pubDate>
            <category>Technology</category>
            <author>developer@example.com (Developer Team)</author>
        </item>
        
        <item>
            <title>XML Processing Enhancement</title>
            <description>Improved XML content extraction and parsing capabilities</description>
            <link>https://example.com/news/xml-enhancement</link>
            <guid>https://example.com/news/xml-enhancement</guid>
            <pubDate>Mon, 15 Sep 2025 09:15:00 GMT</pubDate>
            <category>Development</category>
            <author>xml-team@example.com (XML Team)</author>
        </item>
    </channel>
</rss>`;
    }

    /**
     * Generate SOAP message XML
     */
    generateSOAPMessage() {
        return `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:test="http://example.com/test-service">
    <soap:Header>
        <test:RequestHeader>
            <test:MessageId>test-msg-12345</test:MessageId>
            <test:Timestamp>2025-09-17T04:30:00Z</test:Timestamp>
            <test:Version>1.2</test:Version>
            <test:Authentication>
                <test:Token>eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9</test:Token>
                <test:Username>testuser</test:Username>
            </test:Authentication>
        </test:RequestHeader>
    </soap:Header>
    
    <soap:Body>
        <test:ProcessEmailRequest>
            <test:EmailData>
                <test:Subject>Test Email Processing Request</test:Subject>
                <test:From>sender@example.com</test:From>
                <test:To>recipient@example.com</test:To>
                <test:Content encoding="base64">VGhpcyBpcyBhIHRlc3QgZW1haWwgYm9keQ==</test:Content>
                <test:Attachments>
                    <test:Attachment>
                        <test:Name>document.pdf</test:Name>
                        <test:Type>application/pdf</test:Type>
                        <test:Size>15724</test:Size>
                        <test:Data>JVBERi0xLjQ...</test:Data>
                    </test:Attachment>
                </test:Attachments>
            </test:EmailData>
            <test:ProcessingOptions>
                <test:ExtractAttachments>true</test:ExtractAttachments>
                <test:ParseHTML>true</test:ParseHTML>
                <test:ValidateSignatures>false</test:ValidateSignatures>
                <test:MaxFileSize>10485760</test:MaxFileSize>
            </test:ProcessingOptions>
        </test:ProcessEmailRequest>
    </soap:Body>
</soap:Envelope>`;
    }
}

// Browser compatibility
if (typeof window !== 'undefined') {
    window.SyntheticFileGenerator = SyntheticFileGenerator;
}

// Node.js compatibility
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SyntheticFileGenerator;
}
