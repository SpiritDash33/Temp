/**
 * Synthetic Test Suite Runner for EmailParser
 * Comprehensive testing framework for RFC5322, MIME, S/MIME, and Streaming
 */
class SyntheticTestRunner {
    constructor(options = {}) {
        this.debug = options.debug || false;
        this.parser = null; // Will be initialized with EmailParser
        this.testResults = new Map();
        this.performanceMetrics = new Map();
        this.categories = {
            'core': 'Core RFC5322/MIME Tests',
            'advanced': 'Advanced MIME & Attachments',
            'streaming': 'Streaming & Performance Tests',
            'smime': 'S/MIME Cryptographic Tests',
            'errors': 'Error Handling & Edge Cases'
        };
        
        this.stats = {
            totalTests: 0,
            passed: 0,
            failed: 0,
            skipped: 0,
            startTime: null,
            endTime: null
        };

        if (this.debug) {
            console.log('SyntheticTestRunner initialized');
        }
    }

    /**
     * Initialize with EmailParser instance
     */
    setParser(emailParser) {
        this.parser = emailParser;
        if (this.debug) {
            console.log('EmailParser configured for testing');
        }
    }

    /**
     * Run complete test suite or specific category
     */
    async runSuite(category = 'all', options = {}) {
        this.stats.startTime = performance.now();
        
        console.log('🧪 Starting Synthetic Test Suite...');
        console.log('=' .repeat(50));

        try {
            const categoriesToRun = category === 'all' 
                ? Object.keys(this.categories)
                : [category];

            for (const cat of categoriesToRun) {
                if (this.categories[cat]) {
                    console.log(`\n📂 Running ${this.categories[cat]}...`);
                    await this.runCategoryTests(cat, options);
                }
            }

            this.stats.endTime = performance.now();
            this.generateFinalReport();
            
        } catch (error) {
            console.error('❌ Test suite execution failed:', error.message);
            throw error;
        }

        return this.getTestResults();
    }

    /**
     * Run tests for specific category
     */
    async runCategoryTests(category, options = {}) {
        const testFiles = await this.getTestFiles(category);
        
        for (const testFile of testFiles) {
            await this.runSingleTest(testFile, category, options);
        }
    }

    /**
     * Execute individual test file
     */
    async runSingleTest(testFile, category, options = {}) {
        const testName = `${category}/${testFile.name}`;
        const startTime = performance.now();
        
        try {
            console.log(`  🔍 Testing: ${testFile.name}`);
            
            // Load test file
            const fileContent = await this.loadTestFile(testFile.path);
            
            // Parse with EmailParser
            const parseResult = await this.parseTestFile(fileContent, testFile);
            
            // Validate results
            const validation = await this.validateResult(parseResult, testFile.expected);
            
            const duration = performance.now() - startTime;
            
            // Record results
            this.recordTestResult(testName, {
                status: validation.passed ? 'PASSED' : 'FAILED',
                duration: duration,
                validation: validation,
                parseResult: parseResult,
                expected: testFile.expected,
                errors: validation.errors || []
            });
            
            // Performance metrics
            this.recordPerformanceMetric(testName, {
                duration: duration,
                memoryUsage: parseResult?.parserInfo?.memoryUsed || 0,
                processingMode: parseResult?.parserInfo?.processingMode || 'unknown'
            });
            
            if (validation.passed) {
                console.log(`    ✅ PASSED (${duration.toFixed(2)}ms)`);
                this.stats.passed++;
            } else {
                console.log(`    ❌ FAILED (${validation.errors.length} errors)`);
                if (this.debug) {
                    validation.errors.forEach(error => {
                        console.log(`      - ${error}`);
                    });
                }
                this.stats.failed++;
            }
            
        } catch (error) {
            console.log(`    💥 ERROR: ${error.message}`);
            this.recordTestResult(testName, {
                status: 'ERROR',
                error: error.message,
                duration: performance.now() - startTime
            });
            this.stats.failed++;
        }
        
        this.stats.totalTests++;
    }

    /**
     * Get list of test files for category
     */
    async getTestFiles(category) {
        // This would normally read from file system
        // For now, return synthetic test definitions
        
        const testDefinitions = {
            core: [
                {
                    name: 'simple-text.eml',
                    path: `/TestSuite/SyntheticTests/Core/simple-text.eml`,
                    expected: {
                        subject: 'Simple Text Email Test',
                        from: { email: 'sender@example.com' },
                        to: [{ email: 'recipient@example.com' }],
                        bodyText: 'This is a simple text email for basic parsing test.',
                        attachments: []
                    }
                },
                {
                    name: 'multipart-mixed.eml',
                    path: `/TestSuite/SyntheticTests/Core/multipart-mixed.eml`,
                    expected: {
                        subject: 'Multipart Mixed with Attachments',
                        from: { email: 'attachments@example.com' },
                        to: [{ email: 'recipient@example.com' }],
                        bodyText: 'This email contains multiple attachments for testing.',
                        attachments: [
                            { name: 'test-document.txt', type: 'text/plain' },
                            { name: 'data.json', type: 'application/json' }
                        ]
                    }
                },
                {
                    name: 'multipart-alternative.eml',
                    path: `/TestSuite/SyntheticTests/Core/multipart-alternative.eml`,
                    expected: {
                        subject: 'Multipart Alternative Test',
                        from: { email: 'html@example.com' },
                        to: [{ email: 'recipient@example.com' }],
                        bodyText: 'This is the plain text version of the email.',
                        bodyHtml: '<html><body><h1>HTML Version</h1><p>This is the <b>HTML</b> version of the email.</p></body></html>',
                        hasAlternativeContent: true
                    }
                }
            ],
            advanced: [
                // Nested Email Tests
                {
                    name: 'nested-eml-message.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/nested-eml-message.eml`,
                    expected: {
                        subject: 'Forwarded Email with Nested Message',
                        from: { email: 'forwarder@example.com' },
                        attachments: [
                            { name: 'original-message.eml', type: 'message/rfc822' }
                        ],
                        hasNestedEmails: true,
                        nestedEmailCount: 1
                    }
                },
                {
                    name: 'deeply-nested-emails.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/deeply-nested-emails.eml`,
                    expected: {
                        subject: 'Email Thread with Deep Nesting',
                        from: { email: 'thread-starter@example.com' },
                        hasNestedEmails: true,
                        nestedEmailCount: 4,
                        threadDepth: 4
                    }
                },
                {
                    name: 'embedded-msg-attachment.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/embedded-msg-attachment.eml`,
                    expected: {
                        subject: 'Email with Embedded MSG File',
                        from: { email: 'msg-sender@example.com' },
                        attachments: [
                            { name: 'embedded-message.msg', type: 'application/vnd.ms-outlook' }
                        ],
                        hasEmbeddedMsgFiles: true
                    }
                },

                // Rich HTML Content Tests
                {
                    name: 'rich-html-email.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/rich-html-email.eml`,
                    expected: {
                        subject: 'Rich HTML Email with Complex Content',
                        from: { email: 'newsletter@example.com' },
                        hasRichHTML: true,
                        htmlFeatures: ['tables', 'css', 'images', 'links', 'forms'],
                        bodyHtmlLength: { min: 1000 } // Rich HTML should be substantial
                    }
                },
                {
                    name: 'html-with-embedded-images.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/html-with-embedded-images.eml`,
                    expected: {
                        subject: 'HTML Email with Inline Images',
                        from: { email: 'marketing@example.com' },
                        hasInlineImages: true,
                        inlineImageCount: 3,
                        contentType: 'multipart/mixed'
                    }
                },
                {
                    name: 'html-multipart-related.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/html-multipart-related.eml`,
                    expected: {
                        subject: 'Complex HTML Email Structure',
                        from: { email: 'complex@example.com' },
                        contentType: 'multipart/related',
                        hasRelatedParts: true,
                        relatedPartCount: { min: 1 }
                    }
                },

                // XML Content Tests
                {
                    name: 'xml-data-attachment.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/xml-data-attachment.eml`,
                    expected: {
                        subject: 'Email with XML Data',
                        from: { email: 'data@example.com' },
                        attachments: [
                            { name: 'generic-data.xml', type: 'application/xml' }
                        ],
                        hasXMLContent: true,
                        xmlType: 'generic'
                    }
                },
                {
                    name: 'rss-feed-attachment.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/rss-feed-attachment.eml`,
                    expected: {
                        subject: 'RSS Feed Data',
                        from: { email: 'feeds@example.com' },
                        attachments: [
                            { name: 'rss-data.xml', type: 'application/xml' }
                        ],
                        hasXMLContent: true,
                        xmlType: 'rss'
                    }
                },
                {
                    name: 'soap-xml-message.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/soap-xml-message.eml`,
                    expected: {
                        subject: 'SOAP XML Message',
                        from: { email: 'webservice@example.com' },
                        attachments: [
                            { name: 'soap-data.xml', type: 'application/xml' }
                        ],
                        hasXMLContent: true,
                        xmlType: 'soap'
                    }
                },

                // Mixed Content Tests
                {
                    name: 'html-xml-mixed.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/html-xml-mixed.eml`,
                    expected: {
                        subject: 'Mixed HTML and XML Content',
                        from: { email: 'mixed@example.com' },
                        hasMixedContent: true,
                        contentTypes: ['html', 'xml', 'pdf'],
                        attachmentCount: { min: 2 }
                    }
                },

                // Traditional Advanced MIME Tests
                {
                    name: 'calendar-ics.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/calendar-ics.eml`,
                    expected: {
                        subject: 'Meeting Invitation',
                        from: { email: 'calendar@example.com' },
                        attachments: [
                            { name: 'meeting.ics', type: 'text/calendar' }
                        ],
                        hasCalendarData: true
                    }
                },
                {
                    name: 'vcard-contact.eml',
                    path: `/TestSuite/SyntheticTests/Advanced-MIME/vcard-contact.eml`,
                    expected: {
                        subject: 'Contact Information',
                        from: { email: 'contacts@example.com' },
                        attachments: [
                            { name: 'contact.vcf', type: 'text/vcard' }
                        ],
                        hasVCardData: true
                    }
                }
            ],
            streaming: [
                {
                    name: 'large-body-10mb.eml',
                    path: `/TestSuite/SyntheticTests/Streaming/large-body-10mb.eml`,
                    expected: {
                        processingMode: 'streaming',
                        memoryUsage: { max: 15 * 1024 * 1024 }, // 15MB max
                        bodySize: { min: 10 * 1024 * 1024 } // Should be ~10MB
                    }
                },
                {
                    name: 'many-attachments-50.eml',
                    path: `/TestSuite/SyntheticTests/Streaming/many-attachments-50.eml`,
                    expected: {
                        attachmentCount: { exact: 50 },
                        processingMode: 'streaming'
                    }
                }
            ],
            smime: [
                {
                    name: 'smime-signed.eml',
                    path: `/TestSuite/SyntheticTests/SMIME/smime-signed.eml`,
                    expected: {
                        subject: 'S/MIME Signed Email Test',
                        from: { email: 'secure@example.com' },
                        hasSMIMESignature: true,
                        contentType: 'multipart/signed',
                        signatureType: 'application/pkcs7-signature'
                    }
                }
            ],
            errors: [
                {
                    name: 'malformed-headers.eml',
                    path: `/TestSuite/SyntheticTests/Error-Conditions/malformed-headers.eml`,
                    expected: {
                        subject: 'Malformed Header Test',
                        hasParsingErrors: true,
                        errorRecovery: true
                    }
                }
            ]
        };
        
        return testDefinitions[category] || [];
    }

    /**
     * Load test file content
     */
    async loadTestFile(filePath) {
        // Extract file name from path
        const fileName = filePath.split('/').pop();
        
        // Generate content using the file generator
        try {
            const generator = new SyntheticFileGenerator({ debug: false });
            
            // Generate specific content based on file name
            if (fileName.includes('simple-text')) {
                return generator.createSimpleTextEmail({
                    subject: 'Simple Text Email Test',
                    from: { name: 'Test Sender', email: 'sender@example.com' },
                    to: [{ name: 'Test Recipient', email: 'recipient@example.com' }],
                    body: 'This is a simple text email for basic RFC5322 parsing validation.'
                });
            } else if (fileName.includes('multipart-mixed')) {
                return generator.createMultipartMixedEmail({
                    subject: 'Multipart Mixed with Attachments',
                    from: { email: 'attachments@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'This email contains multiple attachments for testing.',
                    attachments: [
                        {
                            filename: 'test-document.txt',
                            contentType: 'text/plain',
                            content: 'This is a test document attachment.\nIt contains sample text data.'
                        },
                        {
                            filename: 'data.json',
                            contentType: 'application/json',
                            content: '{"test": true, "data": [1, 2, 3], "message": "JSON test file"}'
                        }
                    ]
                });
            } else if (fileName.includes('multipart-alternative')) {
                return generator.createMultipartAlternativeEmail({
                    subject: 'Multipart Alternative Test',
                    from: { name: 'HTML Sender', email: 'html@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    textBody: 'This is the plain text version of the email.',
                    htmlBody: '<html><body><h1>HTML Version</h1><p>This is the <b>HTML</b> version of the email.</p></body></html>'
                });
            } else if (fileName.includes('nested-eml-message')) {
                return generator.createNestedEmailMessage({
                    subject: 'Forwarded Email with Nested Message',
                    from: { name: 'Email Forwarder', email: 'forwarder@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'Please see the forwarded email below.',
                    nestedEmail: {
                        subject: 'Original Message Subject',
                        from: { name: 'Original Sender', email: 'original@example.com' },
                        to: [{ email: 'first-recipient@example.com' }],
                        body: 'This is the content of the original nested email message.',
                        date: '2025-09-16T10:30:00Z'
                    }
                });
            } else if (fileName.includes('deeply-nested-emails')) {
                return generator.createDeeplyNestedEmails({
                    subject: 'Email Thread with Deep Nesting',
                    nestingLevels: 4,
                    threadSubject: 'Re: Important Project Discussion'
                });
            } else if (fileName.includes('embedded-msg-attachment')) {
                return generator.createEmbeddedMSGAttachment({
                    subject: 'Email with Embedded MSG File',
                    from: { email: 'msg-sender@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'This email contains an embedded .msg file as an attachment.',
                    embeddedMsgSubject: 'Embedded Message Content',
                    embeddedMsgBody: 'This content is inside the embedded MSG file.'
                });
            } else if (fileName.includes('rich-html-email')) {
                return generator.createRichHTMLEmail({
                    subject: 'Rich HTML Email with Complex Content',
                    from: { name: 'HTML Newsletter', email: 'newsletter@example.com' },
                    to: [{ email: 'subscriber@example.com' }],
                    htmlFeatures: ['tables', 'css', 'images', 'links', 'forms']
                });
            } else if (fileName.includes('html-with-embedded-images')) {
                return generator.createHTMLWithEmbeddedImages({
                    subject: 'HTML Email with Inline Images',
                    from: { email: 'marketing@example.com' },
                    to: [{ email: 'customer@example.com' }],
                    imageCount: 3
                });
            } else if (fileName.includes('html-multipart-related')) {
                return generator.createHTMLMultipartRelated({
                    subject: 'Complex HTML Email Structure',
                    from: { email: 'complex@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    relatedParts: ['css', 'images', 'scripts']
                });
            } else if (fileName.includes('xml-data-attachment')) {
                return generator.createXMLDataEmail({
                    subject: 'Email with XML Data',
                    from: { email: 'data@example.com' },
                    to: [{ email: 'analyst@example.com' }],
                    xmlType: 'generic',
                    xmlContent: generator.generateSampleXML()
                });
            } else if (fileName.includes('rss-feed-attachment')) {
                return generator.createXMLDataEmail({
                    subject: 'RSS Feed Data',
                    from: { email: 'feeds@example.com' },
                    to: [{ email: 'subscriber@example.com' }],
                    xmlType: 'rss',
                    xmlContent: generator.generateRSSFeed()
                });
            } else if (fileName.includes('soap-xml-message')) {
                return generator.createXMLDataEmail({
                    subject: 'SOAP XML Message',
                    from: { email: 'webservice@example.com' },
                    to: [{ email: 'client@example.com' }],
                    xmlType: 'soap',
                    xmlContent: generator.generateSOAPMessage()
                });
            } else if (fileName.includes('html-xml-mixed')) {
                return generator.createMixedContentEmail({
                    subject: 'Mixed HTML and XML Content',
                    from: { email: 'mixed@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    contentTypes: ['html', 'xml', 'pdf']
                });
            } else if (fileName.includes('calendar-ics')) {
                return generator.createCalendarEmail({
                    subject: 'Meeting Invitation',
                    from: { name: 'Calendar System', email: 'calendar@example.com' },
                    to: [{ email: 'attendee@example.com' }],
                    event: {
                        summary: 'Project Review Meeting',
                        dtstart: '20251017T140000Z',
                        dtend: '20251017T150000Z',
                        location: 'Conference Room A',
                        description: 'Monthly project review and planning session'
                    }
                });
            } else if (fileName.includes('vcard-contact')) {
                return generator.createVCardEmail({
                    subject: 'Contact Information',
                    from: { name: 'Contact Manager', email: 'contacts@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    contact: {
                        fn: 'John Business',
                        org: 'Example Corp',
                        email: 'john.business@example.com',
                        tel: '+1-555-123-4567',
                        title: 'Senior Manager'
                    }
                });
            } else if (fileName.includes('pdf-attachment')) {
                return generator.createPDFAttachmentEmail({
                    subject: 'Document Attachment Test',
                    from: { email: 'documents@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'Please find the attached PDF document for review.',
                    pdfContent: generator.generateSyntheticPDF()
                });
            } else if (fileName.includes('image-attachment')) {
                return generator.createImageAttachmentEmail({
                    subject: 'Image Attachment Test',
                    from: { email: 'images@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'This email contains a test image attachment.',
                    imageContent: generator.generateSyntheticImage()
                });
            } else if (fileName.includes('large-body-10mb')) {
                return generator.createLargeBodyEmail({
                    subject: 'Large Body Test (10MB - Streaming)',
                    targetSize: 10 * 1024 * 1024 // 10MB
                });
            } else if (fileName.includes('large-body-1mb')) {
                return generator.createLargeBodyEmail({
                    subject: 'Large Body Test (1MB)',
                    targetSize: 1 * 1024 * 1024 // 1MB
                });
            } else if (fileName.includes('many-attachments-50')) {
                return generator.createManyAttachmentsEmail({
                    subject: 'Many Attachments Test (50 files)',
                    attachmentCount: 50,
                    attachmentSize: 1024 // 1KB each
                });
            } else if (fileName.includes('smime-signed')) {
                return generator.createSMIMESignedEmail({
                    subject: 'S/MIME Signed Email Test',
                    from: { email: 'secure@example.com' },
                    to: [{ email: 'recipient@example.com' }],
                    body: 'This email is digitally signed for authenticity verification.'
                });
            } else if (fileName.includes('malformed-headers')) {
                return generator.createMalformedHeaderEmail();
            } else {
                // Fallback for other files
                return this.generateSimpleTextEmail();
            }
            
        } catch (error) {
            console.warn(`Failed to generate content for ${fileName}:`, error.message);
            return this.generateSimpleTextEmail();
        }
    }

    /**
     * Parse test file with EmailParser
     */
    async parseTestFile(fileContent, testFile) {
        if (!this.parser) {
            throw new Error('EmailParser not configured. Call setParser() first.');
        }

        try {
            // Create File-like object from content
            const blob = new Blob([fileContent], { type: 'message/rfc822' });
            const file = new File([blob], testFile.name, { type: 'message/rfc822' });
            
            // Parse with options based on test file
            const options = this.getParsingOptions(testFile);
            options.debug = true; // Enable debug for troubleshooting
            
            if (this.debug) {
                console.log(`    📝 File size: ${file.size} bytes`);
                console.log(`    📄 Content preview: ${fileContent.substring(0, 200)}...`);
            }
            
            const result = await this.parser.parse(file, options);
            
            if (this.debug) {
                console.log(`    🔍 Parser result:`, {
                    subject: result.subject,
                    from: result.from,
                    attachmentCount: result.attachments?.length || 0,
                    parserInfo: result.parserInfo
                });
            }
            
            return result;
            
        } catch (error) {
            if (this.debug) {
                console.log(`    💥 Parsing error: ${error.message}`);
            }
            throw error;
        }
    }

    /**
     * Get parsing options for test
     */
    getParsingOptions(testFile) {
        const options = {};
        
        // Force streaming for streaming tests
        if (testFile.path.includes('Streaming/')) {
            options.forceStreaming = true;
        }
        
        // Enable debug for error tests
        if (testFile.path.includes('Error/')) {
            options.debug = true;
        }
        
        return options;
    }

    /**
     * Validate parse result against expected
     */
    async validateResult(actual, expected) {
        const errors = [];
        let passed = true;

        // Validate basic email fields
        if (expected.subject && actual.subject !== expected.subject) {
            errors.push(`Subject mismatch: expected "${expected.subject}", got "${actual.subject}"`);
            passed = false;
        }

        if (expected.from && expected.from.email) {
            if (actual.from.email !== expected.from.email) {
                errors.push(`From email mismatch: expected "${expected.from.email}", got "${actual.from.email}"`);
                passed = false;
            }
        }

        // Validate attachments
        if (expected.attachments) {
            if (actual.attachments.length !== expected.attachments.length) {
                errors.push(`Attachment count mismatch: expected ${expected.attachments.length}, got ${actual.attachments.length}`);
                passed = false;
            }
            
            for (let i = 0; i < expected.attachments.length && i < actual.attachments.length; i++) {
                const expectedAtt = expected.attachments[i];
                const actualAtt = actual.attachments[i];
                
                if (expectedAtt.name && actualAtt.name !== expectedAtt.name) {
                    errors.push(`Attachment ${i} name mismatch: expected "${expectedAtt.name}", got "${actualAtt.name}"`);
                    passed = false;
                }
                
                if (expectedAtt.type && actualAtt.type !== expectedAtt.type) {
                    errors.push(`Attachment ${i} type mismatch: expected "${expectedAtt.type}", got "${actualAtt.type}"`);
                    passed = false;
                }
            }
        }

        // Validate processing mode for streaming tests
        if (expected.processingMode && actual.parserInfo) {
            if (actual.parserInfo.processingMode !== expected.processingMode) {
                errors.push(`Processing mode mismatch: expected "${expected.processingMode}", got "${actual.parserInfo.processingMode}"`);
                passed = false;
            }
        }

        // Validate memory usage
        if (expected.memoryUsage && actual.parserInfo?.memoryUsed) {
            if (expected.memoryUsage.max && actual.parserInfo.memoryUsed > expected.memoryUsage.max) {
                errors.push(`Memory usage exceeded: ${actual.parserInfo.memoryUsed} > ${expected.memoryUsage.max}`);
                passed = false;
            }
        }

        return { passed, errors };
    }

    /**
     * Record test result
     */
    recordTestResult(testName, result) {
        this.testResults.set(testName, result);
    }

    /**
     * Record performance metric
     */
    recordPerformanceMetric(testName, metrics) {
        this.performanceMetrics.set(testName, metrics);
    }

    /**
     * Generate final test report
     */
    generateFinalReport() {
        const duration = this.stats.endTime - this.stats.startTime;
        
        console.log('\n' + '='.repeat(50));
        console.log('🎯 SYNTHETIC TEST SUITE RESULTS');
        console.log('='.repeat(50));
        console.log(`📊 Total Tests: ${this.stats.totalTests}`);
        console.log(`✅ Passed: ${this.stats.passed} (${((this.stats.passed/this.stats.totalTests)*100).toFixed(1)}%)`);
        console.log(`❌ Failed: ${this.stats.failed} (${((this.stats.failed/this.stats.totalTests)*100).toFixed(1)}%)`);
        console.log(`⏱️  Duration: ${(duration/1000).toFixed(2)}s`);
        
        if (this.stats.failed > 0) {
            console.log('\n❌ FAILED TESTS:');
            for (const [testName, result] of this.testResults.entries()) {
                if (result.status === 'FAILED' || result.status === 'ERROR') {
                    console.log(`  - ${testName}: ${result.error || result.validation?.errors?.join(', ')}`);
                }
            }
        }
        
        // Performance summary
        console.log('\n📈 PERFORMANCE SUMMARY:');
        let totalDuration = 0;
        let streamingTests = 0;
        let traditionalTests = 0;
        
        for (const [testName, metrics] of this.performanceMetrics.entries()) {
            totalDuration += metrics.duration;
            if (metrics.processingMode === 'streaming') {
                streamingTests++;
            } else {
                traditionalTests++;
            }
        }
        
        console.log(`  - Average test duration: ${(totalDuration / this.stats.totalTests).toFixed(2)}ms`);
        console.log(`  - Streaming tests: ${streamingTests}`);
        console.log(`  - Traditional tests: ${traditionalTests}`);
        
        console.log('\n🎉 Test suite execution completed!');
    }

    /**
     * Get test results summary
     */
    getTestResults() {
        return {
            stats: this.stats,
            results: Array.from(this.testResults.entries()),
            performance: Array.from(this.performanceMetrics.entries())
        };
    }

    // ============================================================================
    // MOCK EMAIL GENERATORS (for initial testing)
    // ============================================================================

    generateSimpleTextEmail() {
        return `From: sender@example.com
To: recipient@example.com
Subject: Simple Text Email Test
Date: Wed, 17 Sep 2025 04:00:00 -0700
Message-ID: <test1@example.com>
MIME-Version: 1.0
Content-Type: text/plain; charset=utf-8

This is a simple text email for basic parsing test.

-- 
Test signature`;
    }

    generateMultipartEmail() {
        return `From: sender@example.com
To: recipient@example.com
Subject: Multipart Mixed Email Test
Date: Wed, 17 Sep 2025 04:00:00 -0700
Message-ID: <test2@example.com>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="----=_NextPart_000_001B_01C09E45.2D56F0E0"

------=_NextPart_000_001B_01C09E45.2D56F0E0
Content-Type: text/plain; charset=utf-8

This email has text and attachments.

------=_NextPart_000_001B_01C09E45.2D56F0E0
Content-Type: text/plain; name="test.txt"
Content-Disposition: attachment; filename="test.txt"
Content-Transfer-Encoding: base64

VGhpcyBpcyBhIHRlc3QgZmlsZSBhdHRhY2htZW50LgpJdCBjb250YWlucyBzb21lIHNhbXBsZSB0
ZXh0IGRhdGEu

------=_NextPart_000_001B_01C09E45.2D56F0E0
Content-Type: application/pdf; name="test.pdf"
Content-Disposition: attachment; filename="test.pdf"
Content-Transfer-Encoding: base64

JVBERi0xLjQKJfbk/N8KMSAwIG9iago8PAovVHlwZSAvUGFnZXMKL0tpZHMgWzIgMCBSXQovQ291
bnQgMQovTWVkaWFCb3ggWzAgMCA2MTIgNzkyXQo+PgplbmRvYmoK

------=_NextPart_000_001B_01C09E45.2D56F0E0--`;
    }

    generateLargeBodyEmail() {
        const largeText = 'This is a large email body that will trigger streaming mode. '.repeat(50000);
        
        return `From: sender@example.com
To: recipient@example.com
Subject: Large Body Email Test (Streaming)
Date: Wed, 17 Sep 2025 04:00:00 -0700
Message-ID: <test3@example.com>
MIME-Version: 1.0
Content-Type: text/plain; charset=utf-8

${largeText}

End of large email body.`;
    }
}

// Browser compatibility
if (typeof window !== 'undefined') {
    window.SyntheticTestRunner = SyntheticTestRunner;
}

// Node.js compatibility
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SyntheticTestRunner;
}
