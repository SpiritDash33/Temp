/**
 * Node.js Test Runner for Enhanced Email Parser
 * Tests the parser against real sample files to identify issues
 */
const fs = require('fs');
const path = require('path');

// Import the parser modules (adapted for Node.js)
const { OLEParser } = require('./OLEParser.js');
const { RTFDecompressor } = require('./RTFDecompressor.js');
const { MSGExtractor } = require('./MSGExtractor.js');
const { EMLParser } = require('./EMLParser.js');
const EmailParser = require('./EmailParser.js');

async function testSampleFiles() {
    console.log('🚀 Enhanced Email Parser - Real File Testing');
    console.log('='.repeat(50));
    
    const parser = new EmailParser();
    parser.setDebug(true);
    
    const sampleFiles = [
        {
            name: 'EML Sample',
            path: '../Sample_emails/eml/dsefwefwe.eml',
            type: 'eml'
        },
        {
            name: 'MSG Sample', 
            path: '../Sample_emails/Msg/401K Account Notification.msg',
            type: 'msg'
        }
    ];
    
    for (const sample of sampleFiles) {
        console.log(`\n📧 Testing: ${sample.name}`);
        console.log('-'.repeat(30));
        
        try {
            const filePath = path.resolve(__dirname, sample.path);
            console.log(`📂 File: ${filePath}`);
            
            if (!fs.existsSync(filePath)) {
                console.log(`❌ File not found: ${filePath}`);
                continue;
            }
            
            // Read file as buffer
            const fileBuffer = fs.readFileSync(filePath);
            console.log(`📊 File size: ${fileBuffer.length} bytes`);
            
            // Create a File-like object for Node.js
            const file = {
                name: path.basename(filePath),
                size: fileBuffer.length,
                arrayBuffer: () => Promise.resolve(fileBuffer.buffer.slice(
                    fileBuffer.byteOffset, 
                    fileBuffer.byteOffset + fileBuffer.byteLength
                )),
                text: () => Promise.resolve(fileBuffer.toString('utf8'))
            };
            
            const startTime = process.hrtime.bigint();
            const email = await parser.parse(file, {
                extractPlainText: true,
                processAttachments: true,
                extractAttachmentText: true
            });
            const endTime = process.hrtime.bigint();
            const duration = Number(endTime - startTime) / 1000000; // Convert to milliseconds
            
            console.log(`✅ Parse successful! (${duration.toFixed(2)}ms)`);
            
            // Display results
            displayResults(email, sample.type);
            
        } catch (error) {
            console.log(`❌ Parse failed: ${error.message}`);
            console.log(`   Stack: ${error.stack?.split('\n')[1]?.trim()}`);
        }
    }
    
    // Display parser statistics
    console.log('\n📊 Parser Statistics:');
    console.log('-'.repeat(30));
    const stats = parser.getStats();
    console.log(`Files processed: ${stats.filesProcessed}`);
    console.log(`Total size: ${formatBytes(stats.totalSize)}`);
    console.log(`Success rate: ${stats.filesProcessed > 0 ? Math.round(((stats.filesProcessed - stats.errors) / stats.filesProcessed) * 100) : 0}%`);
    console.log(`Average duration: ${Math.round(stats.averageDuration || 0)}ms`);
    console.log(`Errors: ${stats.errors}`);
}

function displayResults(email, type) {
    console.log('\n📋 PARSING RESULTS:');
    console.log(`   Subject: ${email.subject || 'No Subject'}`);
    console.log(`   From: ${formatAddress(email.from)}`);
    console.log(`   To: ${formatAddressList(email.to)}`);
    console.log(`   Date: ${email.date ? email.date.toISOString() : 'No Date'}`);
    
    console.log('\n📝 BODY CONTENT:');
    console.log(`   Text: ${email.body.text ? email.body.text.length + ' chars' : 'None'}`);
    console.log(`   HTML: ${email.body.html ? email.body.html.length + ' chars' : 'None'}`);
    console.log(`   RTF: ${email.body.rtf ? email.body.rtf.length + ' chars' : 'None'}`);
    console.log(`   Plain Text Extracted: ${email.plainText ? email.plainText.length + ' chars' : 'None'}`);
    
    console.log('\n📎 ATTACHMENTS:');
    if (email.attachments && email.attachments.length > 0) {
        email.attachments.forEach((att, i) => {
            console.log(`   [${i + 1}] ${att.name || 'Unknown'} (${att.type || 'unknown'}, ${formatBytes(att.size || 0)})`);
        });
    } else {
        console.log('   None');
    }
    
    console.log('\n🔗 EMBEDDED MESSAGES:');
    if (email.threads && email.threads.length > 0) {
        email.threads.forEach((thread, i) => {
            console.log(`   [${i + 1}] ${thread.subject || 'No Subject'}`);
        });
    } else {
        console.log('   None');
    }
    
    console.log('\n🔧 TECHNICAL INFO:');
    console.log(`   Parser: ${email.parserInfo.type} v${email.parserInfo.version}`);
    console.log(`   Headers: ${email.headers instanceof Map ? email.headers.size : 'None'}`);
    console.log(`   Metadata: ${Object.keys(email.metadata).length} fields`);
    
    if (email.fragments && email.fragments.length > 0) {
        console.log(`   Fragments: ${email.fragments.length}`);
    }
    
    // Show sample text content
    if (email.body.text) {
        console.log('\n📖 SAMPLE TEXT CONTENT:');
        console.log('   ' + email.body.text.substring(0, 200).replace(/\n/g, '\\n') + 
                   (email.body.text.length > 200 ? '...' : ''));
    }
    
    // Show RTF conversion if available
    if (email.body.rtf) {
        console.log('\n🔄 RTF PROCESSING TEST:');
        try {
            const rtfDecompressor = new RTFDecompressor();
            const rtfText = rtfDecompressor.rtfToPlainText(email.body.rtf);
            console.log(`   RTF to Text: ${rtfText ? rtfText.length + ' chars' : 'Failed'}`);
            if (rtfText) {
                console.log('   Sample: ' + rtfText.substring(0, 100).replace(/\n/g, '\\n') + '...');
            }
        } catch (error) {
            console.log(`   RTF Processing Error: ${error.message}`);
        }
    }
}

function formatAddress(addr) {
    if (!addr) return 'No Address';
    if (addr.name && addr.email) {
        return `${addr.name} <${addr.email}>`;
    }
    return addr.email || addr.name || 'Unknown';
}

function formatAddressList(addresses) {
    if (!addresses || addresses.length === 0) return 'None';
    return addresses.map(addr => formatAddress(addr)).join(', ');
}

function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
}

// Run the tests
if (require.main === module) {
    testSampleFiles().catch(error => {
        console.error('❌ Test runner failed:', error);
        process.exit(1);
    });
}

module.exports = { testSampleFiles };
