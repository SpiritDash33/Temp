/**
 * Memory Manager for Streaming Email Parser
 * Efficient memory usage tracking and optimization
 * Provides GC-friendly chunk processing and memory monitoring
 */
class MemoryManager {
    constructor(options = {}) {
        this.maxMemory = options.maxMemory || 10 * 1024 * 1024; // 10MB default
        this.gcThreshold = options.gcThreshold || 0.8; // 80% of max memory
        this.monitorInterval = options.monitorInterval || 1000; // 1 second
        this.enableDetailedTracking = options.enableDetailedTracking !== false;

        this.memoryStats = this.initializeMemoryStats();
        this.memoryProfile = new Map();
        this.gcHistory = [];
        this.monitoringActive = false;

        if (options.debug) {
            console.log('MemoryManager initialized with max memory:', this.maxMemory, 'bytes');
        }
    }

    initializeMemoryStats() {
        return {
            peakUsage: 0,
            currentUsage: 0,
            gcCycles: 0,
            deallocated: 0,
            allocated: 0,
            averageChunkSize: 0,
            largestAllocation: 0,
            chunksProcessed: 0,
            allocationsByType: new Map(),
            lastGcTime: 0,
            gcDurationTotal: 0
        };
    }

    /**
     * Track memory allocation
     */
    trackAllocation(type, size, context = null) {
        const allocation = {
            type: type,
            size: size,
            context: context,
            timestamp: performance.now(),
            id: this.generateAllocationId(),
            isActive: true
        };

        this.memoryStats.allocated += size;
        this.memoryStats.allocationsByType.set(type,
            (this.memoryStats.allocationsByType.get(type) || 0) + size);

        this.memoryProfile.set(allocation.id, allocation);

        // Track peak and largest
        this.memoryStats.currentUsage += size;
        if (size > this.memoryStats.largestAllocation) {
            this.memoryStats.largestAllocation = size;
        }
        if (this.memoryStats.currentUsage > this.memoryStats.peakUsage) {
            this.memoryStats.peakUsage = this.memoryStats.currentUsage;
        }

        if (this.enableDetailedTracking) {
            this.logAllocation(allocation);
        }

        return allocation.id;
    }

    /**
     * Track memory deallocation
     */
    trackDeallocation(allocationId) {
        const allocation = this.memoryProfile.get(allocationId);

        if (!allocation) {
            console.warn('Attempted deallocation of unknown allocation:', allocationId);
            return false;
        }

        if (!allocation.isActive) {
            console.warn('Double deallocation detected:', allocationId);
            return false;
        }

        allocation.isActive = false;
        allocation.deallocatedAt = performance.now();

        this.memoryStats.deallocated += allocation.size;
        this.memoryStats.currentUsage -= allocation.size;

        if (this.enableDetailedTracking) {
            this.logDeallocation(allocation);
        }

        return true;
    }

    /**
     * Track chunk processing for memory profiling
     */
    trackChunkProcessing(chunkSize, processingTime, success = true) {
        this.memoryStats.chunksProcessed++;

        // Update average chunk size
        const totalSize = this.memoryStats.averageChunkSize * (this.memoryStats.chunksProcessed - 1) + chunkSize;
        this.memoryStats.averageChunkSize = totalSize / this.memoryStats.chunksProcessed;

        // Store processing context if detailed tracking
        if (this.enableDetailedTracking) {
            this.memoryProfile.set(`chunk_${this.memoryStats.chunksProcessed}`, {
                type: 'chunk',
                size: chunkSize,
                processingTime,
                success,
                timestamp: performance.now()
            });
        }
    }

    /**
     * Check if memory usage is approaching limits
     */
    checkMemoryPressure() {
        const pressureRatio = this.memoryStats.currentUsage / this.maxMemory;
        return {
            pressure: pressureRatio,
            needsGc: pressureRatio > this.gcThreshold,
            critical: pressureRatio > 0.95,
            recommendedAction: this.getRecommendedAction(pressureRatio)
        };
    }

    getRecommendedAction(pressureRatio) {
        if (pressureRatio > 0.95) {
            return 'CRITICAL: Force GC immediately';
        } else if (pressureRatio > this.gcThreshold) {
            return 'HIGH: Trigger GC cycle';
        } else if (pressureRatio > 0.6) {
            return 'MEDIUM: Monitor closely';
        } else {
            return 'LOW: Normal operation';
        }
    }

    /**
     * Perform memory optimization
     */
    async optimizeMemory() {
        const gcStartTime = performance.now();

        // Force garbage collection if available
        this.forceGarbageCollection();

        const gcDuration = performance.now() - gcStartTime;
        this.memoryStats.gcDurationTotal += gcDuration;
        this.memoryStats.gcCycles++;
        this.memoryStats.lastGcTime = performance.now();

        this.gcHistory.push({
            timestamp: performance.now(),
            duration: gcDuration,
            memoryBefore: this.memoryStats.currentUsage
        });

        // Clean up stale allocations
        await this.cleanupStaleAllocations();

        return {
            gcDuration,
            memoryFreed: this.calculateMemoryFreed(),
            remainingUsage: this.memoryStats.currentUsage
        };
    }

    forceGarbageCollection() {
        // Browser environments
        if (typeof window !== 'undefined') {
            if (window.gc && typeof window.gc === 'function') {
                window.gc();
            } else if (typeof window !== 'undefined' && window.navigator &&
                       /Chrome|Edge/.test(window.navigator.userAgent)) {
                // Force GC in Chrome (experimental)
                console.log('Memory optimization requested');
            }
        }

        // Node.js environments
        if (typeof global !== 'undefined' && global.gc) {
            global.gc();
        }

        // Alternative: Create and discard a large temporary object to trigger GC
        if (typeof global === 'undefined' || !global.gc) {
            this.induceGarbageCollection();
        }
    }

    induceGarbageCollection() {
        // Create temporary large object to encourage GC
        try {
            const tempArray = new Array(100).fill(0).map(() => new Uint8Array(1024));
            // Let it go out of scope immediately
        } catch (e) {
            // Ignore errors in constrained environments
        }
    }

    async cleanupStaleAllocations() {
        const now = performance.now();
        const staleThreshold = 60000; // 60 seconds
        let cleanedCount = 0;

        for (const [id, allocation] of this.memoryProfile.entries()) {
            // Mark allocations as stale if they've been inactive for too long
            if (!allocation.isActive && now - allocation.timestamp > staleThreshold) {
                this.memoryProfile.delete(id);
                cleanedCount++;
            }
        }

        if (this.enableDetailedTracking && cleanedCount > 0) {
            console.log(`Cleaned up ${cleanedCount} stale memory allocations`);
        }

        return cleanedCount;
    }

    calculateMemoryFreed() {
        // Estimate memory freed by GC cycle
        // In a real implementation, would need browser/Node.js memory APIs
        const recentHistory = this.gcHistory.slice(-2);
        if (recentHistory.length >= 2) {
            return Math.max(0, recentHistory[0].memoryBefore - this.memoryStats.currentUsage);
        }
        return 0;
    }

    /**
     * Generate unique allocation ID
     */
    generateAllocationId() {
        return `alloc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    /**
     * Logging for detailed tracking
     */
    logAllocation(allocation) {
        const sizeMB = Math.round(allocation.size / 1024 / 1024 * 100) / 100;
        console.log(`[Memory] +${sizeMB}MB ${allocation.type}${allocation.context ? ` (${allocation.context})` : ''}`);
    }

    logDeallocation(allocation) {
        const sizeMB = Math.round(allocation.size / 1024 / 1024 * 100) / 100;
        const duration = allocation.deallocatedAt - allocation.timestamp;
        console.log(`[Memory] -${sizeMB}MB ${allocation.type} (lived ${duration.toFixed(0)}ms)`);
    }

    /**
     * Start memory monitoring
     */
    startMonitoring(callback = null) {
        if (this.monitoringActive) return;

        this.monitoringActive = true;

        this.monitoringInterval = setInterval(() => {
            const pressure = this.checkMemoryPressure();

            if (callback) {
                callback(pressure, this.getMemoryStats());
            }

            // Auto-optimize if memory pressure is high
            if (pressure.needsGc) {
                this.optimizeMemory();
            }
        }, this.monitorInterval);

        if (this.enableDetailedTracking) {
            console.log('Memory monitoring started with', this.monitorInterval, 'ms interval');
        }
    }

    /**
     * Stop memory monitoring
     */
    stopMonitoring() {
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
            this.monitoringInterval = undefined;
        }
        this.monitoringActive = false;

        if (this.enableDetailedTracking) {
            console.log('Memory monitoring stopped');
        }
    }

    /**
     * Get comprehensive memory statistics
     */
    getMemoryStats() {
        const pressure = this.checkMemoryPressure();

        return {
            ...this.memoryStats,
            pressure: pressure.pressure,
            memoryEfficiency: this.calculateMemoryEfficiency(),
            allocationBreakdown: this.getAllocationBreakdown(),
            gcEfficiency: this.calculateGcEfficiency(),
            isMonitoringActive: this.monitoringActive,
            pressureLevel: pressure.recommendedAction
        };
    }

    getAllocationBreakdown() {
        const breakdown = {};
        for (const [type, size] of this.memoryStats.allocationsByType.entries()) {
            breakdown[type] = {
                totalSize: size,
                percentage: size / this.memoryStats.peakUsage,
                allocationCount: Array.from(this.memoryProfile.values())
                    .filter(a => a.type === type).length
            };
        }
        return breakdown;
    }

    calculateMemoryEfficiency() {
        if (this.memoryStats.allocated === 0) return 1;

        const efficiency = this.memoryStats.deallocated / this.memoryStats.allocated;
        return Math.max(0, Math.min(1, efficiency));
    }

    calculateGcEfficiency() {
        if (this.gcHistory.length === 0) return 0;

        const totalFreed = this.gcHistory.reduce((sum, gc) => sum + this.calculateMemoryFreedForHistory(gc), 0);
        const totalAllocated = this.memoryStats.allocated;

        return totalAllocated > 0 ? totalFreed / totalAllocated : 0;
    }

    calculateMemoryFreedForHistory(gcRecord) {
        // Simplified calculation for GC history
        return Math.max(0, gcRecord.memoryBefore - this.memoryStats.currentUsage);
    }

    /**
     * Reset memory statistics
     */
    resetStats() {
        this.memoryStats = this.initializeMemoryStats();
        this.memoryProfile.clear();
        this.gcHistory.length = 0;
    }

    /**
     * Get memory profile summary
     */
    getMemoryProfileSummary() {
        const activeAllocations = Array.from(this.memoryProfile.values()).filter(a => a.isActive);
        const types = Array.from(new Set(activeAllocations.map(a => a.type)));

        return {
            totalAllocations: this.memoryProfile.size,
            activeAllocations: activeAllocations.length,
            allocationTypes: types,
            typeBreakdown: types.map(type => ({
                type: type,
                count: activeAllocations.filter(a => a.type === type).length,
                totalSize: activeAllocations
                    .filter(a => a.type === type)
                    .reduce((sum, a) => sum + a.size, 0)
            }))
        };
    }

    /**
     * Export memory profile for analysis
     */
    exportMemoryProfile() {
        return {
            stats: this.getMemoryStats(),
            profile: Array.from(this.memoryProfile.entries()).map(([id, alloc]) => ({
                id,
                ...alloc,
                lifeTime: alloc.isActive ? performance.now() - alloc.timestamp :
                           alloc.deallocatedAt - alloc.timestamp
            })),
            gcHistory: this.gcHistory,
            metadata: {
                exportTime: new Date().toISOString(),
                version: '1.0',
                totalProfileSize: this.memoryProfile.size,
                monitoringDuration: performance.now() - (this.memoryStats.startTime || performance.now())
            }
        };
    }

    /**
     * Import memory profile (for testing/debugging)
     */
    importMemoryProfile(exportData) {
        if (!exportData || typeof exportData !== 'object' || !exportData.stats || !exportData.profile) {
            throw new Error('Invalid memory profile format');
        }

        // Safely validate and copy stats
        if (typeof exportData.stats === 'object') {
            this.memoryStats = { ...this.initializeMemoryStats(), ...exportData.stats };
        }
        
        // Safely import profile data
        if (Array.isArray(exportData.profile)) {
            this.memoryProfile = new Map(exportData.profile.filter(p => p && p.id).map(p => [p.id, p]));
        }
        
        // Safely import GC history
        if (Array.isArray(exportData.gcHistory)) {
            this.gcHistory = exportData.gcHistory.slice(0, 100); // Limit size
        }
    }
}

// Enhanced tracking for streaming parsers
class StreamingMemoryTracker {
    constructor(memoryManager) {
        this.memoryManager = memoryManager;
        this.chunkAllocations = new Map();
    }

    trackChunkAllocation(chunkId, size, data) {
        const allocationId = this.memoryManager.trackAllocation(
            'streaming_chunk',
            size,
            `chunk_${chunkId}`
        );

        this.chunkAllocations.set(chunkId, {
            allocationId,
            size,
            timestamp: performance.now(),
            data: data // Keep reference for cleanup
        });

        return allocationId;
    }

    deallocateChunk(chunkId) {
        const chunkInfo = this.chunkAllocations.get(chunkId);

        if (!chunkInfo) {
            console.warn(`Chunk ${chunkId} not found in allocation tracker`);
            return false;
        }

        const success = this.memoryManager.trackDeallocation(chunkInfo.allocationId);

        if (success) {
            // Clear references to help GC
            chunkInfo.data = null;
            this.chunkAllocations.delete(chunkId);
        }

        return success;
    }

    getActiveChunks() {
        return Array.from(this.chunkAllocations.entries()).map(([id, info]) => ({
            id,
            size: info.size,
            age: performance.now() - info.timestamp
        }));
    }

    clearStaleChunks(maxAge = 30000) { // 30 seconds
        const now = performance.now();
        const staleChunks = [];

        for (const [chunkId, info] of this.chunkAllocations.entries()) {
            if (now - info.timestamp > maxAge) {
                staleChunks.push(chunkId);
            }
        }

        let freedCount = 0;
        for (const chunkId of staleChunks) {
            if (this.deallocateChunk(chunkId)) {
                freedCount++;
            }
        }

        return freedCount;
    }
}

// Browser compatibility
if (typeof window !== 'undefined') {
    window.MemoryManager = MemoryManager;
    window.StreamingMemoryTracker = StreamingMemoryTracker;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { MemoryManager, StreamingMemoryTracker };
}
