/**
 * Streaming EML Parser for Large RFC5322/MIME Files
 * Processes RFC5322/MIME email files in memory-efficient chunks
 * Maintains compatibility with Enhanced EML Parser recovery features
 */
class StreamingEMLParser extends EMLParser {
    constructor(options = {}) {
        super();
        this.chunkSize = options.chunkSize || 64 * 1024; // 64KB for EML (smaller chunks due to line-based parsing)
        this.maxMemory = options.maxMemory || 8 * 1024 * 1024; // 8MB for EML
        this.debug = options.debug || false;
        this.enableBoundaryDetection = options.enableBoundaryDetection !== false;

        // Streaming state tracking
        this.headerBuffer = '';
        this.headersParsed = false;
        this.bodyStarted = false;
        this.mimeBoundaries = new Map();
        this.attachmentStreams = new Set();
        this.currentMimePart = null;

        // Memory and progress tracking
        this.memoryManager = options.memoryManager || new MemoryManager({ debug: this.debug });
        this.streamingTracker = new StreamingMemoryTracker(this.memoryManager);

        if (this.debug) {
            console.log('StreamingEMLParser initialized with chunk size:', this.chunkSize, 'bytes');
        }
    }

    /**
     * Stream parse EML file in line-oriented chunks
     */
    async parseFileStream(file, options = {}) {
        const startTime = performance.now();
        this.processingState = 'initializing';

        try {
            const fileSize = file.size;
            const chunkCount = Math.ceil(fileSize / this.chunkSize);

            // Start memory monitoring
            this.memoryManager.startMonitoring();

            const results = [];
            let headers = new Map();
            let body = { text: '', html: '', enriched: '' };
            let attachments = [];
            let boundary = null;

            // Step 1: Stream header processing
            if (this.debug) console.log('Streaming EML: Processing headers');
            const headerResult = await this.streamHeaderProcessing(file, options);
            headers = headerResult.headers;
            boundary = headerResult.boundary;
            results.push(headerResult);

            // Step 2: Stream body processing with MIME parts
            if (this.debug) console.log('Streaming EML: Processing body and MIME parts');
            const bodyResult = await this.streamBodyProcessing(file, boundary, headerResult.lastOffset, options);
            body = bodyResult.body;
            attachments = bodyResult.attachments;
            results.push(bodyResult);

            // Merge results
            const finalResult = this.mergeStreamingEMLResults(headers, body, attachments);

            this.processingState = 'completed';

            if (this.debug) {
                const duration = performance.now() - startTime;
                console.log(`Streaming EML completed in ${duration.toFixed(2)}ms`);
            }

            return finalResult;

        } catch (error) {
            this.processingState = 'error';
            throw new Error(`Streaming EML parse failed: ${error.message}`);
        } finally {
            // Clean up
            this.cleanupStreamingEML();
            this.memoryManager.stopMonitoring();
        }
    }

    /**
     * Stream parse email headers
     */
    async streamHeaderProcessing(file, options) {
        if (!file) {
            throw new Error('File parameter is required for header processing');
        }

        this.headerBuffer = '';
        const headerLines = [];
        let offset = 0;
        let hasMoreChunks = true;

        while (hasMoreChunks && !this.headersParsed) {
            const chunk = await this.readHeaderChunk(file, offset, this.chunkSize);
            const chunkResult = await this.processHeaderChunk(chunk, options);

            offset = chunkResult.newOffset;
            this.headerBuffer += chunkResult.remaining || '';
            headerLines.push(...chunkResult.lines);
            hasMoreChunks = chunkResult.hasMoreChunks;

            // Memory management
            if (this.memoryManager && this.memoryManager.optimizeMemory) {
                await this.memoryManager.optimizeMemory();
            }
        }

        // Parse collected headers
        const headers = this.parseStreamingHeaders(headerLines);
        const boundary = this.extractMIMEBoundary(headers);

        return {
            type: 'header_chunks',
            success: true,
            headers: headers,
            boundary: boundary,
            headerLinesCount: headerLines.length,
            size: this.headerBuffer.length,
            lastOffset: offset
        };
    }

    /**
     * Read chunk optimized for header processing
     */
    async readHeaderChunk(file, offset, size) {
        const chunkSize = Math.min(size, file.size - offset);
        const arrayBuffer = await file.slice(offset, offset + chunkSize).arrayBuffer();

        const allocationId = this.streamingTracker.trackChunkAllocation(
            `header_chunk_${offset}`, arrayBuffer.byteLength, arrayBuffer);

        return {
            data: arrayBuffer,
            offset: offset,
            size: arrayBuffer.byteLength,
            allocationId
        };
    }

    /**
     * Process header chunk and accumulate lines
     */
    async processHeaderChunk(chunk, options) {
        const decoder = new TextDecoder('utf-8', { fatal: false });
        const chunkText = decoder.decode(chunk.data);

        // Combine with previous buffer
        const fullText = this.headerBuffer + chunkText;
        const lines = fullText.split(/(\r?\n)/).filter(line => line.trim().length > 0);

        let lastCompleteLine = 0;
        const completeLines = [];

        // Find last complete line (for incremental processing)
        for (let i = 0; i < lines.length; i++) {
            if (lines[i].match(/^\S/) && lines[i].endsWith('\n')) {
                // Start of new header field
                continue;
            }

            if (lines[i].endsWith('\n')) {
                lastCompleteLine = i;
            } else {
                break; // Current line is incomplete
            }
        }

        // Extract complete lines
        completeLines.push(...lines.slice(0, lastCompleteLine + 1));

        // Store remaining buffer for next chunk
        const remaining = lines.slice(lastCompleteLine + 1).join('\n');

        // Check for headers end (empty line)
        const headersEndIndex = completeLines.findIndex(line => line.trim() === '');
        const headersComplete = headersEndIndex !== -1;

        if (headersComplete) {
            this.headersParsed = true;
            completeLines.splice(headersEndIndex + 1); // Remove body start
        }

        return {
            newOffset: chunk.offset + chunk.size,
            lines: completeLines,
            remaining: remaining,
            hasMoreChunks: !headersComplete && (chunk.offset + chunk.size) < file.size,
            headersComplete
        };
    }

    /**
     * Parse accumulated header lines
     */
    parseStreamingHeaders(lines) {
        const headers = new Map();
        let currentHeader = '';
        let currentValue = '';

        for (const line of lines) {
            if (line.match(/^\S/) && currentHeader) {
                // Start of new header, save previous
                headers.set(currentHeader, currentValue);
                currentValue = '';

                // Parse new header
                const colonIndex = line.indexOf(':');
                if (colonIndex > 0) {
                    currentHeader = line.substring(0, colonIndex).trim();
                    currentValue = line.substring(colonIndex + 1).trim();
                }
            } else if (currentHeader) {
                // Continuation of previous header
                currentValue += ' ' + line.trim();
            } else {
                // First header
                const colonIndex = line.indexOf(':');
                if (colonIndex > 0) {
                    currentHeader = line.substring(0, colonIndex).trim();
                    currentValue = line.substring(colonIndex + 1).trim();
                }
            }
        }

        // Save last header
        if (currentHeader) {
            headers.set(currentHeader, currentValue);
        }

        return headers;
    }

    /**
     * Extract MIME boundary for multipart processing
     */
    extractMIMEBoundary(headers) {
        const contentType = headers.get('content-type') || headers.get('Content-Type');

        if (!contentType) return null;

        const boundaryMatch = contentType.match(/boundary\s*=\s*["']?([^;"'\s]+)["']?/i);
        return boundaryMatch ? boundaryMatch[1] : null;
    }

    /**
     * Stream parse email body and MIME parts
     */
    async streamBodyProcessing(file, boundary, startOffset, options) {
        const body = { text: '', html: '', enriched: '', attachments: [] };
        const attachments = [];

        if (!boundary) {
            // Simple body without multipart
            const result = await this.streamSimpleBody(file, startOffset, options);
            body.text = result.text;
            body.html = result.html || '';
        } else {
            // Multipart MIME processing
            const multipartResult = await this.streamMultipartProcessing(file, boundary, startOffset, options);
            body.text = multipartResult.text;
            body.html = multipartResult.html;
            attachments.push(...multipartResult.attachments);
        }

        return {
            type: 'body_chunks',
            success: true,
            body: body,
            attachments: attachments,
            multipart: boundary !== null,
            size: body.text.length + (body.html ? body.html.length : 0)
        };
    }

    /**
     * Stream simple body (no MIME multipart)
     */
    async streamSimpleBody(file, startOffset, options) {
        const decoder = new TextDecoder('utf-8', { fatal: false });
        const lines = [];
        let currentLine = '';

        let offset = startOffset;
        while (offset < file.size) {
            const chunkSize = Math.min(this.chunkSize, file.size - offset);
            const arrayBuffer = await file.slice(offset, offset + chunkSize).arrayBuffer();
            const chunkText = decoder.decode(arrayBuffer);

            const allocationId = this.streamingTracker.trackChunkAllocation(
                `body_chunk_${offset}`, arrayBuffer.byteLength, arrayBuffer);

            // Process line by line
            for (let i = 0; i < chunkText.length; i++) {
                const char = chunkText[i];

                if (char === '\n') {
                    lines.push(currentLine + char);
                    currentLine = '';
                } else {
                    currentLine += char;
                }
            }

            offset += chunkSize;

            // Memory cleanup
            this.streamingTracker.deallocateChunk(`body_chunk_${offset}`);
        }

        // Join final body text
        return {
            text: lines.join(''),
            html: null
        };
    }

    /**
     * Stream multipart MIME processing
     */
    async streamMultipartProcessing(file, boundary, startOffset, options) {
        const decoder = new TextDecoder('utf-8', { fatal: false });
        const parts = [];
        let currentPart = null;
        let inBoundary = false;

        let offset = startOffset;
        let remainingBuffer = '';

        while (offset < file.size) {
            const chunkSize = Math.min(this.chunkSize, file.size - offset);
            const arrayBuffer = await file.slice(offset, offset + chunkSize).arrayBuffer();
            const chunkText = decoder.decode(arrayBuffer);

            const allocationId = this.streamingTracker.trackChunkAllocation(
                `multipart_chunk_${offset}`, arrayBuffer.byteLength, arrayBuffer);

            // Process MIME boundaries
            const result = this.processMIMEChunk(chunkText, boundary, remainingBuffer);

            if (result.parts && result.parts.length > 0) {
                parts.push(...result.parts);
            }

            remainingBuffer = result.remaining || '';
            offset += chunkSize;

            // Memory cleanup
            this.streamingTracker.deallocateChunk(`multipart_chunk_${offset}`);

            // Memory management
            if (offset % (this.chunkSize * 5) === 0) { // Every 5 chunks
                await this.memoryManager.optimizeMemory();
            }
        }

        // Process remaining parts
        if (remainingBuffer) {
            const finalParts = this.processMIMEChunk(remainingBuffer, boundary, '', true);
            if (finalParts.parts && finalParts.parts.length > 0) {
                parts.push(...finalParts.parts);
            }
        }

        return this.processStreamingMIMEParts(parts);
    }

    /**
     * Process MIME chunk and extract parts
     */
    processMIMEChunk(chunkText, boundary, buffer, isLastChunk = false) {
        const fullText = buffer + chunkText;
        const lines = fullText.split(/\r?\n/);
        const parts = [];
        let currentContent = '';
        let currentHeaders = {};
        let inPart = false;
        let remaining = '';

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];

            const boundaryStartPattern = new RegExp(`^--${boundary}\\s*$`);
            const boundaryEndPattern = new RegExp(`^--${boundary}--\\s*$`);

            if (boundaryEndPattern.test(line)) {
                // End of multipart
                break;
            } else if (boundaryStartPattern.test(line)) {
                // Start of new part
                if (inPart && currentContent) {
                    parts.push({
                        headers: currentHeaders,
                        content: currentContent
                    });
                }

                currentHeaders = {};
                currentContent = '';
                inPart = true;
            } else if (inPart) {
                // Content line
                if (Object.keys(currentHeaders).length === 0) {
                    // Still in headers
                    if (line.trim() === '') {
                        // Headers done
                    } else {
                        const colonIndex = line.indexOf(':');
                        if (colonIndex > 0) {
                            const headerName = line.substring(0, colonIndex).trim().toLowerCase();
                            const headerValue = line.substring(colonIndex + 1).trim();
                            currentHeaders[headerName] = headerValue;
                        }
                    }
                } else {
                    // Body content
                    currentContent += line + '\n';
                }
            }
        }

        // Handle remaining content
        if (isLastChunk && inPart && currentContent) {
            parts.push({
                headers: currentHeaders,
                content: currentContent
            });
        }

        return {
            parts: parts,
            remaining: currentContent // Last incomplete part
        };
    }

    /**
     * Process streaming MIME parts into structured content
     */
    processStreamingMIMEParts(parts) {
        let mainText = '';
        let mainHtml = '';
        const attachments = [];

        for (const part of parts) {
            const contentType = part.headers['content-type'] || 'text/plain';
            const contentTransferEncoding = part.headers['content-transfer-encoding'] || 'plain';
            const contentDisposition = part.headers['content-disposition'] || '';
            const filename = this.extractFilenameFromDisposition(contentDisposition) ||
                           this.extractFilenameFromHeaders(part.headers);

            // Decode content based on encoding
            let content = this.decodeContent(part.content, contentTransferEncoding);

            if (contentType.startsWith('text/plain')) {
                if (!mainText) {
                    mainText = content;
                }
            } else if (contentType.startsWith('text/html')) {
                if (!mainHtml) {
                    mainHtml = content;
                }
            } else {
                // Treat as attachment
                const attachment = {
                    name: filename || 'attachment',
                    data: typeof content === 'string' ? new TextEncoder().encode(content) : content,
                    type: contentType,
                    encoding: contentTransferEncoding,
                    disposition: contentDisposition,
                    filename: filename,
                    content: content,
                    size: content?.length || 0
                };

                attachments.push(attachment);
            }
        }

        return {
            text: mainText,
            html: mainHtml,
            attachments: attachments
        };
    }

    /**
     * Decode content based on transfer encoding
     */
    decodeContent(content, encoding) {
        if (!content) return '';

        switch (encoding.toLowerCase()) {
            case 'base64':
                try {
                    const cleanBase64 = content.replace(/\s/g, '').replace(/[^\w\+\/\=]/g, '');
                    return new TextDecoder('utf-8', { fatal: false })
                        .decode(this.base64ToArrayBuffer(cleanBase64));
                } catch (error) {
                    if (this.debug) {
                        console.warn('Base64 decode failed:', error.message);
                    }
                    return content; // Fallback to original
                }

            case 'quoted-printable':
                return this.decodeQuotedPrintable(content);

            case '7bit':
            case '8bit':
            case 'binary':
            case 'plain':
            default:
                return content;
        }
    }

    /**
     * Extract filename from Content-Disposition
     */
    extractFilenameFromDisposition(disposition) {
        const filenameMatch = disposition.match(/filename\s*=\s*["']?([^;"']+)["']?/i);
        return filenameMatch ? filenameMatch[1] : null;
    }

    /**
     * Extract filename from headers (Content-Type name parameter)
     */
    extractFilenameFromHeaders(headers) {
        const contentType = headers['content-type'] || '';

        if (!contentType) return null;

        const nameMatch = contentType.match(/name\s*=\s*["']?([^;"']+)["']?/i);
        return nameMatch ? nameMatch[1] : null;
    }

    /**
     * Decode Quoted-Printable encoding
     */
    decodeQuotedPrintable(content) {
        return content
            .replace(/\r\n$/g, '') // Remove trailing CRLF
            .replace(/\r\n/g, '\n') // Convert CRLF to LF
            .replace(/=((\d|[A-F]){2})/gi, (match, hex) => {
                return String.fromCharCode(parseInt(hex, 16));
            })
            .replace(/=\r?\n/g, ''); // Remove soft line breaks
    }

    /**
     * Convert Base64 string to ArrayBuffer
     */
    base64ToArrayBuffer(content) {
        try {
            // Handle URL-safe Base64
            let cleanBase64 = content.replace(/-/g, '+').replace(/_/g, '/');

            // Add padding if needed
            while (cleanBase64.length % 4 !== 0) {
                cleanBase64 += '=';
            }

            const binaryString = atob(cleanBase64);
            const bytes = new Uint8Array(binaryString.length);

            for (let i = 0; i < binaryString.length; i++) {
                bytes[i] = binaryString.charCodeAt(i);
            }

            return bytes.buffer;
        } catch (error) {
            throw new Error(`Base64 decode failed: ${error.message}`);
        }
    }

    /**
     * Merge streaming EML results
     */
    mergeStreamingEMLResults(headers, body, attachments) {
        return {
            type: 'streaming_eml_result',
            headers: headers,
            body: body,
            attachments: attachments,
            metadata: {
                processingMode: 'streaming',
                memoryStats: this.memoryManager.getMemoryStats(),
                chunkSize: this.chunkSize,
                processingState: this.processingState,
                headersCount: headers.size,
                bodySize: body.text?.length || 0,
                attachmentsCount: attachments.length,
                timestamp: new Date().toISOString()
            }
        };
    }

    /**
     * Clean up streaming resources
     */
    cleanupStreamingEML() {
        // Clear all streaming state
        this.headerBuffer = '';
        this.headerLines = [];
        this.bodyStarted = false;
        this.mimeBoundaries.clear();
        this.currentMimePart = null;

        // Clean up memory allocations
        this.streamingTracker.clearStaleChunks(0);

        // Reset parsing state
        this.headersParsed = false;
        this.processingState = 'cleaned';
    }

    /**
     * Get streaming statistics
     */
    getStreamingStats() {
        return {
            memoryStats: this.memoryManager.getMemoryStats(),
            activeChunks: this.streamingTracker.getActiveChunks(),
            processingState: this.processingState,
            headersParsed: this.headersParsed,
            totalProcessedSize: this.streamingTracker.getProcessedSize()
        };
    }

    /**
     * Cancel ongoing parsing
     */
    cancel() {
        if (this.processingState === 'parsing') {
            this.processingState = 'cancelled';
        }

        this.cleanupStreamingEML();
    }
}

// Browser compatibility
if (typeof window !== 'undefined') {
    window.StreamingEMLParser = StreamingEMLParser;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = StreamingEMLParser;
}
