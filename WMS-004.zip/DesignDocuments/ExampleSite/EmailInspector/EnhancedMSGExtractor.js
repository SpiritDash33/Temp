/**
 * Enhanced MSG Extractor with Property-Level Error Isolation
 * Extends base MSG extractor with robust property parsing and recovery
 * Handles corrupted individual properties while extracting valid ones
 */
class EnhancedMSGExtractor extends MSGExtractor {
    constructor(oleParser) {
        super(oleParser);
        this.propertyRecoveryOptions = {
            isolatePropertyErrors: true,
            skipCorruptedProperties: true,
            fallbackPropertyParsing: true,
            usePropertyDefaults: true,
            maximumPropertyFailures: 50,
            enablePropertyValidation: true
        };

        this.propertyFailureCount = 0;
        this.corruptedProperties = new Set();
        this.propertyRecoveryLog = [];
    }

    async extractEmail(analysis, isEmbedded = false, depth = 0) {
        // Reset recovery state for new extraction
        this.resetPropertyRecoveryState();

        this.propertyRecoveryLog.push({
            level: 'info',
            message: 'Starting enhanced MSG extraction with property recovery'
        });

        try {
            // Extract base email structure
            const email = await this.extractEmailWithRecovery(analysis, isEmbedded, depth);

            // Add recovery metadata
            email.recovery = {
                activated: true,
                corruptedProperties: Array.from(this.corruptedProperties),
                recoveryLog: this.propertyRecoveryLog,
                propertyRecoveryRate: this.calculatePropertyRecoveryRate(email),
                isolationResults: this.getIsolationResults()
            };

            return email;

        } catch (error) {
            this.propertyRecoveryLog.push({
                level: 'error',
                message: `MSG extraction failed: ${error.message}`,
                failureType: 'total'
            });

            throw new Error(`MSG extraction failed: ${error.message}`);
        }
    }

    async extractEmailWithRecovery(analysis, isEmbedded, depth) {
        const email = {
            subject: '',
            from: { name: '', email: '', addressType: '', searchKey: null },
            to: [],
            cc: [],
            bcc: [],
            body: { text: '', html: '', rtf: null },
            attachments: [],
            threads: [],
            headers: new Map(),
            metadata: {
                messageClass: '',
                importance: 1,
                priority: 1,
                sensitivity: 0,
                size: 0,
                hasAttachments: false,
                conversationTopic: '',
                conversationIndex: null,
                internetMessageId: '',
                creationTime: null,
                lastModificationTime: null
            },
            date: null,
            fragments: analysis.propertyAnalysis.samples
        };

        // Extract properties with individual error isolation
        await this.extractPropertiesWithIsolation(email, analysis.propertyAnalysis.samples);
        await this.extractRecipientsWithIsolation(email, analysis);
        await this.processAttachmentsWithIsolation(email, analysis, depth);

        // Post-processing with error handling
        this.postProcessWithRecovery(email);

        this.propertyRecoveryLog.push({
            level: 'success',
            message: 'MSG extraction completed with recovery',
            stats: {
                totalProperties: analysis.propertyAnalysis.samples.length,
                corruptedProperties: this.corruptedProperties.size,
                successfulExtraction: true
            }
        });

        return email;
    }

    async extractPropertiesWithIsolation(email, propertySamples) {
        for (const sample of propertySamples) {
            if (!this.shouldProcessProperty(sample)) continue;

            try {
                await this.extractSinglePropertyWithRecovery(sample, email);
            } catch (error) {
                this.handlePropertyFailure(sample, error, 'single_property');
                continue;
            }
        }
    }

    shouldProcessProperty(sample) {
        // Skip already identified corrupted properties
        if (this.corruptedProperties.has(sample.name)) {
            return false;
        }

        // Skip if we've exceeded maximum failures
        if (this.propertyFailureCount >= this.propertyRecoveryOptions.maximumPropertyFailures) {
            this.propertyRecoveryLog.push({
                level: 'warning',
                message: 'Maximum property failure threshold reached, stopping property extraction'
            });
            return false;
        }

        // Skip invalid samples
        if (!sample.propId && !sample.name?.startsWith('__substg1.0_')) {
            return false;
        }

        return true;
    }

    async extractSinglePropertyWithRecovery(sample, email) {
        try {
            // Get the property mapping
            const propInfo = this.getPropertyInfo(sample.propId);

            if (!propInfo) {
                // Unknown property - extract as generic property
                this.extractGenericProperty(sample, email);
                return;
            }

            // Get the type handler
            const typeHandler = this.typeHandlers[propInfo.type];

            if (!typeHandler) {
                this.propertyRecoveryLog.push({
                    level: 'warning',
                    message: `No type handler for property ${propInfo.key} (${propInfo.type})`
                });
                return;
            }

            // Extract property value with type validation
            let value = await this.extractPropertyValue(sample, propInfo, typeHandler);

            // Map to email structure
            this.mapPropertyToEmailStructure(propInfo.key, value, email);

        } catch (error) {
            // Mark property as corrupted but continue with others
            this.corruptedProperties.add(sample.name);
            throw new Error(`Property ${sample.propId} extraction failed: ${error.message}`);
        }
    }

    async extractPropertyValue(sample, propInfo, typeHandler) {
        let value;

        try {
            // Try to extract based on data availability
            if (sample.isBinary && sample.rawData) {
                value = typeHandler(sample.rawData);
            } else if (!sample.isBinary && sample.fullText && sample.fullText !== '[binary data]') {
                value = sample.fullText;
            } else {
                // Fallback: try to convert text to binary and then parse
                const binaryData = this.textToBinaryValue(sample.fullText || '');
                value = typeHandler(binaryData);
            }

            return value;

        } catch (error) {
            // Try fallback parsing methods
            try {
                value = await this.fallbackPropertyParsing(sample, propInfo, typeHandler);
                this.propertyRecoveryLog.push({
                    level: 'info',
                    message: `Fallback parsing succeeded for property ${propInfo.key}`
                });
                return value;
            } catch (fallbackError) {
                throw new Error(`${error.message} (fallback also failed: ${fallbackError.message})`);
            }
        }
    }

    async fallbackPropertyParsing(sample, propInfo, typeHandler) {
        // Try various fallback methods for property extraction

        // Method 1: Length-specific binary extraction
        if (sample.rawData && sample.rawData.length > 0) {
            try {
                return this.parseWithLengthValidation(sample.rawData, typeHandler, propInfo);
            } catch (error) {
                // Continue to next method
            }
        }

        // Method 2: Type-specific default values
        const defaultValue = this.getPropertyDefaultValue(propInfo);
        if (defaultValue !== undefined) {
            this.propertyRecoveryLog.push({
                level: 'info',
                message: `Using default value for property ${propInfo.key}: ${typeof defaultValue}`
            });
            return defaultValue;
        }

        // Method 3: Text-based guesswork for simple types
        if (propInfo.type === 'PtypString' && sample.fullText && sample.fullText !== '[binary data]') {
            return sample.fullText;
        }

        throw new Error('All fallback parsing methods failed');
    }

    parseWithLengthValidation(rawData, typeHandler, propInfo) {
        // Different properties have different expected lengths
        const expectedLengths = {
            'PtypBoolean': 1,
            'PtypInteger16': 2,
            'PtypInteger32': 4,
            'PtypInteger64': 8,
            'PtypFloating32': 4,
            'PtypFloating64': 8,
            'PtypCurrency': 8,
            'PtypTime': 8
        };

        const expectedLength = expectedLengths[propInfo.type];
        if (expectedLength && rawData.length >= expectedLength) {
            // Truncate or pad data if necessary
            const adjustedData = rawData.length > expectedLength ?
                rawData.slice(0, expectedLength) :
                new Uint8Array(expectedLength).set(rawData);
            return typeHandler(adjustedData);
        }

        // For variable-length types, try direct parsing
        return typeHandler(rawData);
    }

    getPropertyDefaultValue(propInfo) {
        // Default values for common properties when extraction fails
        const defaults = {
            'importance': 1,
            'priority': 1,
            'sensitivity': 0,
            'hasAttachments': false,
            'readReceiptRequested': false,
            'deliveryReceiptRequested': false,
            'trustSender': -1
        };

        return defaults[propInfo.key];
    }

    textToBinaryValue(text) {
        if (typeof text !== 'string' || text.length === 0) {
            return new Uint8Array(0);
        }

        try {
            // Try base64 decoding first
            if (/^[A-Za-z0-9+/]*={0,2}$/.test(text.trim())) {
                try {
                    return Uint8Array.from(atob(text.trim()), c => c.charCodeAt(0));
                } catch (e) {
                    // Not valid base64
                }
            }

            // Try hex decoding
            if (/^[0-9A-Fa-f\s]*$/.test(text)) {
                const hexOnly = text.replace(/\s/g, '');
                if (hexOnly.length % 2 === 0) {
                    const bytes = new Uint8Array(hexOnly.length / 2);
                    for (let i = 0; i < hexOnly.length; i += 2) {
                        bytes[i / 2] = parseInt(hexOnly.substr(i, 2), 16);
                    }
                    return bytes;
                }
            }

            // Try UTF-8 encoding
            const encoder = new TextEncoder();
            return encoder.encode(text);

        } catch (error) {
            this.propertyRecoveryLog.push({
                level: 'warning',
                message: `Text to binary conversion failed: ${error.message}`
            });
            return new Uint8Array(0);
        }
    }

    async extractRecipientsWithIsolation(email, analysis) {
        try {
            // Normal recipient extraction attempt
            await this.extractRecipientsNormal(email, analysis);
        } catch (error) {
            this.propertyRecoveryLog.push({
                level: 'warning',
                message: `Recipient extraction failed: ${error.message}, attempting recovery`
            });

            // Fallback: extract partial recipient information from properties
            this.extractRecipientsFallback(email, analysis.propertyAnalysis.samples);
        }
    }

    async extractRecipientsNormal(email, analysis) {
        // This would use the base MSG extractor's recipient extraction
        // For now, we'll implement a basic version
        const recipientProps = analysis.propertyAnalysis.samples.filter(
            sample => sample.propId === '0E04' || sample.propId === '0E03' || sample.propId === '0E02'
        );

        for (const prop of recipientProps) {
            try {
                if (prop.fullText && prop.fullText !== '[binary data]') {
                    this.parseRecipientProperty(prop, email);
                }
            } catch (error) {
                this.propertyRecoveryLog.push({
                    level: 'warning',
                    message: `Recipient property parsing failed: ${error.message}`
                });
            }
        }
    }

    extractRecipientsFallback(email, samples) {
        // Extract recipient information from any available properties
        const senderProps = samples.filter(
            s => s.propId === '0C1A' || s.propId === '0C1E' || s.propId === '0C1F'
        );

        // Extract display name properties for recipients
        const displayProps = samples.filter(
            s => s.propId === '0E04' || s.propId === '0E03' || s.propId === '0E02'
        );

        // Try to construct recipient lists from properties
        for (const prop of displayProps) {
            try {
                const recipients = this.parseRecipientDisplayList(prop.fullText);
                if (recipients && recipients.length > 0) {
                    // Determine which list this is for
                    if (prop.propId === '0E04') email.to.push(...recipients);
                    else if (prop.propId === '0E03') email.cc.push(...recipients);
                    else if (prop.propId === '0E02') email.bcc.push(...recipients);
                }
            } catch (error) {
                continue; // Skip this property
            }
        }
    }

    parseRecipientProperty(sample, email) {
        // Placeholder for recipient property parsing
        // This would need full recipient parsing logic
        const recipientList = this.parseRecipientDisplayList(sample.fullText);

        if (sample.propId === '0E04') email.to = recipientList;
        else if (sample.propId === '0E03') email.cc = recipientList;
        else if (sample.propId === '0E02') email.bcc = recipientList;
    }

    parseRecipientDisplayList(recipientString) {
        if (!recipientString || typeof recipientString !== 'string') {
            return [];
        }

        // Simple recipient list parsing
        return recipientString.split(';')
            .filter(addr => addr.trim().length > 0)
            .map(addr => this.parseAddressFromDisplay(addr.trim()));
    }

    parseAddressFromDisplay(addr) {
        const match = addr.match(/^"?([^"<]*?)"?\s*<([^>]+)>$/);
        if (match) {
            return { name: match[1].trim(), email: match[2].trim() };
        } else {
            return { name: '', email: addr.trim() };
        }
    }

    async processAttachmentsWithIsolation(email, analysis, depth) {
        const attachmentDirs = analysis.directories.filter(d =>
            d.name && d.name.startsWith('__attach_version1.0_'));

        for (const attachDir of attachmentDirs) {
            try {
                const attachment = await this.processSingleAttachmentWithRecovery(attachDir, analysis, depth);
                if (attachment) {
                    if (attachment.isEmbedded) {
                        email.threads.push(attachment.embeddedMessage);
                    } else {
                        email.attachments.push(attachment);
                    }
                }
            } catch (error) {
                this.handleAttachmentFailure(attachDir, error);
                continue;
            }
        }
    }

    async processSingleAttachmentWithRecovery(attachDir, analysis, depth) {
        try {
            return await super.processSingleAttachment(attachDir, analysis, depth);
        } catch (error) {
            this.propertyRecoveryLog.push({
                level: 'warning',
                message: `Attachment processing failed for ${attachDir.name}: ${error.message}, attempting recovery`
            });

            // Try minimal attachment extraction
            return await this.extractMinimalAttachment(attachDir, analysis);
        }
    }

    async extractMinimalAttachment(attachDir, analysis) {
        const attachment = {
            name: 'Recovery_Attachment',
            size: attachDir.size,
            type: 'unknown',
            method: 0,
            isEmbedded: false,
            data: null,
            recoveryAttempt: true
        };

        // Try to extract basic information from attach directory
        const attachProps = analysis.propertyAnalysis.samples.filter(s =>
            s.name.includes(attachDir.name));

        for (const prop of attachProps) {
            try {
                if (!prop.propId) continue;

                switch (prop.propId) {
                    case '3704': // PidTagAttachFilename
                        if (prop.fullText && prop.fullText !== '[binary data]') {
                            attachment.name = prop.fullText;
                        }
                        break;
                    case '370E': // PidTagAttachMimeTag
                        if (prop.fullText && prop.fullText !== '[binary data]') {
                            attachment.type = prop.fullText;
                        }
                        break;
                    case '3701': // PidTagAttachDataObject
                        attachment.data = prop.rawData;
                        break;
                }
            } catch (error) {
                continue; // Skip this property
            }
        }

        return attachment;
    }

    getPropertyInfo(propId) {
        // Get property information from the base extractor
        return this.propMap[propId];
    }

    mapPropertyToEmailStructure(key, value, email) {
        // Use the base extractor's mapping method
        const sample = { propId: '', typeId: '', rawData: null, fullText: value };
        this.mapPropertyToEmail(key, value, email);
    }

    postProcessWithRecovery(email) {
        // Post-processing with error handling
        this.postProcessEmail(email);
    }

    handlePropertyFailure(sample, error, failureType) {
        this.propertyFailureCount++;
        this.corruptedProperties.add(sample.name);

        this.propertyRecoveryLog.push({
            level: 'warning',
            message: `Property failure (${failureType}): ${sample.name} - ${error.message}`,
            propertyId: sample.propId || 'unknown',
            failureType: failureType
        });
    }

    handleAttachmentFailure(attachDir, error) {
        this.propertyRecoveryLog.push({
            level: 'error',
            message: `Attachment processing failed: ${attachDir.name} - ${error.message}`,
            attachmentName: attachDir.name
        });
    }

    calculatePropertyRecoveryRate(email) {
        // Calculate how many properties were successfully extracted vs total
        const totalSamples = email.fragments?.length || 0;
        const corruptedCount = this.corruptedProperties.size;

        if (totalSamples === 0) return 100;

        const recoveredCount = totalSamples - corruptedCount;
        return Math.round((recoveredCount / totalSamples) * 100);
    }

    getIsolationResults() {
        return {
            propertyFailures: this.propertyFailureCount,
            corruptedProperties: this.corruptedProperties.size,
            recoverySuccessRate: Math.max(0, 100 - (this.propertyFailureCount * 2)), // Rough metric
            isolationEffective: this.propertyFailureCount <= this.propertyRecoveryOptions.maximumPropertyFailures
        };
    }

    resetPropertyRecoveryState() {
        this.propertyFailureCount = 0;
        this.corruptedProperties.clear();
        this.propertyRecoveryLog = [];
    }

    extractGenericProperty(sample, email) {
        // Store unknown properties in metadata for inspection
        if (!email.metadata.unknownProperties) {
            email.metadata.unknownProperties = [];
        }

        email.metadata.unknownProperties.push({
            name: sample.name,
            propId: sample.propId,
            typeId: sample.typeId,
            textSample: sample.textSample,
            size: sample.size,
            isBinary: sample.isBinary
        });
    }
}

// Browser/Node.js compatibility
if (typeof window !== 'undefined') {
    window.EnhancedMSGExtractor = EnhancedMSGExtractor;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = EnhancedMSGExtractor;
}
