/**
 * Advanced MIME Types Parser for Email Suite
 * Handles calendar, vCard, XML, and document formats
 * Extends basic MIME parsing with rich structured data support
 */
class AdvancedMIMEParser {
    constructor(options = {}) {
        this.debug = options.debug || false;
        this.extractCalendarEvents = options.extractCalendarEvents !== false;
        this.extractVCardContacts = options.extractVCardContacts !== false;
        this.extractXMLContent = options.extractXMLContent !== false;
        this.extractDocumentMetadata = options.extractDocumentMetadata !== false;
        this.maxParseSize = options.maxParseSize || 10 * 1024 * 1024; // 10MB limit
        this.enableBinaryExtraction = options.enableBinaryExtraction !== false;

        this.stats = this.initializeStats();

        // Initialize sub-parsers
        this.iCalendarParser = new ICalendarParser();
        this.vCardParser = new VCardParser();
        this.xmlParser = new XMLParser();
        this.documentParser = new DocumentParser();
    }

    initializeStats() {
        return {
            iCalendarProcessed: 0,
            vCardProcessed: 0,
            xmlProcessed: 0,
            documentsProcessed: 0,
            parsingErrors: 0,
            totalProcessingTime: 0,
            lastOperation: null
        };
    }

    /**
     * Main processing method for advanced MIME types
     */
    async processAdvancedMIME(mimePart) {
        const startTime = performance.now();
        const result = {
            type: mimePart.contentType?.type || 'unknown',
            originalPart: mimePart,
            parsedContent: null,
            metadata: {},
            warnings: [],
            processingTime: 0
        };

        try {
            const contentType = mimePart.contentType?.type || '';

            // Route to appropriate parser
            switch (contentType) {
                case 'text/calendar':
                    result.parsedContent = await this.processCalendarData(mimePart);
                    break;
                case 'text/vcard':
                case 'text/x-vcard':
                    result.parsedContent = await this.processVCardData(mimePart);
                    break;
                case 'application/xml':
                case 'text/xml':
                    result.parsedContent = await this.processXMLData(mimePart);
                    break;
                case 'application/pdf':
                    result.parsedContent = await this.processDocumentData(mimePart);
                    break;
                case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
                case 'application/vnd.ms-word':
                case 'application/msword':
                    result.parsedContent = await this.processDocumentData(mimePart);
                    break;
                case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
                case 'application/vnd.ms-excel':
                    result.parsedContent = await this.processDocumentData(mimePart);
                    break;
                case 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
                case 'application/vnd.ms-powerpoint':
                    result.parsedContent = await this.processDocumentData(mimePart);
                    break;
                default:
                    // Check for calendar or vCard content by inspection
                    const contentInspection = this.inspectContent(contentType, mimePart.content);
                    if (contentInspection.suggestedType) {
                        result.parsedContent = await this.processByInspection(contentInspection, mimePart);
                    } else {
                        result.metadata.note = 'MIME type not recognized for advanced parsing';
                    }
            }

            // Add processing metadata
            result.metadata.contentType = contentType;
            result.metadata.contentSize = mimePart.content?.length || 0;
            result.metadata.encoding = mimePart.contentEncoding || 'unknown';
            result.metadata.filename = mimePart.filename || mimePart.contentDisposition?.params?.filename || '';

            if (this.debug) {
                result.metadata.debugInfo = {
                    parsingMethod: result.parsedContent?.type || 'none',
                    processingTime: performance.now() - startTime
                };
            }

        } catch (error) {
            if (this.debug) {
                console.warn('Advanced MIME processing error:', error.message);
            }

            this.stats.parsingErrors++;
            result.warnings.push(`Processing failed: ${error.message}`);
            result.metadata.error = error.message;
        }

        result.processingTime = performance.now() - startTime;
        this.stats.totalProcessingTime += result.processingTime;

        return result;
    }

    /**
     * Process iCalendar/vCalendar data
     */
    async processCalendarData(mimePart) {
        if (!this.extractCalendarEvents) {
            return null;
        }

        try {
            // Decode content
            const content = this.decodeMIMEContent(mimePart.content, mimePart.contentEncoding || '7bit');

            // Validate size limits
            if (content.length > this.maxParseSize) {
                throw new Error(`Calendar data too large: ${content.length} bytes (max: ${this.maxParseSize})`);
            }

            // Parse calendar data
            const calendarResult = await this.iCalendarParser.parse(content);

            this.stats.iCalendarProcessed++;

            return {
                type: 'calendar',
                format: this.iCalendarParser.detectFormat(content),
                events: calendarResult.events || [],
                todos: calendarResult.todos || [],
                journals: calendarResult.journals || [],
                timezones: calendarResult.timezones || [],
                metadata: {
                    version: calendarResult.version,
                    prodId: calendarResult.prodId,
                    method: calendarResult.method,
                    eventCount: calendarResult.events?.length || 0,
                    todoCount: calendarResult.todos?.length || 0
                }
            };

        } catch (error) {
            throw new Error(`Calendar parsing failed: ${error.message}`);
        }
    }

    /**
     * Process vCard contact data
     */
    async processVCardData(mimePart) {
        if (!this.extractVCardContacts) {
            return null;
        }

        try {
            const content = this.decodeMIMEContent(mimePart.content, mimePart.contentEncoding || '7bit');

            if (content.length > this.maxParseSize) {
                throw new Error(`vCard data too large: ${content.length} bytes (max: ${this.maxParseSize})`);
            }

            const vCardResult = await this.vCardParser.parse(content);

            this.stats.vCardProcessed++;

            return {
                type: 'vcard',
                version: vCardResult.version,
                contacts: vCardResult.contacts || [],
                metadata: {
                    version: vCardResult.version,
                    contactCount: vCardResult.contacts?.length || 0,
                    hasPhotos: vCardResult.contacts?.some(contact => contact.photo) || false
                }
            };

        } catch (error) {
            throw new Error(`vCard parsing failed: ${error.message}`);
        }
    }

    /**
     * Process XML content
     */
    async processXMLData(mimePart) {
        if (!this.extractXMLContent) {
            return null;
        }

        try {
            const content = this.decodeMIMEContent(mimePart.content, mimePart.contentEncoding || '7bit');

            if (content.length > this.maxParseSize) {
                throw new Error(`XML data too large: ${content.length} bytes (max: ${this.maxParseSize})`);
            }

            const xmlResult = await this.xmlParser.parse(content);

            this.stats.xmlProcessed++;

            return {
                type: 'xml',
                rootElement: xmlResult.rootElement,
                schema: xmlResult.schema,
                validated: xmlResult.validated,
                metadata: xmlResult.metadata,
                structuredData: xmlResult.structuredData,
                extractedFields: xmlResult.extractedFields || {}
            };

        } catch (error) {
            throw new Error(`XML parsing failed: ${error.message}`);
        }
    }

    /**
     * Process document content (PDF, Office docs)
     */
    async processDocumentData(mimePart) {
        if (!this.extractDocumentMetadata) {
            return null;
        }

        try {
            const content = mimePart.content; // Keep binary for document parsing

            if (!content || content.length === 0) {
                throw new Error('No document content provided');
            }

            if (content.length > this.maxParseSize) {
                throw new Error(`Document too large: ${content.length} bytes (max: ${this.maxParseSize})`);
            }

            const docResult = await this.documentParser.extractMetadata(content, mimePart.contentType?.type);

            this.stats.documentsProcessed++;

            return {
                type: 'document',
                docType: docResult.docType,
                metadata: docResult.metadata,
                contentPreview: docResult.contentPreview,
                links: docResult.links || [],
                images: docResult.images || [],
                stats: {
                    pageCount: docResult.pageCount,
                    wordCount: docResult.wordCount,
                    characterCount: docResult.characterCount
                }
            };

        } catch (error) {
            throw new Error(`Document parsing failed: ${error.message}`);
        }
    }

    /**
     * Content inspection for MIME types not explicitly declared
     */
    inspectContent(contentType, content) {
        const result = {
            suggestedType: null,
            confidence: 0,
            reasons: []
        };

        try {
            const textContent = this.decodeMIMEContent(content, '7bit');

            // Calendar pattern detection
            if (this.looksLikeCalendar(textContent)) {
                result.suggestedType = 'text/calendar';
                result.confidence = 0.8;
                result.reasons.push('Contains calendar patterns');
            }

            // vCard pattern detection
            if (this.looksLikeVCard(textContent)) {
                result.suggestedType = 'text/vcard';
                result.confidence = 0.9;
                result.reasons.push('Contains vCard patterns');
            }

            // XML pattern detection
            if (this.looksLikeXML(textContent)) {
                result.suggestedType = 'text/xml';
                result.confidence = 0.7;
                result.reasons.push('Contains XML patterns');
            }

        } catch (error) {
            // Content inspection failed
        }

        return result;
    }

    /**
     * Process content based on inspection results
     */
    async processByInspection(inspection, mimePart) {
        if (this.debug) {
            console.log(`Processing by inspection: ${inspection.suggestedType} (confidence: ${inspection.confidence})`);
        }

        // Temporarily update content type for processing
        const originalType = mimePart.contentType?.type;
        mimePart.contentType = { ...mimePart.contentType, type: inspection.suggestedType };

        try {
            const result = await this.processAdvancedMIME(mimePart);

            // Add inspection metadata
            if (result) {
                result.metadata.detectedByInspection = {
                    originalType: originalType,
                    detectedType: inspection.suggestedType,
                    confidence: inspection.confidence,
                    reasons: inspection.reasons
                };
            }

            return result;

        } finally {
            // Restore original content type
            mimePart.contentType = { ...mimePart.contentType, type: originalType };
        }
    }

    /**
     * Content pattern recognition methods
     */
    looksLikeCalendar(content) {
        if (!content || typeof content !== 'string') return false;

        const calendarPatterns = [
            /^BEGIN:VCALENDAR/i,
            /^BEGIN:VEVENT/i,
            /^DTSTART:/i,
            /^DTEND:/i,
            /^METHOD:/i,
            /^PRODID:/i,
            /\d{8}T\d{6}/, // ISO datetime patterns
        ];

        const matches = calendarPatterns.filter(pattern => pattern.test(content)).length;
        return matches >= 2; // At least 2 calendar patterns
    }

    looksLikeVCard(content) {
        if (!content || typeof content !== 'string') return false;

        const vcardPatterns = [
            /^BEGIN:VCARD/i,
            /^FN:/i,
            /^TEL:/i,
            /^EMAIL:/i,
            /^ADR:/i,
            /^VERSION:/i,
            /^ORG:/i,
        ];

        const matches = vcardPatterns.filter(pattern => pattern.test(content)).length;
        return matches >= 2; // At least 2 vCard patterns
    }

    looksLikeXML(content) {
        if (!content || typeof content !== 'string') return false;

        // Simple XML detection
        const xmlPatterns = [
            /^<\?xml/i,      // XML declaration
            /^<[^>]+>.*<\/[^>]+>$/s, // XML with closing tag
            /xmlns[:=]/i,    // XML namespace declarations
            /schema/i,       // Schema references
        ];

        const matches = xmlPatterns.filter(pattern => pattern.test(content)).length;
        return matches >= 1; // At least 1 XML pattern
    }

    /**
     * MIME content decoding
     */
    decodeMIMEContent(content, encoding) {
        if (!content) return '';

        switch (encoding.toLowerCase()) {
            case 'base64':
                try {
                    if (typeof atob !== 'undefined') {
                        return atob(content);
                    }
                    return Buffer.from(content, 'base64').toString();
                } catch (e) {
                    if (this.debug) console.warn('Base64 decode failed:', e.message);
                    return content;
                }

            case 'quoted-printable':
                return content
                    .replace(/=[0-9A-F]{2}/gi, (match) => {
                        return String.fromCharCode(parseInt(match.substr(1), 16));
                    })
                    .replace(/=\r?\n/g, '');

            case '7bit':
            case '8bit':
            case 'binary':
            default:
                return typeof content === 'string' ? content :
                       new TextDecoder('utf-8').decode(content);
        }
    }

    /**
     * Get processing statistics
     */
    getStats() {
        return {
            ...this.stats,
            averageProcessingTime: this.stats.totalProcessingTime /
                Math.max(1, (this.stats.iCalendarProcessed + this.stats.vCardProcessed +
                           this.stats.xmlProcessed + this.stats.documentsProcessed)),
            processingEfficiency: this.getProcessingEfficiency()
        };
    }

    getProcessingEfficiency() {
        const totalProcessed = this.stats.iCalendarProcessed + this.stats.vCardProcessed +
                              this.stats.xmlProcessed + this.stats.documentsProcessed;

        if (totalProcessed === 0) return 1;

        const successRate = 1 - (this.stats.parsingErrors / totalProcessed);
        return Math.max(0, Math.min(1, successRate));
    }

    resetStats() {
        this.stats = this.initializeStats();
    }
}

// =============================================================================
// SUB-PARSERS
// =============================================================================

class ICalendarParser {
    async parse(content) {
        // Simulate iCalendar parsing
        const lines = content.split(/\r?\n/);
        const result = {
            version: '2.0',
            prodId: '',
            method: '',
            events: [],
            todos: [],
            journals: [],
            timezones: []
        };

        try {
            let currentObject = null;
            let inEvent = false, inTodo = false, inJournal = false;

            for (const line of lines) {
                const trimmed = line.trim();

                if (trimmed === 'BEGIN:VEVENT') {
                    currentObject = {};
                    inEvent = true;
                    result.events.push(currentObject);
                } else if (trimmed === 'END:VEVENT') {
                    inEvent = false;
                    currentObject = null;
                } else if (currentObject && inEvent) {
                    this.parseEventProperty(trimmed, currentObject);
                }

                // Similar handlers for TODO and JOURNAL would go here
            }

        } catch (error) {
            if (this.debug) console.warn('iCalendar parse error:', error.message);
        }

        return result;
    }

    parseEventProperty(line, event) {
        if (!line.includes(':')) return;

        const [property, ...valueParts] = line.split(':');
        const value = valueParts.join(':');

        switch (property) {
            case 'SUMMARY': event.title = value; break;
            case 'DTSTART': event.start = this.parseICalDate(value); break;
            case 'DTEND': event.end = this.parseICalDate(value); break;
            case 'LOCATION': event.location = value; break;
            case 'DESCRIPTION': event.description = value; break;
            case 'ORGANIZER': event.organizer = this.parseAttendee(value); break;
            case 'ATTENDEE': (event.attendees = event.attendees || []).push(this.parseAttendee(value)); break;
        }
    }

    parseICalDate(dateString) {
        // Simple ISO date parsing
        const match = dateString.match(/^(\d{4})(\d{2})(\d{2})T?(\d{2})?(\d{2})?(\d{2})?/);
        if (match) {
            const [, year, month, day, hour, minute, second] = match;
            return new Date(year, month - 1, day, hour || 0, minute || 0, second || 0);
        }
        return new Date(dateString);
    }

    parseAttendee(value) {
        // Parse attendee: CN="Name";EMAIL="email@example.com"
        const nameMatch = value.match(/CN="?([^";]+)"?/);
        const emailMatch = value.match(/MAILTO:?([^\s;]+)/);

        return {
            name: nameMatch ? nameMatch[1] : '',
            email: emailMatch ? emailMatch[1] : '',
            responseStatus: 'NEEDS-ACTION' // Default
        };
    }

    detectFormat(content) {
        if (content.includes('BEGIN:VCALENDAR')) {
            return content.includes('VERSION:2.0') ? 'iCalendar2.0' : 'vCalendar1.0';
        }
        return 'unknown';
    }
}

class VCardParser {
    async parse(content) {
        // Simulate vCard parsing
        const lines = content.split(/\r?\n/);
        const result = {
            version: '3.0',
            contacts: []
        };

        try {
            let currentContact = null;
            let inContact = false;

            for (const line of lines) {
                const trimmed = line.trim();

                if (trimmed === 'BEGIN:VCARD') {
                    currentContact = this.createBlankContact();
                    inContact = true;
                    result.contacts.push(currentContact);
                } else if (trimmed === 'END:VCARD') {
                    inContact = false;
                    currentContact = null;
                } else if (currentContact && inContact) {
                    this.parseVCardProperty(trimmed, currentContact);
                }
            }

        } catch (error) {
            if (this.debug) console.warn('vCard parse error:', error.message);
        }

        return result;
    }

    createBlankContact() {
        return {
            uid: '',
            fullName: '',
            name: { family: '', given: '', middle: '', prefix: '', suffix: '' },
            emails: [],
            telephones: [],
            addresses: [],
            organization: '',
            title: '',
            photo: null,
            notes: '',
            urls: [],
            categories: [],
            birthDate: null,
            revision: null
        };
    }

    parseVCardProperty(line, contact) {
        if (!line.includes(':')) return;

        const [propertyStr, ...valueParts] = line.split(':');
        const value = valueParts.join(':');
        const propertyParams = propertyStr.split(';');
        const property = propertyParams[0];

        switch (property) {
            case 'FN': contact.fullName = value; break;
            case 'N': contact.name = this.parseName(value); break;
            case 'EMAIL': contact.emails.push(this.parseEmail(value, propertyParams)); break;
            case 'TEL': contact.telephones.push(this.parseTelephone(value, propertyParams)); break;
            case 'ADR': contact.addresses.push(this.parseAddress(value, propertyParams)); break;
            case 'ORG': contact.organization = value; break;
            case 'TITLE': contact.title = value; break;
            case 'URL': contact.urls.push(value); break;
            case 'NOTE': contact.notes = value; break;
            case 'CATEGORIES': contact.categories = value.split(',').map(c => c.trim()); break;
            case 'BDAY': contact.birthDate = this.parseDate(value); break;
            case 'REV': contact.revision = this.parseDate(value); break;
            case 'UID': contact.uid = value; break;
        }
    }

    parseName(value) {
        const parts = value.split(';');
        return {
            family: parts[0]?.trim() || '',
            given: parts[1]?.trim() || '',
            middle: parts[2]?.trim() || '',
            prefix: parts[3]?.trim() || '',
            suffix: parts[4]?.trim() || ''
        };
    }

    parseEmail(value, params) {
        return {
            email: value,
            type: this.extractTypeFromParams(params),
            isPrimary: params.includes('PREF')
        };
    }

    parseTelephone(value, params) {
        return {
            number: value,
            type: this.extractTypeFromParams(params),
            isPrimary: params.includes('PREF')
        };
    }

    parseAddress(value, params) {
        const parts = value.split(';');
        return {
            street: parts[2] || '', // Extended address
            city: parts[3] || '',
            region: parts[4] || '',
            postCode: parts[5] || '',
            country: parts[6] || '',
            type: this.extractTypeFromParams(params)
        };
    }

    extractTypeFromParams(params) {
        for (let i = 1; i < params.length; i++) {
            if (params[i].startsWith('TYPE=')) {
                return params[i].substring(5);
            }
        }
        return 'work'; // Default
    }

    parseDate(dateString) {
        if (!dateString) return null;

        // Handle different date formats (YYYY-MM-DD, YYYYMMDD)
        if (dateString.includes('-')) {
            return new Date(dateString);
        } else {
            // Assume YYYYMMDD format
            const match = dateString.match(/^(\d{4})(\d{2})(\d{2})$/);
            if (match) {
                return new Date(match[1], match[2] - 1, match[3]);
            }
        }

        return null;
    }
}

class XMLParser {
    async parse(content) {
        const result = {
            rootElement: null,
            schema: null,
            validated: false,
            metadata: {},
            structuredData: {},
            extractedFields: {}
        };

        try {
            // Simple XML parsing - for production would use proper XML parser
            const xmlDeclaration = content.match(/<\?xml.*?\?>/);
            if (xmlDeclaration) {
                result.metadata.xmlDeclaration = xmlDeclaration[0];
            }

            // Extract root element
            const rootMatch = content.match(/^.*?<([^>\s]+)[>\s]/);
            if (rootMatch) {
                result.rootElement = rootMatch[1];
            }

            // Basic schema detection
            if (content.includes('xmlns:') || content.includes('schema')) {
                result.schema = 'detected';
                result.validated = true; // Placeholder
            }

            // Extract common fields and structures
            result.structuredData = this.extractXMLStructure(content);
            result.extractedFields = this.extractCommonFields(content);

        } catch (error) {
            if (this.debug) console.warn('XML parse error:', error.message);
        }

        return result;
    }

    extractXMLStructure(content) {
        // Basic XML structure extraction
        const structure = {
            elements: [],
            attributes: {},
            textContent: ''
        };

        // Simple element extraction (would need proper XML parser for complex docs)
        const elementMatches = content.match(/<[^>]+>/g) || [];
        structure.elements = elementMatches.slice(0, 10); // Limit for preview

        // Extract some attributes
        structure.attributesCount = (elementMatches.join('').match(/[\w-]+="[^"]*"/g) || []).length;

        // Get text content preview
        structure.textContent = content.replace(/<[^>]*>/g, '').trim().substring(0, 200);

        return structure;
    }

    extractCommonFields(content) {
        const fields = {};

        // Extract common XML field patterns
        const patterns = {
            title: /<title[^>]*>([^<]*)<\/title>/gi,
            description: /<description[^>]*>([^<]*)<\/description>/gi,
            author: /<author[^>]*>([^<]*)<\/author>/gi,
            content: /<content[^>]*>([^<]*)<\/content>/gi,
            summary: /<summary[^>]*>([^<]*)<\/summary>/gi,
            subject: /<subject[^>]*>([^<]*)<\/subject>/gi,
            category: /<category[^>]*>([^<]*)<\/category>/gi,
            keywords: /<keywords?[^>]*>([^<]*)<\/keywords?>/gi,
            date: /<(?:pubDate|published|created|updated)[^>]*>([^<]*)<\/(?:pubDate|published|created|updated)>/gi
        };

        for (const [fieldName, regex] of Object.entries(patterns)) {
            const match = regex.exec(content);
            if (match) {
                fields[fieldName] = match[1].trim();
            }
        }

        return fields;
    }
}

class DocumentParser {
    async extractMetadata(content, mimeType) {
        const result = {
            docType: this.determineDocType(mimeType),
            metadata: {},
            contentPreview: '',
            links: [],
            images: [],
            pageCount: 1,
            wordCount: 0,
            characterCount: 0
        };

        try {
            // Extract text content if possible
            const textContent = this.extractDocumentText(content, mimeType);
            result.contentPreview = textContent.substring(0, 500);
            result.wordCount = textContent.split(/\s+/).length;
            result.characterCount = textContent.length;

            // Extract basic metadata
            result.metadata = this.extractDocumentMetadata(content, mimeType);

            // Extract links if applicable
            if (textContent.includes('http')) {
                result.links = this.extractLinks(textContent);
            }

        } catch (error) {
            if (this.debug) console.warn('Document metadata extraction error:', error.message);
        }

        return result;
    }

    determineDocType(mimeType) {
        const typeMap = {
            'application/pdf': 'PDF',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'Word(DOCX)',
            'application/vnd.ms-word': 'Word',
            'application/msword': 'Word',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'Excel(XLSX)',
            'application/vnd.ms-excel': 'Excel',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'PowerPoint(PPTX)',
            'application/vnd.ms-powerpoint': 'PowerPoint'
        };

        return typeMap[mimeType] || 'Unknown Document';
    }

    extractDocumentText(content, mimeType) {
        // For demonstration, try to extract text from common formats
        if (mimeType === 'text/plain') {
            return new TextDecoder('utf-8').decode(content);
        }

        // For other formats, we'd need document-specific parsers
        // Placeholder implementation
        return 'Document text extraction would require format-specific libraries...';
    }

    extractDocumentMetadata(content, mimeType) {
        const metadata = {
            created: null,
            modified: null,
            author: '',
            title: '',
            subject: '',
            keywords: [],
            pageCount: 1
        };

        // In a real implementation, we'd parse format-specific headers
        // For now, return placeholder metadata
        metadata.created = new Date();
        metadata.modified = new Date();
        metadata.author = 'Unknown';

        return metadata;
    }

    extractLinks(text) {
        const urlRegex = /(https?:\/\/[^\s<>"{}|\\^`[\]]+)/g;
        const links = [];
        let match;

        while ((match = urlRegex.exec(text)) !== null) {
            links.push(match[1]);
        }

        return links;
    }
}

// Browser compatibility
if (typeof window !== 'undefined') {
    window.AdvancedMIMEParser = AdvancedMIMEParser;
    window.ICalendarParser = ICalendarParser;
    window.VCardParser = VCardParser;
    window.XMLParser = XMLParser;
    window.DocumentParser = DocumentParser;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AdvancedMIMEParser, ICalendarParser, VCardParser, XMLParser, DocumentParser };
}
