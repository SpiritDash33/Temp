# Email Parser Library Documentation

A comprehensive JavaScript email parsing library supporting Microsoft MSG files and RFC5322/MIME EML files with advanced features including S/MIME cryptography, streaming support, and recovery capabilities.

## Table of Contents

- [Overview](#overview)
- [Core Components](#core-components)
- [Installation & Usage](#installation--usage)
- [API Reference](#api-reference)
- [Advanced Features](#advanced-features)
- [Configuration Options](#configuration-options)
- [Examples](#examples)
- [Performance & Memory Management](#performance--memory-management)
- [Security Features](#security-features)
- [Error Handling & Recovery](#error-handling--recovery)

## Overview

The Email Parser Library is a complete solution for parsing email files in both Microsoft MSG format and standard EML/MIME format. It provides:

- **Full MSG Support**: Complete MS-OXMSG specification compliance with all MAPI properties
- **Complete EML/MIME Support**: RFC5322, RFC2045-2049 compliant with all MIME extensions
- **Advanced Features**: S/MIME cryptography, streaming for large files, error recovery
- **Rich Data Extraction**: Attachments, embedded messages, calendar events, contacts
- **Memory Efficient**: Streaming support for files up to 1GB+ with configurable memory limits
- **Security Focused**: Input validation, XSS prevention, secure credential handling

## Core Components

### 1. EmailParser (Main Orchestrator)

The primary interface for email parsing operations.

```javascript
const parser = new EmailParser({
    debug: true,
    enableRecovery: true,
    enableSMIME: true,
    enableAdvancedMIME: true,
    enableStreaming: true,
    streamingThreshold: 25 * 1024 * 1024, // 25MB
    maxStreamingMemory: 10 * 1024 * 1024  // 10MB
});

const email = await parser.parse(file);
```

**Key Features:**
- Automatic format detection (MSG vs EML)
- Streaming support for large files
- Integrated S/MIME processing
- Advanced MIME type handling
- Error recovery capabilities

### 2. OLEParser (Microsoft OLE File System)

Handles the OLE compound document format used by MSG files.

```javascript
const oleParser = new OLEParser();
const analysis = await oleParser.parseFile(file);
```

**Capabilities:**
- Complete OLE specification compliance
- DIFAT chain processing for large files
- Mini-FAT support for small streams
- Sector chain validation
- Directory tree reconstruction

### 3. MSGExtractor (MAPI Property Extraction)

Extracts email data from MSG files using complete MS-OXPROPS property mapping.

```javascript
const extractor = new MSGExtractor(oleParser);
const email = await extractor.extractEmail(analysis);
```

**Features:**
- 250+ MAPI property mappings
- All MS-OXPROPS data types supported
- Embedded message extraction
- Attachment processing
- RTF decompression integration

### 4. EMLParser (RFC5322/MIME Compliant)

Parses standard email files in EML format.

```javascript
const emlParser = new EMLParser();
const email = await emlParser.parseFile(file);
```

**Standards Compliance:**
- RFC5322 message format
- RFC2045-2049 MIME specifications
- All transfer encodings (Base64, Quoted-Printable)
- Multipart message handling
- Header folding and encoding

### 5. RTFDecompressor (MS-OXRTFCP)

Decompresses RTF content from MSG files.

```javascript
const decompressor = new RTFDecompressor();
const plainText = decompressor.rtfToPlainText(rtfData);
const htmlContent = decompressor.rtfToHTML(rtfData);
const images = decompressor.extractImages(rtfData);
```

**Features:**
- LZFU compression algorithm
- RTF to plain text conversion
- RTF to HTML conversion
- Embedded image extraction
- CRC32 validation

### 6. SMIMECrypto (S/MIME Security)

Handles S/MIME cryptographic operations.

```javascript
const smime = new SMIMECrypto({
    verifySignatures: true,
    extractCertificates: true,
    strictValidation: true
});

const result = await smime.verifySignature(signedData, certificate, content);
const certs = await smime.extractCertificates(smimeData, contentType);
```

**Security Features:**
- PKCS#7 signature verification
- Certificate chain validation
- X.509 certificate parsing
- Encryption/decryption support
- Certificate caching

### 7. AdvancedMIMEParser (Rich Content Types)

Processes advanced MIME types including calendars, contacts, and documents.

```javascript
const advancedParser = new AdvancedMIMEParser({
    extractCalendarEvents: true,
    extractVCardContacts: true,
    extractXMLContent: true,
    extractDocumentMetadata: true
});

const result = await advancedParser.processAdvancedMIME(mimePart);
```

**Supported Formats:**
- iCalendar/vCalendar events
- vCard contacts
- XML documents
- PDF metadata
- Office document metadata

### 8. MemoryManager (Streaming Support)

Manages memory usage for large file processing.

```javascript
const memoryManager = new MemoryManager({
    maxMemory: 10 * 1024 * 1024,
    gcThreshold: 0.8,
    enableDetailedTracking: true
});

memoryManager.startMonitoring();
const allocationId = memoryManager.trackAllocation('chunk', size, context);
```

**Memory Features:**
- Allocation tracking
- Garbage collection optimization
- Memory pressure monitoring
- Streaming chunk management
- Performance profiling

## Installation & Usage

### Basic Setup

```javascript
// Include all required components
const parser = new EmailParser({
    debug: false,
    enableRecovery: true,
    enableSMIME: true,
    enableAdvancedMIME: true
});

// Parse an email file
async function parseEmail(file) {
    try {
        const email = await parser.parse(file);
        
        console.log('Subject:', email.subject);
        console.log('From:', email.from);
        console.log('Body Text:', email.body.text);
        console.log('Attachments:', email.attachments.length);
        
        return email;
    } catch (error) {
        console.error('Parsing failed:', error.message);
        throw error;
    }
}
```

### File Input Methods

```javascript
// From File input element
const fileInput = document.getElementById('fileInput');
const file = fileInput.files[0];
const email = await parser.parse(file);

// From Blob
const blob = new Blob([arrayBuffer], { type: 'application/vnd.ms-outlook' });
const email = await parser.parse(blob);

// From ArrayBuffer (create File-like object)
const file = new File([arrayBuffer], 'email.msg', { 
    type: 'application/vnd.ms-outlook' 
});
const email = await parser.parse(file);
```

## API Reference

### EmailParser Class

#### Constructor Options

```javascript
new EmailParser({
    debug: boolean,                    // Enable debug logging
    enableRecovery: boolean,           // Enable error recovery
    enableSMIME: boolean,              // Enable S/MIME processing
    enableAdvancedMIME: boolean,       // Enable advanced MIME types
    enableStreaming: boolean,          // Enable streaming for large files
    streamingThreshold: number,        // Size threshold for streaming (bytes)
    maxStreamingMemory: number,        // Max memory for streaming (bytes)
    maxRecoveryAttempts: number,       // Max recovery attempts
    verifySignatures: boolean,         // Verify S/MIME signatures
    extractCertificates: boolean,      // Extract certificates
    extractCalendarEvents: boolean,    // Extract calendar data
    extractVCardContacts: boolean,     // Extract contact data
    extractAttachmentText: boolean,    // Extract text from attachments
    processAttachments: boolean        // Process attachment metadata
})
```

#### Main Methods

```javascript
// Parse email file
async parse(file, options = {})

// Get parsing statistics
getStats()

// Get streaming statistics (if enabled)
getStreamingStats()

// Clear internal cache
clearCache()

// Set debug mode
setDebug(boolean)

// Cancel streaming operations
cancelStreaming()
```

#### Parse Options

```javascript
await parser.parse(file, {
    forceStreaming: boolean,           // Force streaming mode
    forceTraditional: boolean,         // Force traditional parsing
    streamingThreshold: number,        // Override streaming threshold
    chunkSize: number,                 // Streaming chunk size
    enableStreamingFallback: boolean,  // Allow fallback to traditional
    extractPlainText: boolean,         // Extract combined plain text
    processAttachments: boolean        // Process attachment metadata
});
```

### Email Object Structure

The parsed email object has the following structure:

```javascript
{
    // Basic email fields
    subject: string,
    from: {
        name: string,
        email: string,
        addressType: string,
        searchKey: Uint8Array
    },
    to: Array<{name: string, email: string}>,
    cc: Array<{name: string, email: string}>,
    bcc: Array<{name: string, email: string}>,
    date: Date,
    
    // Body content
    body: {
        text: string,           // Plain text body
        html: string,           // HTML body
        rtf: string,            // RTF content (if available)
        enriched: string,       // Enriched text
        embeddedImages: Array   // Images from RTF
    },
    
    // Attachments
    attachments: Array<{
        name: string,
        type: string,
        size: number,
        data: Uint8Array,
        detectedType: string,
        contentId: string,
        isInline: boolean,
        advanced: Object,       // Advanced MIME parsing results
        calendarData: Object,   // Calendar events (if applicable)
        contactData: Object,    // Contact data (if applicable)
        documentData: Object    // Document metadata (if applicable)
    }>,
    
    // Embedded messages
    threads: Array<EmailObject>,
    
    // Headers and metadata
    headers: Map<string, string>,
    metadata: {
        messageClass: string,
        importance: number,
        priority: number,
        sensitivity: number,
        size: number,
        hasAttachments: boolean,
        conversationTopic: string,
        conversationIndex: Uint8Array,
        internetMessageId: string,
        creationTime: Date,
        lastModificationTime: Date,
        fileInfo: Object,
        parseTime: string,
        features: Object
    },
    
    // Security information
    security: {
        smime: {
            present: boolean,
            signatureVerified: boolean,
            certificateValidated: boolean,
            encryptionDetected: boolean,
            certificates: Array,
            processingTime: string
        }
    },
    
    // Parser information
    parserInfo: {
        type: string,           // 'msg' or 'eml'
        version: string,        // Parser version
        processingMode: string, // 'traditional' or 'streaming'
        memoryUsed: number,
        chunkSize: string,
        oleVersion: string,     // For MSG files
        mimeVersion: string,    // For EML files
        properties: number,     // Property count (MSG)
        attachments: number,    // Attachment count
        embeddedMessages: number
    },
    
    // Raw property data (for debugging)
    fragments: Array<{
        name: string,
        propId: string,
        typeId: string,
        size: number,
        textSample: string,
        fullText: string,
        rawData: Uint8Array
    }>
}
```

## Advanced Features

### Streaming Support

For large email files (>25MB by default), the parser automatically switches to streaming mode:

```javascript
const parser = new EmailParser({
    enableStreaming: true,
    streamingThreshold: 50 * 1024 * 1024,  // 50MB threshold
    maxStreamingMemory: 20 * 1024 * 1024   // 20MB memory limit
});

// Monitor streaming progress
parser.memoryManager.startMonitoring((pressure, stats) => {
    console.log('Memory pressure:', pressure.pressure);
    console.log('Memory usage:', stats.currentUsage);
});

const email = await parser.parse(largeFile);
```

### S/MIME Security Processing

```javascript
const parser = new EmailParser({
    enableSMIME: true,
    verifySignatures: true,
    extractCertificates: true,
    strictValidation: true
});

const email = await parser.parse(signedEmail);

if (email.security?.smime?.present) {
    console.log('S/MIME signature verified:', email.security.smime.signatureVerified);
    console.log('Certificates found:', email.security.smime.certificates?.length);
}
```

### Advanced MIME Type Processing

```javascript
const parser = new EmailParser({
    enableAdvancedMIME: true,
    extractCalendarEvents: true,
    extractVCardContacts: true,
    extractDocumentMetadata: true
});

const email = await parser.parse(file);

// Check for calendar events in attachments
email.attachments.forEach(attachment => {
    if (attachment.calendarData) {
        console.log('Calendar events:', attachment.calendarData.events);
    }
    if (attachment.contactData) {
        console.log('Contacts:', attachment.contactData.contacts);
    }
    if (attachment.documentData) {
        console.log('Document metadata:', attachment.documentData.metadata);
    }
});
```

### Error Recovery

```javascript
const parser = new EmailParser({
    enableRecovery: true,
    maxRecoveryAttempts: 5,
    bypassDamagedSectors: true,
    reconstructFAT: true,
    lenientParsing: true,
    skipCorruptedHeaders: true
});

// Parser will attempt to recover from various file corruption issues
const email = await parser.parse(corruptedFile);
```

## Configuration Options

### Memory Management

```javascript
const memoryManager = new MemoryManager({
    maxMemory: 50 * 1024 * 1024,      // 50MB limit
    gcThreshold: 0.8,                  // Trigger GC at 80%
    monitorInterval: 5000,             // Monitor every 5 seconds
    enableDetailedTracking: true       // Track individual allocations
});
```

### S/MIME Configuration

```javascript
const smimeOptions = {
    verifySignatures: true,            // Verify digital signatures
    extractCertificates: true,         // Extract certificate data
    maxCertificateChain: 5,           // Max certificate chain length
    strictValidation: true             // Strict certificate validation
};
```

### Advanced MIME Configuration

```javascript
const advancedMimeOptions = {
    extractCalendarEvents: true,       // Process calendar attachments
    extractVCardContacts: true,        // Process contact cards
    extractXMLContent: true,           // Process XML documents
    extractDocumentMetadata: true,     // Extract document metadata
    maxAdvancedMIMESize: 10 * 1024 * 1024, // 10MB limit
    enableBinaryExtraction: true       // Extract binary content
};
```

## Examples

### Basic Email Parsing

```javascript
async function parseBasicEmail(file) {
    const parser = new EmailParser();
    const email = await parser.parse(file);
    
    return {
        subject: email.subject,
        from: `${email.from.name} <${email.from.email}>`,
        to: email.to.map(addr => `${addr.name} <${addr.email}>`),
        date: email.date,
        bodyText: email.body.text,
        bodyHtml: email.body.html,
        attachmentCount: email.attachments.length
    };
}
```

### Processing Attachments

```javascript
async function processAttachments(file) {
    const parser = new EmailParser({
        processAttachments: true,
        extractAttachmentText: true,
        enableAdvancedMIME: true
    });
    
    const email = await parser.parse(file);
    
    const attachmentInfo = email.attachments.map(attachment => ({
        name: attachment.name,
        type: attachment.type,
        size: attachment.size,
        detectedType: attachment.detectedType,
        hasCalendarData: !!attachment.calendarData,
        hasContactData: !!attachment.contactData,
        textPreview: attachment.text?.substring(0, 100)
    }));
    
    return attachmentInfo;
}
```

### Handling Large Files with Streaming

```javascript
async function parseLargeEmail(file) {
    const parser = new EmailParser({
        enableStreaming: true,
        streamingThreshold: 10 * 1024 * 1024, // 10MB
        maxStreamingMemory: 5 * 1024 * 1024   // 5MB
    });
    
    // Monitor memory usage
    parser.memoryManager?.startMonitoring((pressure, stats) => {
        if (pressure.needsGc) {
            console.log('High memory pressure detected');
        }
    });
    
    try {
        const email = await parser.parse(file);
        
        // Get streaming statistics
        const streamingStats = parser.getStreamingStats();
        console.log('Peak memory usage:', streamingStats.memoryManager?.peakUsage);
        
        return email;
    } finally {
        parser.memoryManager?.stopMonitoring();
    }
}
```

### S/MIME Signature Verification

```javascript
async function verifySignedEmail(file) {
    const parser = new EmailParser({
        enableSMIME: true,
        verifySignatures: true,
        extractCertificates: true
    });
    
    const email = await parser.parse(file);
    
    if (email.security?.smime?.present) {
        const smimeInfo = {
            signatureVerified: email.security.smime.signatureVerified,
            certificateCount: email.security.smime.certificates?.length || 0,
            encryptionDetected: email.security.smime.encryptionDetected
        };
        
        // Check individual attachments for S/MIME data
        email.attachments.forEach(attachment => {
            if (attachment.certificates) {
                console.log(`Attachment ${attachment.name} has certificates:`, 
                           attachment.certificates.length);
            }
        });
        
        return smimeInfo;
    }
    
    return { signatureVerified: false, reason: 'No S/MIME content found' };
}
```

### Calendar Event Extraction

```javascript
async function extractCalendarEvents(file) {
    const parser = new EmailParser({
        enableAdvancedMIME: true,
        extractCalendarEvents: true
    });
    
    const email = await parser.parse(file);
    const events = [];
    
    // Check attachments for calendar data
    email.attachments.forEach(attachment => {
        if (attachment.calendarData?.events) {
            events.push(...attachment.calendarData.events.map(event => ({
                title: event.title,
                start: event.start,
                end: event.end,
                location: event.location,
                description: event.description,
                organizer: event.organizer,
                attendees: event.attendees
            })));
        }
    });
    
    return events;
}
```

## Performance & Memory Management

### Memory Optimization

The library includes sophisticated memory management:

```javascript
// Configure memory limits
const parser = new EmailParser({
    enableStreaming: true,
    maxStreamingMemory: 10 * 1024 * 1024,  // 10MB limit
    streamingThreshold: 25 * 1024 * 1024   // Stream files >25MB
});

// Monitor memory usage
const stats = parser.getStreamingStats();
console.log('Memory efficiency:', stats.memoryManager?.memoryEfficiency);
console.log('GC cycles:', stats.memoryManager?.gcCycles);
```

### Performance Monitoring

```javascript
// Get detailed performance statistics
const stats = parser.getStats();
console.log('Files processed:', stats.filesProcessed);
console.log('Average processing time:', stats.averageDuration);
console.log('S/MIME operations:', stats.cryptoStats?.signaturesVerified);
console.log('Advanced MIME processed:', stats.advancedMimeStats?.totalProcessed);
```

### Streaming Configuration

```javascript
// Fine-tune streaming behavior
const streamingOptions = {
    chunkSize: 2 * 1024 * 1024,        // 2MB chunks for MSG
    enableStreamingFallback: true,      // Allow fallback to traditional
    preferTraditional: false,           // Prefer streaming when available
    streamingThreshold: 50 * 1024 * 1024 // Custom threshold
};

const email = await parser.parse(file, streamingOptions);
```

## Security Features

### Input Validation

The library includes comprehensive input validation:

- File size limits (configurable)
- Content type validation
- Header sanitization
- XSS prevention in extracted content
- Buffer overflow protection

### Secure Credential Handling

```javascript
// All test data is clearly marked
const testCertificate = {
    subject: 'CN=TEST_USER_SYNTHETIC',  // Clearly marked as test data
    issuer: 'CN=TEST_CA_SYNTHETIC',     // Not real credentials
    // ... other test properties
};
```

### S/MIME Security

```javascript
// Comprehensive certificate validation
const smime = new SMIMECrypto({
    strictValidation: true,             // Strict certificate validation
    maxCertificateChain: 5,            // Limit certificate chain length
    verifySignatures: true             // Always verify signatures
});
```

## Error Handling & Recovery

### Basic Error Handling

```javascript
try {
    const email = await parser.parse(file);
    // Process email
} catch (error) {
    if (error.message.includes('File too large')) {
        // Handle large file error
        console.log('File exceeds size limit');
    } else if (error.message.includes('Invalid OLE')) {
        // Handle format error
        console.log('Invalid file format');
    } else {
        // Handle other errors
        console.error('Parsing failed:', error.message);
    }
}
```

### Recovery Options

```javascript
const parser = new EmailParser({
    enableRecovery: true,
    maxRecoveryAttempts: 5,
    
    // MSG recovery options
    bypassDamagedSectors: true,
    reconstructFAT: true,
    skipCorruptedProperties: true,
    
    // EML recovery options
    lenientParsing: true,
    skipCorruptedHeaders: true,
    repairMultpart: true,
    healBrokenMIME: true
});

// Parser will attempt to recover from various corruption issues
const email = await parser.parse(corruptedFile);
```

### Graceful Degradation

```javascript
// The parser attempts to extract as much data as possible
const email = await parser.parse(partiallyCorruptedFile);

// Check what was successfully extracted
if (email.subject) console.log('Subject extracted successfully');
if (email.body.text) console.log('Body text extracted successfully');
if (email.attachments.length > 0) console.log('Some attachments extracted');

// Check for warnings
if (email.metadata.parseError) {
    console.log('Parsing completed with warnings:', email.metadata.parseError);
}
```

---

## Browser Compatibility

The library is compatible with modern browsers supporting:
- ES2017+ features
- File API
- ArrayBuffer/DataView
- TextEncoder/TextDecoder
- Web Crypto API (for S/MIME features)

## Node.js Compatibility

The library also works in Node.js environments with appropriate polyfills for browser-specific APIs.

---

*This documentation covers the core email parser library components. For the complete email inspector application and testing tools, see the separate application documentation.*