/**
 * Enhanced OLE Parser with Recovery Capabilities
 * Extends the base OLE parser with corruption recovery features
 * Handles damaged sectors, FAT reconstruction, and partial data extraction
 */
class EnhancedOLEParser extends OLEParser {
    constructor(options = {}) {
        super();
        this.recoveryOptions = {
            bypassDamagedSectors: options.bypassDamagedSectors || false,
            reconstructFAT: options.reconstructFAT || false,
            fatReconstructionMode: options.fatReconstructionMode || 'adaptive',
            maxSkippedSectors: options.maxSkippedSectors || 10,
            skipCorruptedProperties: options.skipCorruptedProperties !== false,
            validateSectorChains: options.validateSectorChains !== false,
            enableSectorRecovery: options.enableSectorRecovery !== false
        };

        this.damagedSectors = new Set();
        this.skippedSectors = new Set();
        this.recoveryLog = [];
    }

    async parseFile(file, recoveryContext = null) {
        try {
            // Reset recovery state for new file
            this.resetRecoveryState();

            // Attempt normal parsing first
            if (!this.recoveryOptions.bypassDamagedSectors && !this.recoveryOptions.reconstructFAT) {
                return await super.parseFile(file);
            }

            // Enhanced parsing with recovery
            const result = await this.parseWithRecovery(file);

            // Add recovery metadata
            result.recovery = {
                activated: true,
                damagedSectors: Array.from(this.damagedSectors),
                skippedSectors: Array.from(this.skippedSectors),
                recoveryLog: this.recoveryLog,
                successRate: this.calculateSuccessRate(result)
            };

            return result;

        } catch (error) {
            if (this.recoveryOptions.bypassDamagedSectors || this.recoveryOptions.reconstructFAT) {
                // If we're in recovery mode and still failed, log it
                this.recoveryLog.push({
                    level: 'error',
                    message: `Final parse failure: ${error.message}`,
                    timestamp: new Date().toISOString()
                });

                throw new Error(`Recovery failed: ${error.message}`);
            }

            // Re-throw original error if not in recovery mode
            throw error;
        }
    }

    async parseWithRecovery(file) {
        this.recoveryLog.push({
            level: 'info',
            message: 'Starting enhanced parsing with recovery options',
            options: this.recoveryOptions
        });

        let buffer, header, fat, miniFat, directories, tree, rootEntry;

        try {
            buffer = await file.arrayBuffer();
        } catch (error) {
            throw new Error(`File access error: ${error.message}`);
        }

        // Step 1: Parse header with signature validation
        header = this.parseHeaderRecovery(buffer);

        // Step 2: Build FAT with recovery
        if (this.recoveryOptions.reconstructFAT) {
            fat = this.buildFATRcovery(buffer, header);
        } else {
            fat = this.buildFATRecovery(buffer, header);
        }

        // Step 3: Build Mini-FAT with recovery
        miniFat = this.buildMiniFATRcovery(buffer, header, fat);

        // Step 4: Parse directory structure with recovery
        ({ directories, tree } = this.parseDirectoriesRecovery(buffer, header, fat));

        // Step 5: Find root entry
        rootEntry = directories.find(d => d.type === 5);
        if (!rootEntry && !this.recoveryOptions.skipCorruptedProperties) {
            throw new Error('Root directory entry not found');
        }

        // Step 6: Complete property analysis with full recovery
        const propertyAnalysis = await this.analyzePropertiesRecovery(
            buffer, directories, header, fat, miniFat, rootEntry
        );

        const result = {
            header,
            directories,
            tree,
            fat,
            miniFat,
            propertyAnalysis,
            rootEntry,
            rawSize: buffer.byteLength
        };

        this.recoveryLog.push({
            level: 'success',
            message: 'Enhanced parsing completed',
            stats: {
                damagedSectors: this.damagedSectors.size,
                skippedSectors: this.skippedSectors.size,
                totalDirectories: directories.length,
                totalProperties: propertyAnalysis.totalProperties
            }
        });

        return result;
    }

    parseHeaderRecovery(buffer) {
        if (buffer.byteLength < 512) {
            const error = 'File too small for OLE format';
            this.recoveryLog.push({ level: 'error', message: error });
            throw new Error(error);
        }

        const view = new DataView(buffer);

        // Validate OLE signature with recovery
        const signature = Array.from(new Uint8Array(buffer, 0, 8))
            .map(b => b.toString(16).padStart(2, '0')).join('');

        if (signature !== 'd0cf11e0a1b11ae1') {
            const error = `Invalid OLE file signature: ${signature}`;
            this.recoveryLog.push({ level: 'error', message: error });

            if (!this.recoveryOptions.bypassDamagedSectors) {
                throw new Error(error);
            }

            // Try alternative signatures or forced parsing
            this.recoveryLog.push({
                level: 'warning',
                message: 'Attempting recovery without signature validation'
            });
        }

        try {
            const header = super.parseHeader(view);
            this.recoveryLog.push({ level: 'info', message: 'Header parsed successfully' });
            return header;
        } catch (error) {
            if (this.recoveryOptions.bypassDamagedSectors) {
                // Create minimal header for recovery
                const minimalHeader = this.createMinimalHeader(view);
                this.recoveryLog.push({
                    level: 'warning',
                    message: `Using minimal header: ${error.message}`
                });
                return minimalHeader;
            }
            throw error;
        }
    }

    createMinimalHeader(view) {
        // Create a minimal header for severely corrupted files
        const signature = Array.from(new Uint8Array(view.buffer, 0, 8));

        return {
            minorVersion: view.getUint16(24, true),
            majorVersion: Math.min(view.getUint16(26, true), 4), // Cap version
            byteOrder: view.getUint16(28, true) === 0xFFFE ? 0xFFFE : 0xFFFE, // Force little endian
            sectorSize: 512, // Default to 512
            miniSectorSize: 64, // Default to 64
            directoryFirstSector: 0,
            miniStreamCutoff: Math.min(view.getUint32(56, true) || 4096, 4096),
            reserved1: 0,
            reserved2: 0,
            fatSectors: 1,
            directoryFirstSector: 0,
            transactionSignature: 0,
            miniFatFirstSector: 0xFFFFFFFE,
            miniFatSectors: 0,
            difatFirstSector: 0xFFFFFFFE,
            difatSectors: 0
        };
    }

    buildFATRecovery(buffer, header) {
        try {
            const fat = this.buildCompleteFAT(new DataView(buffer), header);
            this.recoveryLog.push({ level: 'info', message: 'FAT built successfully' });
            return fat;
        } catch (error) {
            if (!this.recoveryOptions.reconstructFAT) {
                throw error;
            }

            this.recoveryLog.push({
                level: 'warning',
                message: `FAT construction failed, attempting reconstruction: ${error.message}`
            });
            return this.reconstructFAT(buffer, header);
        }
    }

    buildFATRcovery(buffer, header) {
        // Alias for consistency
        return this.buildFATRecovery(buffer, header);
    }

    buildMiniFATRcovery(buffer, header, fat) {
        try {
            const miniFat = this.buildMiniFAT(new DataView(buffer), header, fat);
            this.recoveryLog.push({ level: 'info', message: 'Mini-FAT built successfully' });
            return miniFat;
        } catch (error) {
            if (this.recoveryOptions.reconstructFAT) {
                this.recoveryLog.push({
                    level: 'warning',
                    message: `Mini-FAT construction failed: ${error.message}`
                });
                // Continue with empty minifat - will skip mini-streams
                return [];
            }
            throw error;
        }
    }

    parseDirectoriesRecovery(buffer, header, fat) {
        try {
            const result = this.parseDirectories(new DataView(buffer), header, fat);
            this.recoveryLog.push({
                level: 'info',
                message: 'Directory structure parsed successfully',
                directoryCount: result.directories.length
            });
            return result;
        } catch (error) {
            if (!this.recoveryOptions.bypassDamagedSectors) {
                throw error;
            }

            this.recoveryLog.push({
                level: 'warning',
                message: `Directory parsing failed, attempting recovery: ${error.message}`
            });
            return this.recoverDirectories(buffer, header, fat);
        }
    }

    async analyzePropertiesRecovery(buffer, directories, header, fat, miniFat, rootEntry) {
        try {
            const analysis = this.analyzePropertiesComplete(new DataView(buffer), directories, header, fat, miniFat, rootEntry);
            this.recoveryLog.push({
                level: 'info',
                message: 'Property analysis completed',
                propertyCount: analysis.totalProperties
            });
            return analysis;
        } catch (error) {
            if (!this.recoveryOptions.skipCorruptedProperties) {
                throw error;
            }

            this.recoveryLog.push({
                level: 'warning',
                message: `Property analysis failed, attempting recovery: ${error.message}`
            });
            return this.recoverProperties(buffer, directories, header, fat, miniFat, rootEntry);
        }
    }

    reconstructFAT(buffer, header) {
        const view = new DataView(buffer);
        const fat = [];

        // Start with known good sector patterns
        const sectorCount = Math.floor(buffer.byteLength / header.sectorSize);

        // Initialize FAT with free sectors
        for (let i = 0; i < sectorCount; i++) {
            fat[i] = 0xFFFFFFFF; // Free sector
        }

        // Mark header sectors as special
        fat[0] = 0xFFFFFFFD; // Special (header)
        fat[1] = 0xFFFFFFFE; // End of chain

        // Try to reconstruct FAT chains using heuristics
        const reconstructedChains = this.reconstructSectorChains(buffer, header, sectorCount);

        // Apply reconstructed chains to FAT
        for (const chain of reconstructedChains) {
            for (let i = 0; i < chain.length - 1; i++) {
                const currentSector = chain[i];
                const nextSector = chain[i + 1];

                if (currentSector < fat.length) {
                    fat[currentSector] = nextSector;
                }
            }

            // Mark last sector as end of chain
            const lastSector = chain[chain.length - 1];
            if (lastSector < fat.length) {
                fat[lastSector] = 0xFFFFFFFE;
            }
        }

        this.recoveryLog.push({
            level: 'info',
            message: `FAT reconstruction completed: ${reconstructedChains.length} chains found`
        });

        return fat;
    }

    reconstructSectorChains(buffer, header, sectorCount) {
        const chains = [];
        const processedSectors = new Set();

        for (let sectorIndex = 2; sectorIndex < sectorCount; sectorIndex++) {
            if (processedSectors.has(sectorIndex)) continue;

            const chain = this.findSectorChain(buffer, header, sectorIndex, processedSectors);
            if (chain.length > 1) { // Only keep non-trivial chains
                chains.push(chain);
                chain.forEach(s => processedSectors.add(s));
            }
        }

        return chains;
    }

    findSectorChain(buffer, header, startSector, processedSectors) {
        const chain = [];
        let currentSector = startSector;
        const visited = new Set();

        while (currentSector !== undefined && currentSector < processedSectors.size &&
               !visited.has(currentSector) && chain.length < 1000) { // Prevent infinite loops

            // Stop if we hit a known bad/marked sector
            if (this.damagedSectors.has(currentSector) || this.skippedSectors.has(currentSector)) {
                break;
            }

            visited.add(currentSector);
            chain.push(currentSector);

            // Try to find next sector using various heuristics
            const nextSector = this.predictNextSector(buffer, header, currentSector);

            if (nextSector === null || nextSector === currentSector) {
                break; // End of chain or invalid
            }

            currentSector = nextSector;
        }

        return chain;
    }

    predictNextSector(buffer, header, currentSector) {
        // Simple heuristic: look for sector alignment and common patterns
        const sectorOffset = (currentSector + 1) * header.sectorSize;

        if (sectorOffset + header.sectorSize > buffer.byteLength) {
            return null; // Sector extends beyond file
        }

        // Check for sector alignment patterns (this is heuristic-based)
        const maxChecks = Math.min(10, header.sectorSize / 4);
        let potentialNext = null;

        for (let offset = 4; offset < maxChecks; offset += 4) {
            const value = new DataView(buffer).getUint32(sectorOffset + offset, true);

            // Look for values that could be sector pointers
            if (value >= 2 && value < 0xFFFFFF00) {
                potentialNext = value;
                break;
            }
        }

        return potentialNext;
    }

    recoverDirectories(buffer, header, fat) {
        const directories = [];
        const tree = { root: null, nodes: new Map() };
        let currentSector = header.directoryFirstSector;
        let recoveredCount = 0;

        // Search for directory sectors across the file
        for (let sectorIndex = 0; sectorIndex < Math.min(1000, buffer.byteLength / header.sectorSize); sectorIndex++) {
            try {
                const result = this.tryExtractDirectoriesFromSector(buffer, header, sectorIndex);

                if (result.length > 0) {
                    directories.push(...result);
                    recoveredCount += result.length;

                    if (this.debug) {
                        console.log(`Recovered ${result.length} directories from sector ${sectorIndex}`);
                    }
                }
            } catch (error) {
                // Continue to next sector
                continue;
            }

            // Stop if we have enough directories
            if (recoveredCount >= 100) break;
        }

        // Build minimal tree structure
        const treeResult = this.buildRecoveryDirectoryTree(directories);

        this.recoveryLog.push({
            level: 'warning',
            message: `Directory recovery completed: ${directories.length} entries found`
        });

        return { directories, tree: treeResult };
    }

    tryExtractDirectoriesFromSector(buffer, header, sectorIndex) {
        const directories = [];
        const view = new DataView(buffer);
        const sectorOffset = (sectorIndex + 1) * header.sectorSize;

        if (sectorOffset + header.sectorSize > buffer.byteLength) return directories;

        // Scan sector for directory entry patterns
        for (let entryIndex = 0; entryIndex < header.sectorSize; entryIndex += 128) {
            const entryOffset = sectorOffset + entryIndex;

            if (entryOffset + 128 > buffer.byteLength) break;

            const nameLength = view.getUint16(entryOffset + 64, true);

            // Check for valid directory entry characteristics
            if (nameLength > 0 && nameLength <= 64) {
                try {
                    const entry = this.parseDirectoryEntry(view, entryOffset);

                    // Validate entry
                    if (entry && entry.name && [1, 2, 5].includes(entry.type)) {
                        directories.push(entry);
                    }
                } catch (error) {
                    // Skip invalid entry
                    continue;
                }
            }
        }

        return directories;
    }

    buildRecoveryDirectoryTree(directories) {
        const tree = { root: null, nodes: new Map() };

        // Simple tree reconstruction based on naming patterns
        directories.forEach((dir, index) => {
            tree.nodes.set(index, {
                ...dir,
                children: [],
                leftSibling: 0xFFFFFFFF,
                rightSibling: 0xFFFFFFFF,
                child: 0xFFFFFFFF
            });
        });

        // Try to find root
        for (let i = 0; i < directories.length; i++) {
            if (directories[i].type === 5) { // Root
                tree.root = i;
                break;
            }
        }

        if (tree.root === null && directories.length > 0) {
            tree.root = 0; // Default to first directory
        }

        return tree;
    }

    recoverProperties(buffer, directories, header, fat, miniFat, rootEntry) {
        const analysis = {
            totalProperties: 0,
            samples: [],
            attachments: [],
            embeddedMessages: []
        };

        // Process only non-damaged directories
        for (const dir of directories) {
            if (!dir.name || !dir.name.startsWith('__substg1.0_')) continue;

            try {
                // Attempt to read property data with recovery
                const propertySample = this.readPropertyRecovery(buffer, dir, header, fat, miniFat, rootEntry);

                if (propertySample) {
                    analysis.samples.push(propertySample);
                    analysis.totalProperties++;

                    // Categorize recovered properties
                    this.categorizeRecoveredProperty(propertySample, analysis, dir);
                }
            } catch (error) {
                this.recoveryLog.push({
                    level: 'warning',
                    message: `Property recovery failed for ${dir.name}: ${error.message}`
                });
                continue;
            }
        }

        this.recoveryLog.push({
            level: 'info',
            message: `Property recovery completed: ${analysis.totalProperties} recovered`
        });

        return analysis;
    }

    readPropertyRecovery(buffer, dir, header, fat, miniFat, rootEntry) {
        try {
            let data;

            // Determine if this is a mini-stream or regular stream with recovery
            if (dir.size < header.miniStreamCutoff && dir.size > 0) {
                data = this.readMiniStreamRecovery(buffer, dir.startSector, dir.size, header, miniFat, rootEntry);
            } else {
                data = this.readCompleteSectorChainRecovery(buffer, dir.startSector, dir.size, header, fat);
            }

            if (!data || data.length === 0) {
                return null;
            }

            const propId = dir.name.match(/__substg1\.0_([0-9A-F]{4})([0-9A-F]{4})/)?.[1];
            const typeId = dir.name.match(/__substg1\.0_([0-9A-F]{4})([0-9A-F]{4})/)?.[2];

            return {
                name: dir.name,
                propId,
                typeId,
                size: dir.size,
                actualSize: data.length,
                isBinary: this.isBinaryProperty(propId, typeId),
                textSample: this.tryDecodeText(data.slice(0, 200)),
                fullText: null,
                rawData: null,
                recoveryNote: data.length !== dir.size ? `Recovered ${data.length}/${dir.size} bytes` : null
            };

        } catch (error) {
            // Mark as damaged for statistics
            this.damagedSectors.add(dir.startSector);
            throw error;
        }
    }

    readCompleteSectorChainRecovery(buffer, startSector, size, header, fat) {
        if (startSector >= (fat?.length || 0) || size === 0) {
            // Try alternative reading without FAT
            return this.readSectorsDirect(buffer, startSector, Math.min(size, header.sectorSize), header);
        }

        return this.readSectorsFAT(buffer, startSector, size, header, fat);
    }

    readMiniStreamRecovery(buffer, startSector, size, header, miniFat, rootEntry) {
        if (!rootEntry) return new Uint8Array(0);

        try {
            return super.readMiniStream(buffer, startSector, size, header, miniFat, rootEntry);
        } catch (error) {
            // Fallback to direct mini-sector reading
            this.recoveryLog.push({
                level: 'warning',
                message: `Mini-stream read failed, attempting direct: ${error.message}`
            });

            const rootData = this.readSectorsFAT(buffer, rootEntry.startSector, rootEntry.size, header, []);
            const miniSectorOffset = startSector * header.miniSectorSize;

            if (miniSectorOffset + size > rootData.length) {
                return rootData.slice(miniSectorOffset, rootData.length);
            }

            return rootData.slice(miniSectorOffset, miniSectorOffset + size);
        }
    }

    readSectorsDirect(buffer, startSector, maxBytes, header) {
        const offset = (startSector + 1) * header.sectorSize;
        const availableBytes = Math.min(maxBytes, buffer.byteLength - offset);

        if (availableBytes <= 0) return new Uint8Array(0);

        return new Uint8Array(buffer, offset, availableBytes);
    }

    readSectorsFAT(buffer, startSector, size, header, fat) {
        // Enhanced version of super.readCompleteSectorChain with recovery
        const data = new Uint8Array(size);
        let bytesRead = 0;
        let currentSector = startSector;
        const processedSectors = new Set();

        while (bytesRead < size && currentSector !== 0xFFFFFFFE &&
               currentSector < (fat?.length || 0) &&
               !processedSectors.has(currentSector)) {

            // Mark potentially damaged sectors but continue
            if (this.damagedSectors.has(currentSector)) {
                this.skippedSectors.add(currentSector);
                break;
            }

            const sectorOffset = (currentSector + 1) * header.sectorSize;

            if (sectorOffset + header.sectorSize > buffer.byteLength) {
                this.damagedSectors.add(currentSector);
                this.recoveryLog.push({
                    level: 'warning',
                    message: `Sector ${currentSector} extends beyond file bounds`
                });
                break;
            }

            const bytesToRead = Math.min(header.sectorSize, size - bytesRead);

            try {
                for (let i = 0; i < bytesToRead; i++) {
                    data[bytesRead + i] = buffer[sectorOffset + i];
                }

                bytesRead += bytesToRead;
                processedSectors.add(currentSector);

                // Get next sector from FAT
                currentSector = fat?.[currentSector] ?? 0xFFFFFFFE;

            } catch (error) {
                this.damagedSectors.add(currentSector);
                this.recoveryLog.push({
                    level: 'warning',
                    message: `Error reading sector ${currentSector}: ${error.message}`
                });
                break;
            }
        }

        return data.slice(0, bytesRead);
    }

    categorizeRecoveredProperty(sample, analysis, dir) {
        // Similar to base implementation but with recovery tagging
        const attachmentInfo = {
            dirIndex: 0, // Not available in recovery
            name: 'Unknown Attachment',
            size: sample.size,
            type: 'unknown',
            method: 0,
            isEmbedded: false,
            recoveryAttempt: true
        };

        analysis.attachments.push(attachmentInfo);
    }

    calculateSuccessRate(result) {
        const totalDirectories = result.directories?.length || 0;
        const damagedCount = this.damagedSectors.size;
        const skippedCount = this.skippedSectors.size;

        if (totalDirectories === 0) return 0;

        const usableDirectories = totalDirectories - damagedCount;
        return Math.round((usableDirectories / totalDirectories) * 100);
    }

    resetRecoveryState() {
        this.damagedSectors.clear();
        this.skippedSectors.clear();
        this.recoveryLog = [];
    }

    getRecoveryReport() {
        return {
            damagedSectors: Array.from(this.damagedSectors),
            skippedSectors: Array.from(this.skippedSectors),
            recoveryLog: this.recoveryLog,
            summary: {
                damageDetected: this.damagedSectors.size > 0,
                sectorsSkipped: this.skippedSectors.size,
                logEntries: this.recoveryLog.length,
                recoveryLevel: this.recoveryOptions.enableSectorRecovery ? 'high' : 'standard'
            }
        };
    }
}

// Browser/Node.js compatibility
if (typeof window !== 'undefined') {
    window.EnhancedOLEParser = EnhancedOLEParser;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = EnhancedOLEParser;
}
