/**
 * Recovery Framework for Email Parser Suite
 * Production-grade error recovery for corrupted/damaged email files
 * Provides comprehensive recovery capabilities across all parsers
 */
class RecoveryFramework {
    constructor(options = {}) {
        this.debug = options.debug || false;
        this.maxRecoveryAttempts = options.maxRecoveryAttempts || 5;
        this.enablePartialRecovery = options.enablePartialRecovery !== false;
        this.recoveryStats = this.initializeStats();
    }

    initializeStats() {
        return {
            totalFiles: 0,
            recoveryActivated: 0,
            successfulRecovery: 0,
            partialRecovery: 0,
            totalFailures: 0,
            errorCategories: new Map(),
            lastRecovery: null,
            averageRecoveryTime: 0
        };
    }

    /**
     * Master recovery handler - analyzes damage and orchestrates recovery
     */
    async attemptRecovery(file, error, originalParser) {
        const startTime = performance.now();
        this.recoveryStats.totalFiles++;

        try {
            // Step 1: Analyze the error and categorize damage level
            const damageAnalysis = this.analyzeDamage(error);
            this.updateErrorStats(damageAnalysis.category);

            if (this.debug) {
                console.log('Damage Analysis:', damageAnalysis);
            }

            // Step 2: Choose recovery strategy based on damage level
            const recoveryStrategy = this.selectRecoveryStrategy(damageAnalysis);

            // Step 3: Execute recovery with progressive fallbacks
            const recoveryResult = await this.executeRecovery(recoveryStrategy, file, originalParser, damageAnalysis);

            // Step 4: Validate and enhance recovery results
            const enhancedResult = this.enhanceRecoveryResult(recoveryResult, damageAnalysis);

            // Step 5: Update statistics
            this.updateRecoveryStats(enhancedResult, performance.now() - startTime);

            return enhancedResult;

        } catch (recoveryError) {
            console.warn('Recovery failed:', recoveryError.message);
            this.recoveryStats.totalFailures++;
            throw recoveryError;
        }
    }

    analyzeDamage(error) {
        const damageAnalysis = {
            category: 'unknown',
            severity: 'medium',
            recoverable: false,
            damagePoints: new Set(),
            suggestedStrategy: 'fallback'
        };

        const errorMessage = error.message.toLowerCase();

        // OLE/MSG specific damage patterns
        if (errorMessage.includes('ole') || errorMessage.includes('cfb') || errorMessage.includes('fat')) {
            damageAnalysis.category = 'ole_corruption';
            damageAnalysis.severity = 'high';

            if (errorMessage.includes('signature')) {
                damageAnalysis.suggestedStrategy = 'header_repair';
                damageAnalysis.damagePoints.add('signature');
            } else if (errorMessage.includes('fat') || errorMessage.includes('sector')) {
                damageAnalysis.suggestedStrategy = 'sector_recovery';
                damageAnalysis.damagePoints.add('fat');
            } else if (errorMessage.includes('mini-stream')) {
                damageAnalysis.suggestedStrategy = 'mini_stream_recovery';
                damageAnalysis.damagePoints.add('mini-stream');
            }
        }
        // EML specific damage patterns
        else if (errorMessage.includes('eml') || errorMessage.includes('mime') || errorMessage.includes('rfc')) {
            damageAnalysis.category = 'mime_corruption';
            damageAnalysis.severity = 'medium';

            if (errorMessage.includes('header') || errorMessage.includes('parse')) {
                damageAnalysis.suggestedStrategy = 'header_reconstruction';
                damageAnalysis.damagePoints.add('headers');
            } else if (errorMessage.includes('multipart') || errorMessage.includes('boundary')) {
                damageAnalysis.suggestedStrategy = 'multipart_repair';
                damageAnalysis.damagePoints.add('multipart');
            } else if (errorMessage.includes('encoding')) {
                damageAnalysis.suggestedStrategy = 'encoding_fallback';
                damageAnalysis.damagePoints.add('encoding');
            }
        }
        // RTF specific damage patterns
        else if (errorMessage.includes('rtf') || errorMessage.includes('compression')) {
            damageAnalysis.category = 'rtf_corruption';
            damageAnalysis.severity = 'low';
            damageAnalysis.suggestedStrategy = 'rtf_fallback';
            damageAnalysis.damagePoints.add('rtf');
        }
        // General truncation/size errors
        else if (errorMessage.includes('truncated') || errorMessage.includes('size') || errorMessage.includes('bounds')) {
            damageAnalysis.category = 'truncation';
            damageAnalysis.severity = 'high';
            damageAnalysis.suggestedStrategy = 'partial_extraction';
            damageAnalysis.damagePoints.add('truncation');
        }

        // Determine recoverability
        damageAnalysis.recoverable = this.isRecoverable(damageAnalysis);

        return damageAnalysis;
    }

    isRecoverable(damageAnalysis) {
        // Never recoverable categories
        const unrecoverable = ['total_corruption', 'encryption_unsupported'];
        if (unrecoverable.includes(damageAnalysis.category)) {
            return false;
        }

        // Always recoverable categories
        const alwaysRecoverable = ['rtf_corruption', 'encoding_issue'];
        if (alwaysRecoverable.includes(damageAnalysis.category) || damageAnalysis.severity === 'low') {
            return true;
        }

        // Medium/high severity but potentially recoverable
        return true;
    }

    selectRecoveryStrategy(damageAnalysis) {
        return {
            type: damageAnalysis.suggestedStrategy,
            severity: damageAnalysis.severity,
            recoverableAreas: Array.from(damageAnalysis.damagePoints),
            fallbackChain: this.buildFallbackChain(damageAnalysis),
            maxAttempts: damageAnalysis.severity === 'high' ? 3 : 5,
            recoveryMode: damageAnalysis.category === 'truncation' ? 'partial' : 'complete'
        };
    }

    buildFallbackChain(damageAnalysis) {
        // Progressive fallback strategy
        const baseChain = [
            { name: 'primary_recovery', probability: 0.8 },
            { name: 'secondary_recovery', probability: 0.6 },
            { name: 'tertiary_recovery', probability: 0.4 },
            { name: 'minimal_recovery', probability: 0.2 },
            { name: 'failure_acknowledgment', probability: 0 }
        ];

        // Adjust based on damage type
        if (damageAnalysis.category === 'ole_corruption') {
            baseChain.unshift(
                { name: 'ole_sector_bypass', probability: 0.9 },
                { name: 'ole_fat_reconstruction', probability: 0.7 }
            );
        } else if (damageAnalysis.category === 'mime_corruption') {
            baseChain.unshift(
                { name: 'mime_header_repair', probability: 0.9 },
                { name: 'mime_boundary_detection', probability: 0.7 }
            );
        }

        return baseChain;
    }

    async executeRecovery(recoveryStrategy, file, originalParser, damageAnalysis) {
        this.recoveryStats.recoveryActivated++;
        let attemptIndex = 0;
        let lastError = null;

        for (const fallback of recoveryStrategy.fallbackChain) {
            if (attemptIndex >= recoveryStrategy.maxAttempts) break;

            if (this.debug) {
                console.log(`Attempting recovery: ${fallback.name} (probability: ${fallback.probability})`);
            }

            try {
                const recoveryResult = await this.executeFallbackMethod(fallback.name, file, originalParser, damageAnalysis);

                if (recoveryResult) {
                    recoveryResult.recoveryMethod = fallback.name;
                    recoveryResult.recoveryAttempt = attemptIndex + 1;
                    recoveryResult.damageAnalysis = damageAnalysis;
                    return recoveryResult;
                }
            } catch (e) {
                lastError = e;
                if (this.debug) {
                    console.warn(`${fallback.name} failed: ${e.message}`);
                }
            }

            attemptIndex++;
        }

        // All recovery attempts failed
        throw lastError || new Error(`All recovery methods failed for ${damageAnalysis.category}`);
    }

    async executeFallbackMethod(methodName, file, originalParser, damageAnalysis) {
        switch (methodName) {
            case 'ole_sector_bypass':
                return await this.recoverOLESectorBypass(file, originalParser);
            case 'ole_fat_reconstruction':
                return await this.recoverOLEFATReconst(file, originalParser);
            case 'mime_header_repair':
                return await this.recoverMIMEHeaderRepair(file, originalParser);
            case 'mime_boundary_detection':
                return await this.recoverMIMEBoundaryFix(file, originalParser);
            case 'rtf_fallback':
                return await this.recoverRTFFallback(file, originalParser);
            case 'primary_recovery':
            default:
                // Generic recovery - adjust parser settings
                return await this.executeGenericRecovery(file, originalParser, 'primary');
        }
    }

    async recoverOLESectorBypass(file, oleParser) {
        if (this.debug) console.log('OLE Sector Bypass Recovery');

        // Enhance OLE parser with sector bypass capabilities
        const enhancedParser = new RecoveryOLEParser(oleParser, {
            bypassDamagedSectors: true,
            reconstructFAT: false,
            maxSkippedSectors: 10
        });

        try {
            const analysis = await enhancedParser.parseFile(file);
            return await oleParser.enhancedMSGExtractor.extractEmail(analysis);
        } catch (e) {
            throw new Error(`OLE sector bypass failed: ${e.message}`);
        }
    }

    async recoverOLEFATReconst(file, oleParser) {
        if (this.debug) console.log('OLE FAT Reconstruction Recovery');

        const enhancedParser = new RecoveryOLEParser(oleParser, {
            bypassDamagedSectors: true,
            reconstructFAT: true,
            fatReconstructionMode: 'adaptive'
        });

        try {
            const analysis = await enhancedParser.parseFile(file);
            return await oleParser.enhancedMSGExtractor.extractEmail(analysis);
        } catch (e) {
            throw new Error(`OLE FAT reconstruction failed: ${e.message}`);
        }
    }

    async recoverMIMEHeaderRepair(file, emlParser) {
        if (this.debug) console.log('MIME Header Repair Recovery');

        const enhancedParser = new RecoveryEMLParser(emlParser, {
            reconstructHeaders: true,
            repairMultpart: false,
            lenientParsing: true
        });

        try {
            return await enhancedParser.parseFile(file);
        } catch (e) {
            throw new Error(`MIME header repair failed: ${e.message}`);
        }
    }

    async recoverMIMEBoundaryFix(file, emlParser) {
        if (this.debug) console.log('MIME Boundary Detection Recovery');

        const enhancedParser = new RecoveryEMLParser(emlParser, {
            reconstructHeaders: false,
            repairMultpart: true,
            autoDetectBoundaries: true,
            lenientParsing: true
        });

        try {
            return await enhancedParser.parseFile(file);
        } catch (e) {
            throw new Error(`MIME boundary fix failed: ${e.message}`);
        }
    }

    async recoverRTFFallback(file, originalParser) {
        if (this.debug) console.log('RTF Fallback Recovery');

        let result;
        try {
            result = await originalParser.parse(file, { disallowRTF: true });
        } catch (e) {
            // If that fails, try without any RTF processing
            result = await originalParser.parse(file, { extractHTMLBodies: false, extractRTF: false });
        }

        if (!result) {
            throw new Error('RTF fallback recovery could not extract content');
        }

        return result;
    }

    async executeGenericRecovery(file, originalParser, level) {
        const options = {
            strictValidation: false,
            lenientParsing: true,
            ignoreEncodingErrors: true,
            recoveryMode: level
        };

        return await originalParser.parse(file, options);
    }

    enhanceRecoveryResult(recoveryResult, damageAnalysis) {
        if (!recoveryResult) return null;

        // Mark as recovered data
        recoveryResult.recovery = {
            activated: true,
            damageCategory: damageAnalysis.category,
            severity: damageAnalysis.severity,
            partialRecovery: recoveryResult.recoveryMode === 'partial',
            extractedDataPercentage: this.estimateDataExtraction(recoveryResult, damageAnalysis),
            warnings: this.generateRecoveryWarnings(damageAnalysis),
            timestamp: new Date().toISOString()
        };

        return recoveryResult;
    }

    estimateDataExtraction(recoveryResult, damageAnalysis) {
        // Rough estimation based on recovered components
        let score = 0.5; // Base score for attempting recovery

        if (recoveryResult.subject) score += 0.1;
        if (recoveryResult.from && recoveryResult.from.email) score += 0.1;
        if (recoveryResult.to && recoveryResult.to.length > 0) score += 0.1;
        if (recoveryResult.body && Object.values(recoveryResult.body).some(text => text)) score += 0.2;
        if (recoveryResult.attachments && recoveryResult.attachments.length > 0) score += 0.2;

        // Adjust based on damage size
        if (damageAnalysis.severity === 'high') score *= 0.8;
        if (damageAnalysis.severity === 'low') score *= 1.1;

        return Math.min(Math.round(score * 100), 100);
    }

    generateRecoveryWarnings(damageAnalysis) {
        const warnings = [];

        if (damageAnalysis.category === 'ole_corruption') {
            warnings.push('File corruption detected in OLE structure');
            warnings.push('Some properties may be missing or incomplete');
        } else if (damageAnalysis.category === 'mime_corruption') {
            warnings.push('MIME structure damage detected');
            warnings.push('Multipart boundaries may be incomplete');
        } else if (damageAnalysis.category === 'truncation') {
            warnings.push('File appears truncated');
            warnings.push('Not all content could be recovered');
        }

        if (damageAnalysis.severity === 'high') {
            warnings.push('Severe corruption detected - recovery success not guaranteed');
        }

        warnings.push('Recovered data should be verified before use');

        return warnings;
    }

    updateRecoveryStats(result, duration) {
        if (result && result.recovery) {
            this.recoveryStats.successfulRecovery++;

            if (result.recovery.partialRecovery) {
                this.recoveryStats.partialRecovery++;
            }
        }

        // Update average recovery time
        this.recoveryStats.averageRecoveryTime =
            (this.recoveryStats.averageRecoveryTime + duration) / 2;

        this.recoveryStats.lastRecovery = result ? result : null;
    }

    updateErrorStats(category) {
        this.recoveryStats.errorCategories.set(
            category,
            (this.recoveryStats.errorCategories.get(category) || 0) + 1
        );
    }

    getRecoveryStats() {
        return {
            ...this.recoveryStats,
            errorCategoriesSummary: Object.fromEntries(this.recoveryStats.errorCategories),
            recoveryRate: this.recoveryStats.successfulRecovery / Math.max(1, this.recoveryStats.totalFiles),
            partialRecoveryRate: this.recoveryStats.partialRecovery / Math.max(1, this.recoveryStats.successfulRecovery)
        };
    }

    resetStats() {
        this.recoveryStats = this.initializeStats();
    }
}

// Placeholder for enhanced parser classes
class RecoveryOLEParser {
    constructor(baseParser, options) {
        Object.assign(this, baseParser);
        this.recoveryOptions = options;
    }
}

class RecoveryEMLParser {
    constructor(baseParser, options) {
        Object.assign(this, baseParser);
        this.recoveryOptions = options;
    }
}

// Browser/Node.js compatibility
if (typeof window !== 'undefined') {
    window.RecoveryFramework = RecoveryFramework;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { RecoveryFramework, RecoveryOLEParser, RecoveryEMLParser };
}
