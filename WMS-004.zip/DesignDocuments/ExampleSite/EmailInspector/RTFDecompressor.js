/**
 * RTF Decompressor for Microsoft MSG Files
 * Implements MS-OXRTFCP specification for compressed RTF data
 * Handles LZFU compression algorithm used by Outlook
 */
class RTFDecompressor {
    constructor() {
        this.debug = false;
        
        // RTF control words dictionary as per MS-OXRTFCP specification
        this.dictionary = this.buildRTFDictionary();
    }

    buildRTFDictionary() {
        // Standard RTF dictionary with most common control words and formatting
        return "{\\rtf1\\ansi\\mac\\deff0\\deftab720{\\fonttbl;}{\\f0\\fswiss MS Sans Serif;}{\\f1\\froman\\fcharset2 Symbol;}{\\f2\\fswiss\\fcharset2 Symbol;}{\\f3\\froman Times New Roman;}{\\f4\\fswiss Helvetica;}{\\colortbl\\red0\\green0\\blue0\r\n\\par \\pard\\plain\\f0\\fs20\\b\\i\\u\\tab\\tx";
    }

    /**
     * Decompresses RTF data using LZFU algorithm
     * @param {Uint8Array} compressedData - Compressed RTF data from PID 0x1009
     * @returns {string} Decompressed RTF content
     */
    decompress(compressedData) {
        if (!compressedData || compressedData.length < 16) {
            throw new Error('Invalid compressed RTF data: too short');
        }

        const view = new DataView(compressedData.buffer, compressedData.byteOffset);
        
        // Parse RTF compression header (MS-OXRTFCP 2.1.1)
        const header = this.parseHeader(view);
        
        if (this.debug) {
            console.log('RTF Header:', header);
        }

        // Validate header
        this.validateHeader(header);

        // Extract compressed payload
        const compressedPayload = new Uint8Array(
            compressedData.buffer, 
            compressedData.byteOffset + 16, 
            header.compressedSize - 16
        );

        // Decompress using LZFU algorithm
        let decompressed;
        if (header.compressionType === 0x75465A4C) { // 'LZFu'
            decompressed = this.decompressLZFU(compressedPayload, header.uncompressedSize);
        } else if (header.compressionType === 0x414C454D) { // 'MELA' - uncompressed
            decompressed = new TextDecoder('utf-8').decode(compressedPayload);
        } else {
            throw new Error(`Unsupported RTF compression type: 0x${header.compressionType.toString(16)}`);
        }

        // Validate CRC if present
        if (header.crc !== 0) {
            const calculatedCrc = this.calculateCRC32(decompressed);
            if (calculatedCrc !== header.crc) {
                console.warn(`RTF CRC mismatch: expected 0x${header.crc.toString(16)}, got 0x${calculatedCrc.toString(16)}`);
            }
        }

        return decompressed;
    }

    parseHeader(view) {
        return {
            compressedSize: view.getUint32(0, true),      // Total compressed size including header
            uncompressedSize: view.getUint32(4, true),    // Size of decompressed data
            compressionType: view.getUint32(8, true),     // LZFu (0x75465A4C) or MELA (0x414C454D)
            crc: view.getUint32(12, true)                 // CRC32 of uncompressed data
        };
    }

    validateHeader(header) {
        // Validate compression signature
        if (header.compressionType !== 0x75465A4C && header.compressionType !== 0x414C454D) {
            throw new Error(`Invalid RTF compression signature: 0x${header.compressionType.toString(16)}`);
        }

        // Sanity checks on sizes
        if (header.compressedSize < 16 || header.compressedSize > 16 * 1024 * 1024) {
            throw new Error(`Invalid compressed size: ${header.compressedSize}`);
        }

        if (header.uncompressedSize < 0 || header.uncompressedSize > 100 * 1024 * 1024) {
            throw new Error(`Invalid uncompressed size: ${header.uncompressedSize}`);
        }
    }

    /**
     * LZFU decompression algorithm implementation
     * Based on MS-OXRTFCP 2.2.2 specification
     */
    decompressLZFU(compressedData, expectedSize) {
        // Initialize dictionary buffer with RTF preload
        const dictBuffer = new Uint8Array(4096);
        const preloadData = new TextEncoder().encode(this.dictionary);
        
        // Copy preload data to start of dictionary buffer
        for (let i = 0; i < Math.min(preloadData.length, dictBuffer.length); i++) {
            dictBuffer[i] = preloadData[i];
        }

        let dictIndex = preloadData.length;
        const output = [];
        let dataIndex = 0;

        try {
            while (dataIndex < compressedData.length && output.length < expectedSize) {
                // Read control byte
                const controlByte = compressedData[dataIndex++];
                
                if (dataIndex > compressedData.length) {
                    break;
                }

                // Process 8 control bits
                for (let bit = 0; bit < 8 && dataIndex < compressedData.length && output.length < expectedSize; bit++) {
                    const isReference = (controlByte & (1 << bit)) !== 0;

                    if (isReference) {
                        // Handle back-reference (MS-OXRTFCP 2.2.2.1.1)
                        if (dataIndex + 1 >= compressedData.length) {
                            break;
                        }

                        const byte1 = compressedData[dataIndex++];
                        const byte2 = compressedData[dataIndex++];
                        
                        // Extract offset and length from 16-bit value
                        const combined = (byte2 << 8) | byte1;
                        const offset = combined & 0x0FFF;  // Lower 12 bits
                        const length = (combined >> 12) + 2;  // Upper 4 bits + 2

                        if (this.debug && output.length < 100) {
                            console.log(`Back-ref: offset=${offset}, length=${length}, dictIndex=${dictIndex}`);
                        }

                        // Copy from dictionary buffer
                        for (let i = 0; i < length && output.length < expectedSize; i++) {
                            const srcIndex = (offset + i) % 4096;
                            const byte = dictBuffer[srcIndex];
                            
                            output.push(byte);
                            dictBuffer[dictIndex % 4096] = byte;
                            dictIndex++;
                        }
                    } else {
                        // Handle literal byte (MS-OXRTFCP 2.2.2.1.2)
                        if (dataIndex >= compressedData.length) {
                            break;
                        }

                        const literalByte = compressedData[dataIndex++];
                        output.push(literalByte);
                        dictBuffer[dictIndex % 4096] = literalByte;
                        dictIndex++;
                    }
                }
            }
        } catch (e) {
            console.warn(`LZFU decompression error: ${e.message}`);
        }

        // Convert to string
        try {
            const result = new TextDecoder('utf-8', { fatal: false }).decode(new Uint8Array(output));
            return result;
        } catch (e) {
            // Fallback to latin1 if UTF-8 fails
            const result = Array.from(output).map(b => String.fromCharCode(b)).join('');
            return result;
        }
    }

    /**
     * Calculate CRC32 checksum for validation
     * Implementation of standard CRC32 algorithm
     */
    calculateCRC32(data) {
        const crcTable = this.getCRC32Table();
        let crc = 0xFFFFFFFF;
        
        const bytes = typeof data === 'string' ? new TextEncoder().encode(data) : data;
        
        for (let i = 0; i < bytes.length; i++) {
            const byte = bytes[i];
            crc = (crc >>> 8) ^ crcTable[(crc ^ byte) & 0xFF];
        }
        
        return (~crc) >>> 0; // Convert to unsigned 32-bit
    }

    /**
     * Generate CRC32 lookup table
     */
    getCRC32Table() {
        if (this._crcTable) {
            return this._crcTable;
        }

        const table = new Uint32Array(256);
        
        for (let i = 0; i < 256; i++) {
            let crc = i;
            
            for (let j = 0; j < 8; j++) {
                if (crc & 1) {
                    crc = (crc >>> 1) ^ 0xEDB88320;
                } else {
                    crc = crc >>> 1;
                }
            }
            
            table[i] = crc;
        }
        
        this._crcTable = table;
        return table;
    }

    /**
     * Utility method to convert RTF to plain text
     * Strips RTF control codes and returns readable text
     */
    rtfToPlainText(rtfContent) {
        if (!rtfContent || typeof rtfContent !== 'string') {
            return '';
        }

        let text = rtfContent;
        
        // First, handle line breaks BEFORE removing control words
        text = text.replace(/\\par\b/g, '\n');    // Paragraph breaks
        text = text.replace(/\\line\b/g, '\n');   // Line breaks  
        text = text.replace(/\\tab\b/g, '\t');    // Tab characters
        
        // Remove RTF header and font table
        text = text.replace(/^{\\rtf[^}]*}/, '');
        text = text.replace(/{\\fonttbl[^}]*}/g, '');
        text = text.replace(/{\\colortbl[^}]*}/g, '');
        
        // Remove other control words (but preserve our converted line breaks)
        text = text.replace(/\\[a-zA-Z]+\d*/g, '');
        text = text.replace(/\\[^a-zA-Z\n\t]/g, '');
        
        // Remove braces
        text = text.replace(/[{}]/g, '');
        
        // Clean up whitespace but preserve line breaks
        text = text.replace(/[ \f\r\v]+/g, ' ');  // Replace other whitespace but not \n or \t
        text = text.replace(/\n\s+/g, '\n');      // Remove spaces at start of lines
        text = text.replace(/\s+\n/g, '\n');      // Remove spaces at end of lines
        text = text.replace(/\n{3,}/g, '\n\n');   // Limit consecutive line breaks to 2
        
        return text.trim();
    }

    /**
     * Extract embedded images from RTF content
     * Returns array of image data objects
     */
    extractImages(rtfContent) {
        const images = [];
        
        if (!rtfContent || typeof rtfContent !== 'string') {
            return images;
        }

        // Find image objects in RTF
        const imageRegex = /{\\pict[^}]*\\bliptag\d+[^}]*\\blipupi\d+[^}]*([0-9A-Fa-f\s]+)}/g;
        let match;
        
        while ((match = imageRegex.exec(rtfContent)) !== null) {
            try {
                const hexData = match[1].replace(/\s/g, '');
                
                if (hexData.length > 0 && hexData.length % 2 === 0) {
                    const imageData = new Uint8Array(hexData.length / 2);
                    
                    for (let i = 0; i < hexData.length; i += 2) {
                        imageData[i / 2] = parseInt(hexData.substr(i, 2), 16);
                    }
                    
                    // Detect image format
                    let format = 'unknown';
                    if (imageData[0] === 0xFF && imageData[1] === 0xD8) {
                        format = 'jpeg';
                    } else if (imageData[0] === 0x89 && imageData[1] === 0x50) {
                        format = 'png';
                    } else if (imageData[0] === 0x42 && imageData[1] === 0x4D) {
                        format = 'bmp';
                    }
                    
                    images.push({
                        format: format,
                        data: imageData,
                        size: imageData.length
                    });
                }
            } catch (e) {
                console.warn('Failed to extract RTF image:', e.message);
            }
        }
        
        return images;
    }

    /**
     * Convert RTF to HTML
     * Basic conversion preserving formatting
     */
    rtfToHTML(rtfContent) {
        if (!rtfContent || typeof rtfContent !== 'string') {
            return '';
        }

        let html = rtfContent;
        
        // Convert paragraphs
        html = html.replace(/\\par\s*/g, '</p><p>');
        html = html.replace(/\\line\s*/g, '<br>');
        
        // Convert formatting
        html = html.replace(/\\b\s*/g, '<b>');
        html = html.replace(/\\b0\s*/g, '</b>');
        html = html.replace(/\\i\s*/g, '<i>');
        html = html.replace(/\\i0\s*/g, '</i>');
        html = html.replace(/\\ul\s*/g, '<u>');
        html = html.replace(/\\ul0\s*/g, '</u>');
        
        // Remove remaining control words
        html = html.replace(/\\[a-zA-Z]+\d*\s*/g, '');
        html = html.replace(/\\[^a-zA-Z\s]/g, '');
        
        // Clean up braces
        html = html.replace(/[{}]/g, '');
        
        // Wrap in paragraph tags
        html = `<p>${html}</p>`;
        
        // Clean up empty tags
        html = html.replace(/<p>\s*<\/p>/g, '');
        html = html.replace(/\s+/g, ' ').trim();
        
        return html;
    }
}

// Browser compatibility
if (typeof window !== 'undefined') {
    window.RTFDecompressor = RTFDecompressor;
}

// Node.js compatibility
if (typeof module !== 'undefined' && module.exports) {
    module.exports = RTFDecompressor;
}
