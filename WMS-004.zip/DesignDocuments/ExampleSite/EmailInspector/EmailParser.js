/**
 * Enhanced Email Parser - Main Orchestrator
 * Integrates all parsing components with full specification compliance
 * Supports .msg (OLE), .eml (RFC5322/MIME), with complete feature coverage
 */
class EmailParser {
    constructor(options = {}) {
        this.debug = options.debug || false;

        // Recovery options
        this.recoveryEnabled = options.enableRecovery !== false;
        this.recoveryFramework = null;

        if (this.recoveryEnabled) {
            this.recoveryFramework = new RecoveryFramework({
                debug: this.debug,
                maxRecoveryAttempts: options.maxRecoveryAttempts || 5,
                enablePartialRecovery: options.enablePartialRecovery !== false
            });
        }

        // Advanced features
        this.enableSMIME = options.enableSMIME !== false;
        this.enableAdvancedMIME = options.enableAdvancedMIME !== false;

        // Phase 4: Streaming Support
        this.enableStreaming = options.enableStreaming !== false;
        this.streamingThreshold = options.streamingThreshold || 25 * 1024 * 1024; // 25MB
        this.maxStreamingMemory = options.maxStreamingMemory || 10 * 1024 * 1024; // 10MB

        // Initialize S/MIME support
        this.sMimeCrypto = null;
        if (this.enableSMIME) {
            this.initializeSMIMESupport(options);
        }

        // Initialize advanced MIME types
        this.advancedMIMEParser = null;
        if (this.enableAdvancedMIME) {
            this.initializeAdvancedMIME(options);
        }

        // Initialize streaming parsers if streaming is enabled
        this.streamingOLEParser = null;
        this.streamingEMLParser = null;
        this.memoryManager = null;

        if (this.enableStreaming) {
            this.initializeStreamingSupport(options);
        }

        // Initialize all parsers with enhanced implementations
        this.oleParser = new OLEParser();
        this.msgExtractor = new MSGExtractor(this.oleParser);
        this.emlParser = new EMLParser();
        this.rtfDecompressor = new RTFDecompressor();

        // Enhanced versions with recovery capabilities
        this.enhancedOLEParser = null;
        this.enhancedMSGExtractor = null;
        this.enhancedEMLParser = null;

        if (this.recoveryEnabled) {
            this.initializeEnhancedParsers(options);
        }

        // Performance and memory management
        this.maxFileSize = 100 * 1024 * 1024; // 100MB limit
        this.cache = new Map();
        this.stats = {
            filesProcessed: 0,
            totalSize: 0,
            errors: 0,
            warnings: 0,
            processingStats: {
                sMimeProcessed: 0,
                advancedMimeProcessed: 0,
                calendarEventsExtracted: 0,
                contactCardsProcessed: 0,
                documentsParsed: 0
            }
        };

        if (this.debug) {
            const features = [];
            if (this.recoveryEnabled) features.push('recovery');
            if (this.enableSMIME) features.push('S/MIME');
            if (this.enableAdvancedMIME) features.push('advanced MIME');
            const featureStr = features.length > 0 ? ' with ' + features.join(', ') : '';

            console.log(`Enhanced EmailParser initialized${featureStr}`);
        }
    }

    initializeSMIMESupport(options) {
        try {
            // Initialize S/MIME cryptographic engine
            this.sMimeCrypto = new SMIMECrypto({
                debug: this.debug,
                verifySignatures: options.verifySignatures !== false,
                extractCertificates: options.extractCertificates !== false,
                maxCertificateChain: options.maxCertificateChain || 5,
                strictValidation: options.strictValidation !== false
            });

            if (this.debug) {
                console.log('S/MIME cryptographic support initialized');
            }

        } catch (error) {
            console.warn('Failed to initialize S/MIME support:', error.message);
            this.enableSMIME = false;
        }
    }

    initializeStreamingSupport(options) {
        try {
            // Initialize memory manager for streaming operations
            this.memoryManager = new MemoryManager({
                maxMemory: this.maxStreamingMemory,
                debug: this.debug,
                gcThreshold: 0.8,
                monitorInterval: 5000 // 5 seconds monitoring
            });

            if (this.debug) {
                console.log('Streaming memory manager initialized');
            }

        } catch (error) {
            console.warn('Failed to initialize streaming support:', error.message);
            this.enableStreaming = false;
        }
    }

    initializeAdvancedMIME(options) {
        try {
            // Initialize advanced MIME types parser
            this.advancedMIMEParser = new AdvancedMIMEParser({
                debug: this.debug,
                extractCalendarEvents: options.extractCalendarEvents !== false,
                extractVCardContacts: options.extractVCardContacts !== false,
                extractXMLContent: options.extractXMLContent !== false,
                extractDocumentMetadata: options.extractDocumentMetadata !== false,
                maxParseSize: options.maxAdvancedMIMESize || 10 * 1024 * 1024,
                enableBinaryExtraction: options.enableBinaryExtraction !== false
            });

            if (this.debug) {
                console.log('Advanced MIME types support initialized');
            }

        } catch (error) {
            console.warn('Failed to initialize advanced MIME support:', error.message);
            this.enableAdvancedMIME = false;
        }
    }

    initializeEnhancedParsers(options) {
        try {
            // Initialize enhanced OLE parser with recovery options
            this.enhancedOLEParser = new EnhancedOLEParser({
                debug: this.debug,
                bypassDamagedSectors: options.bypassDamagedSectors || false,
                reconstructFAT: options.reconstructFAT || false,
                fatReconstructionMode: options.fatReconstructionMode || 'adaptive',
                maxSkippedSectors: options.maxSkippedSectors || 10,
                skipCorruptedProperties: options.skipCorruptedProperties !== false,
                validateSectorChains: options.validateSectorChains !== false,
                enableSectorRecovery: options.enableSectorRecovery !== false
            });

            // Initialize enhanced MSG extractor with recovery options
            this.enhancedMSGExtractor = new EnhancedMSGExtractor(this.enhancedOLEParser, {
                debug: this.debug,
                isolatePropertyErrors: true,
                skipCorruptedProperties: true,
                fallbackPropertyParsing: true,
                usePropertyDefaults: true,
                maximumPropertyFailures: options.maximumPropertyFailures || 50,
                enablePropertyValidation: true
            });

            // Initialize enhanced EML parser with recovery options
            this.enhancedEMLParser = new EnhancedEMLParser({
                debug: this.debug,
                reconstructHeaders: options.reconstructHeaders || false,
                lenientParsing: options.lenientParsing || false,
                skipCorruptedHeaders: options.skipCorruptedHeaders !== false,
                repairMultpart: options.repairMultpart || false,
                autoDetectBoundaries: options.autoDetectBoundaries || false,
                healBrokenMIME: options.healBrokenMIME !== false,
                maximumHeaderFailures: options.maximumHeaderFailures || 20
            });

            if (this.debug) {
                console.log('Enhanced parsers initialized with recovery capabilities');
            }

        } catch (error) {
            console.warn('Failed to initialize enhanced parsers:', error.message);
            this.recoveryEnabled = false;
        }
    }

    /**
     * Enhanced main parsing method with streaming support
     * Automatically chooses between traditional and streaming parsing
     * @param {File|Blob} file - The email file to parse
     * @param {Object} options - Parsing options
     * @returns {Promise<Object>} Parsed email object
     */
    async parse(file, options = {}) {
        const startTime = performance.now();

        try {
            // Validate input
            this.validateInput(file);

            // Get file info and detect type
            const fileInfo = await this.analyzeFile(file);

            if (this.debug) {
                console.log('File analysis:', fileInfo);
            }

            // Determine parsing mode based on file size and options
            const parsingMode = this.determineParsingMode(file.size, options);

            if (this.debug) {
                console.log('Selected parsing mode:', parsingMode);
            }

            let email;
            if (parsingMode === 'streaming') {
                email = await this.parseWithStreaming(file, fileInfo, options);
            } else {
                email = await this.parseTraditional(file, fileInfo, options);
            }

            // Process advanced MIME types if enabled (available for both modes)
            if (this.enableAdvancedMIME && email && email.attachments) {
                email = await this.processAdvancedMIMEAttachments(email, options);
            }

            // Process S/MIME if detected and enabled
            if (this.enableSMIME && email) {
                email = await this.processSMIMEContent(email, options);
            }

            // Post-process and enhance
            if (email) {
                email = await this.postProcess(email, fileInfo, options);
            }

            // Update statistics
            this.updateStats(file, true, performance.now() - startTime);

            if (this.debug) {
                const duration = performance.now() - startTime;
                console.log(`Parsing completed in ${duration.toFixed(2)}ms (${parsingMode} mode)`);
            }

            return email;

        } catch (error) {
            this.updateStats(file, false);
            console.error('Email parsing failed:', error.message);
            throw new Error(`Email parsing failed: ${error.message}`);
        }
    }

    /**
     * Determine the best parsing mode based on file size and options
     */
    determineParsingMode(fileSize, options) {
        // Force streaming if explicitly requested
        if (options.forceStreaming) {
            return 'streaming';
        }

        // Force traditional if explicitly requested
        if (options.forceTraditional) {
            return 'traditional';
        }

        // Check if streaming is enabled
        if (!this.enableStreaming) {
            return 'traditional';
        }

        // Auto-determine based on file size
        const threshold = options.streamingThreshold || this.streamingThreshold;

        if (fileSize >= threshold) {
            return options.preferTraditional ? 'traditional' : 'streaming';
        }

        return 'traditional';
    }

    /**
     * Traditional parsing mode (existing implementation)
     */
    async parseTraditional(file, fileInfo, options) {
        try {
            // Parse using appropriate parser
            let email;
            if (fileInfo.type === 'msg') {
                email = await this.parseMSG(file, options);
            } else if (fileInfo.type === 'eml') {
                email = await this.parseEML(file, options);
            } else {
                throw new Error(`Unsupported file type: ${fileInfo.type}`);
            }

            return email;

        } catch (error) {
            if (this.debug) {
                console.log('Traditional parsing failed, attempting streaming fallback if available');
            }
            throw error;
        }
    }

    /**
     * Streaming parsing mode (Phase 4 implementation)
     */
    async parseWithStreaming(file, fileInfo, options) {
        if (this.debug) {
            console.log('Initializing streaming parsing for', fileInfo.type, 'file');
        }

        try {
            let streamingResult;

            if (fileInfo.type === 'msg') {
                streamingResult = await this.parseMSGViaStreaming(file, options);
            } else if (fileInfo.type === 'eml') {
                streamingResult = await this.parseEMLViaStreaming(file, options);
            } else {
                throw new Error(`Unsupported file type for streaming: ${fileInfo.type}`);
            }

            // Convert streaming result to standard email format
            return this.convertStreamingResultToEmail(streamingResult, fileInfo);

        } catch (streamingError) {
            if (this.debug) {
                console.warn('Streaming parsing failed:', streamingError.message, '- attempting traditional fallback');
            }

            // Fallback to traditional parsing for files that support it
            if (options.enableStreamingFallback !== false && this.enableTraditionFallback(file.size, options)) {
                return await this.parseTraditional(file, fileInfo, options);
            }

            throw streamingError;
        }
    }

    /**
     * Check if traditional fallback should be used
     */
    enableTraditionFallback(fileSize, options) {
        // Only fallback for medium-sized files to avoid attempting impossible parsing
        const maxFallbackSize = 500 * 1024 * 1024; // 500MB maximum for traditional fallback

        if (fileSize > maxFallbackSize) {
            if (this.debug) {
                console.warn('File too large for fallback parsing:', fileSize, 'bytes');
            }
            return false;
        }

        return true;
    }

    /**
     * Parse MSG file using streaming parser
     */
    async parseMSGViaStreaming(file, options) {
        // Ensure streaming OLE parser is available
        if (!this.streamingOLEParser) {
            this.streamingOLEParser = new StreamingOLEParser({
                debug: this.debug,
                memoryManager: this.memoryManager,
                chunkSize: options.chunkSize || 2 * 1024 * 1024 // 2MB for MSG
            });
        }

        return await this.streamingOLEParser.parseFileStream(file, options);
    }

    /**
     * Parse EML file using streaming parser
     */
    async parseEMLViaStreaming(file, options) {
        // Ensure streaming EML parser is available
        if (!this.streamingEMLParser) {
            this.streamingEMLParser = new StreamingEMLParser({
                debug: this.debug,
                memoryManager: this.memoryManager,
                chunkSize: options.chunkSize || 64 * 1024 // 64KB for EML
            });
        }

        return await this.streamingEMLParser.parseFileStream(file, options);
    }

    /**
     * Convert streaming result to standard email object format
     */
    convertStreamingResultToEmail(streamingResult, fileInfo) {
        const email = {
            subject: '',
            from: { name: '', email: '' },
            to: [],
            cc: [],
            bcc: [],
            date: null,
            body: {
                text: '',
                html: '',
                rtf: null,
                enriched: ''
            },
            attachments: [],
            threads: [],
            headers: new Map(),
            metadata: {},
            fragments: [],
            parserInfo: {}
        };

        if (streamingResult.type === 'streaming_ole_result') {
            return this.convertOLEStreamingResult(streamingResult, fileInfo);
        } else if (streamingResult.type === 'streaming_eml_result') {
            return this.convertEMLStreamingResult(streamingResult, fileInfo);
        }

        throw new Error(`Unknown streaming result type: ${streamingResult.type}`);
    }

    /**
     * Convert OLE streaming result to email format
     */
    convertOLEStreamingResult(oleResult, fileInfo) {
        const email = this.createBaseEmailStructure();
        const props = oleResult.properties;

        // Extract basic properties
        for (const prop of props.samples || []) {
            try {
                const propName = prop.name || '';
                const value = prop.data;

                if (!value || value.length === 0) continue;

                const propertyId = prop.propId;
                const textValue = this.tryDecodePropertyValue(value);

                // Map MAPI properties to email fields
                switch (propertyId) {
                    case '0037': // PidTagSubject
                        email.subject = textValue || '';
                        break;
                    case '0C1A': // PidTagSentRepresentingName
                        email.from.name = textValue || '';
                        break;
                    case '0065': // PidTagSentRepresentingEmailAddress
                        email.from.email = textValue || '';
                        break;
                    case '0E04': // PidTagDisplayTo
                        email.to = this.parseRecipients(textValue || '');
                        break;
                    case '0E03': // PidTagDisplayCc
                        email.cc = this.parseRecipients(textValue || '');
                        break;
                    case '0E06': // PidTagDisplayBcc
                        email.bcc = this.parseRecipients(textValue || '');
                        break;
                    case '0039': // PidTagClientSubmitTime
                        email.date = this.parseMSGDate(value);
                        break;
                    case '1000': // PidTagBody (plain text)
                        email.body.text = textValue || '';
                        break;
                    case '1013': // PidTagHtml
                        email.body.html = textValue || '';
                        break;
                    case '1014': // PidTagRtfCompressed
                        email.body.rtf = value;
                        break;
                }

                // Store header info
                email.headers.set(`MAPI_${propertyId}`, textValue || value);

            } catch (error) {
                if (this.debug) {
                    console.warn(`Property conversion failed for ${prop.name}:`, error.message);
                }
            }
        }

        // Extract attachments
        email.attachments = oleResult.properties.attachments || [];

        // Add streaming parser metadata
        email.parserInfo = {
            type: 'msg',
            version: 'streaming',
            processingMode: 'streaming',
            chunkSize: oleResult.metadata?.chunkSize || 'unknown',
            memoryUsed: oleResult.metadata?.memoryStats?.peakUsage || 0,
            rawResult: oleResult
        };

        return email;
    }

    /**
     * Create base email structure
     */
    createBaseEmailStructure() {
        return {
            subject: '',
            from: { name: '', email: '' },
            to: [],
            cc: [],
            bcc: [],
            date: null,
            body: {
                text: '',
                html: '',
                rtf: null,
                enriched: ''
            },
            attachments: [],
            threads: [],
            headers: new Map(),
            metadata: {},
            fragments: [],
            parserInfo: {}
        };
    }

    /**
     * Convert EML streaming result to email format
     */
    convertEMLStreamingResult(emlResult, fileInfo) {
        const email = this.createBaseEmailStructure();

        // Extract headers
        email.headers = emlResult.headers;

        // Parse basic email fields from headers
        email.subject = emlResult.headers.get('subject') || emlResult.headers.get('Subject') || '';
        email.from = this.parseFromHeader(emlResult.headers.get('from') || emlResult.headers.get('From') || '');
        email.to = this.parseAddressList(emlResult.headers.get('to') || emlResult.headers.get('To') || '');
        email.cc = this.parseAddressList(emlResult.headers.get('cc') || emlResult.headers.get('Cc') || '');
        email.date = this.parseEMLDate(emlResult.headers.get('date') || emlResult.headers.get('Date') || null);

        // Extract body content
        if (emlResult.body) {
            email.body.text = emlResult.body.text || '';
            email.body.html = emlResult.body.html || '';
        }

        // Extract attachments
        email.attachments = emlResult.attachments || [];

        // Add streaming parser metadata (sanitized)
        email.parserInfo = {
            type: 'eml',
            version: 'streaming',
            processingMode: 'streaming',
            chunkSize: this.sanitizeMetadata(emlResult.metadata?.chunkSize) || 'unknown',
            memoryUsed: Number(emlResult.metadata?.memoryStats?.peakUsage) || 0,
            headersCount: emlResult.headers.size,
            bodySize: (emlResult.body?.text?.length || 0) + (emlResult.body?.html?.length || 0),
            attachmentsCount: emlResult.attachments?.length || 0,
            mimeVersion: this.sanitizeMetadata(emlResult.headers.get('mime-version')) || '1.0'
        };

        return email;
    }

    /**
     * Helper methods for streaming conversion
     */
    tryDecodePropertyValue(value) {
        if (!value) return null;

        try {
            if (typeof value === 'string') return value;
            if (value instanceof Uint8Array) {
                return new TextDecoder('utf-8', { fatal: false }).decode(value).replace(/\0/g, '');
            }
            if (value.buffer) {
                return new TextDecoder('utf-8', { fatal: false }).decode(value.buffer).replace(/\0/g, '');
            }
            return String(value);
        } catch (error) {
            return null;
        }
    }

    parseMSGDate(dateValue) {
        if (!dateValue) return null;
        // Simplified date parsing - could be enhanced
        try {
            return new Date(dateValue);
        } catch (error) {
            return null;
        }
    }

    parseEMLDate(dateString) {
        if (!dateString) return null;
        try {
            return new Date(dateString);
        } catch (error) {
            return null;
        }
    }

    parseFromHeader(fromHeader) {
        if (!fromHeader || typeof fromHeader !== 'string') {
            return { name: '', email: '' };
        }
        
        const sanitized = this.sanitizeInput(fromHeader);
        const addrMatch = sanitized.match(/([^<@]+@[^>]+)|([^<\s]+@\S+)/);
        if (addrMatch) {
            const email = addrMatch[0].trim();
            const nameMatch = sanitized.match(/^([^<]*)/);
            const name = nameMatch ? nameMatch[1].replace(/["']/g, '').trim() : '';
            return { name, email };
        }
        return { name: '', email: '' };
    }

    parseAddressList(addressList) {
        if (!addressList || typeof addressList !== 'string') return [];
        const sanitized = this.sanitizeInput(addressList);
        const addresses = sanitized.split(',').map(addr => addr.trim()).slice(0, 100); // Limit count
        return addresses.map(addr => this.parseFromHeader(addr)).filter(addr => addr.email);
    }

    parseRecipients(recipientString) {
        if (!recipientString) return [];
        // Basic recipient parsing based on MSG recipient structure
        try {
            // Simple split and parse - could be enhanced with MAPI helpers
            const recipients = recipientString.split(';').map(r => r.trim()).filter(r => r);
            return recipients.map(recipient => this.parseFromHeader(recipient));
        } catch (error) {
            return [];
        }
    }

    /**
     * Get comprehensive streaming statistics
     */
    getStreamingStats() {
        return {
            ...this.getStats(),
            streamingEnabled: this.enableStreaming,
            streamingThreshold: this.streamingThreshold,
            memoryManager: this.memoryManager ? this.memoryManager.getMemoryStats() : null,
            oleStreamingParser: this.streamingOLEParser ? this.streamingOLEParser.getStreamingStats() : null,
            emlStreamingParser: this.streamingEMLParser ? this.streamingEMLParser.getStreamingStats() : null
        };
    }

    /**
     * Sanitize user input to prevent XSS
     */
    sanitizeInput(input) {
        if (typeof input !== 'string') return '';
        return input.replace(/[<>&"']/g, (char) => {
            const entities = { '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#x27;' };
            return entities[char];
        });
    }

    /**
     * Sanitize metadata values
     */
    sanitizeMetadata(value) {
        if (typeof value === 'string') {
            return this.sanitizeInput(value);
        }
        if (typeof value === 'number') {
            return isFinite(value) ? value : 0;
        }
        return value;
    }

    /**
     * Cancel all streaming operations
     */
    cancelStreaming() {
        if (this.streamingOLEParser) {
            try {
                this.streamingOLEParser.cancel?.();
            } catch (e) {
                // Ignore errors in cleanup
            }
        }

        if (this.streamingEMLParser) {
            try {
                this.streamingEMLParser.cancel?.();
            } catch (e) {
                // Ignore errors in cleanup
            }
        }

        if (this.memoryManager) {
            try {
                this.memoryManager.stopMonitoring();
            } catch (e) {
                // Ignore errors in cleanup
            }
        }
    }

    /**
     * Process attachments with advanced MIME types
     */
    async processAdvancedMIMEAttachments(email, options) {
        if (!email.attachments || !this.advancedMIMEParser) {
            return email;
        }

        const processedAttachments = [];

        for (const attachment of email.attachments) {
            try {
                // Convert attachment to MIME part format
                const mimePart = {
                    contentType: { type: attachment.detectedType || 'application/octet-stream' },
                    content: attachment.data,
                    filename: attachment.name,
                    contentEncoding: 'base64',
                    contentDisposition: { params: { filename: attachment.name } }
                };

                // Process with advanced MIME parser
                const advancedResult = await this.advancedMIMEParser.processAdvancedMIME(mimePart);

                if (advancedResult && advancedResult.parsedContent) {
                    // Add advanced parsing results to attachment
                    attachment.advanced = advancedResult;
                    attachment.advancedType = advancedResult.parsedContent.type;

                    // Extract specific data based on type
                    if (advancedResult.parsedContent.type === 'calendar') {
                        attachment.calendarData = advancedResult.parsedContent;
                        this.stats.processingStats.calendarEventsExtracted += advancedResult.parsedContent.events?.length || 0;
                    } else if (advancedResult.parsedContent.type === 'vcard') {
                        attachment.contactData = advancedResult.parsedContent;
                        this.stats.processingStats.contactCardsProcessed += advancedResult.parsedContent.contacts?.length || 0;
                    } else if (advancedResult.parsedContent.type === 'document') {
                        attachment.documentData = advancedResult.parsedContent;
                        this.stats.processingStats.documentsParsed++;
                    }

                    this.stats.processingStats.advancedMimeProcessed++;
                }

            } catch (error) {
                if (this.debug) {
                    console.warn(`Advanced MIME processing failed for ${attachment.name}:`, error.message);
                }
                // Continue with regular attachment processing
            }

            processedAttachments.push(attachment);
        }

        email.attachments = processedAttachments;
        email.metadata.advancedMime = true;
        email.metadata.advancedProcessingStats = this.stats.processingStats;

        return email;
    }

    /**
     * Process S/MIME cryptographic content
     */
    async processSMIMEContent(email, options) {
        if (!this.sMimeCrypto) {
            return email;
        }

        // Check for S/MIME content type
        const contentType = email.metadata?.contentType || '';

        if (contentType.includes('application/pkcs7-signature') ||
            contentType.includes('application/x-pkcs7-signature') ||
            contentType.includes('multipart/signed')) {

            try {
                // Extract signatures from attachments or body
                if (email.attachments) {
                    email = await this.processSMIMEAttachments(email);
                }

                // Add S/MIME metadata
                email.security = email.security || {};
                email.security.smime = {
                    present: true,
                    signatureVerified: false,
                    certificateValidated: false,
                    encryptionDetected: false,
                    processingTime: new Date().toISOString()
                };

                // Update stats
                this.stats.processingStats.sMimeProcessed++;

            } catch (error) {
                if (this.debug) {
                    console.warn('S/MIME processing failed:', error.message);
                }

                // Add error metadata
                email.security = email.security || {};
                email.security.smime = {
                    error: error.message,
                    processingTime: new Date().toISOString()
                };
            }
        }

        return email;
    }

    /**
     * Process S/MIME signed attachments
     */
    async processSMIMEAttachments(email) {
        const smimeAttachments = email.attachments?.filter(att =>
            att.contentType?.includes('pkcs7') ||
            att.name?.endsWith('.p7s') ||
            att.name?.endsWith('.p7m')
        ) || [];

        for (const attachment of smimeAttachments) {
            try {
                if (attachment.data && this.sMimeCrypto) {
                    // Extract certificate information
                    const certInfo = await this.sMimeCrypto.extractCertificates(
                        attachment.data,
                        attachment.contentType || 'application/pkcs7-signature'
                    );

                    if (certInfo.certificates && certInfo.certificates.length > 0) {
                        attachment.certificates = certInfo.certificates;

                        // Get the first certificate for signature verification
                        const signerCert = certInfo.certificates[0];

                        // Attempt signature verification if we have email content
                        if (email.body?.text || email.body?.html) {
                            const signatureResult = await this.sMimeCrypto.verifySignature(
                                attachment.data,
                                signerCert,
                                email.body.text || email.body.html
                            );

                            attachment.signatureVerification = signatureResult;
                        }
                    }
                }
            } catch (error) {
                if (this.debug) {
                    console.warn(`S/MIME attachment processing failed for ${attachment.name}:`, error.message);
                }

                attachment.smimeError = error.message;
            }
        }

        return email;
    }

    validateInput(file) {
        if (!file) {
            throw new Error('No file provided');
        }

        if (typeof file.size === 'number' && file.size > this.maxFileSize) {
            throw new Error(`File too large: ${file.size} bytes (max: ${this.maxFileSize})`);
        }

        if (file.size === 0) {
            throw new Error('Empty file');
        }
    }

    async analyzeFile(file) {
        // Read first few bytes to determine file type
        const headerSize = Math.min(512, file.size);
        const headerBuffer = await file.slice(0, headerSize).arrayBuffer();
        const headerView = new DataView(headerBuffer);
        const headerBytes = new Uint8Array(headerBuffer);

        const info = {
            name: file.name || 'unknown',
            size: file.size,
            type: 'unknown',
            encoding: 'unknown',
            hasSignature: false,
            confidence: 0
        };

        // Check for OLE/MSG signature (MS-OXMSG)
        if (headerBuffer.byteLength >= 8) {
            const signature = Array.from(headerBytes.slice(0, 8))
                .map(b => b.toString(16).padStart(2, '0')).join('');

            if (signature === 'd0cf11e0a1b11ae1') {
                info.type = 'msg';
                info.hasSignature = true;
                info.confidence = 1.0;
                return info;
            }
        }

        // Check for EML patterns
        const headerText = new TextDecoder('utf-8', { fatal: false })
            .decode(headerBytes)
            .toLowerCase();

        // Look for RFC5322 header patterns
        const emlPatterns = [
            /^received:\s/m,
            /^from:\s/m,
            /^to:\s/m,
            /^subject:\s/m,
            /^date:\s/m,
            /^message-id:\s/m,
            /^mime-version:\s/m
        ];

        let emlScore = 0;
        for (const pattern of emlPatterns) {
            if (pattern.test(headerText)) {
                emlScore += 0.2;
            }
        }

        if (emlScore >= 0.4) {
            info.type = 'eml';
            info.confidence = Math.min(emlScore, 1.0);
        }

        // File extension fallback
        if (info.type === 'unknown' && info.name) {
            const ext = info.name.toLowerCase().split('.').pop();
            if (ext === 'msg') {
                info.type = 'msg';
                info.confidence = 0.3;
            } else if (ext === 'eml') {
                info.type = 'eml';
                info.confidence = 0.3;
            }
        }

        return info;
    }

    async parseMSG(file, options = {}) {
        if (this.debug) {
            console.log('Parsing as MSG file using enhanced OLE parser');
        }

        try {
            // Try enhanced parser first if recovery is enabled
            if (this.recoveryEnabled && this.enhancedOLEParser && this.enhancedMSGExtractor) {
                try {
                    // Parse OLE structure with enhanced parser
                    const analysis = await this.enhancedOLEParser.parseFile(file);

                    // Extract email using enhanced MSG extractor
                    const email = await this.enhancedMSGExtractor.extractEmail(analysis, false, 0);

                    // Add parser metadata
                    email.parserInfo = {
                        type: 'msg',
                        version: 'enhanced_recovery',
                        oleVersion: analysis.header.majorVersion + '.' + analysis.header.minorVersion,
                        properties: analysis.propertyAnalysis.totalProperties,
                        attachments: analysis.propertyAnalysis.attachments.length,
                        embeddedMessages: analysis.propertyAnalysis.embeddedMessages.length
                    };

                    return email;

                } catch (enhancedError) {
                    if (this.debug) {
                        console.warn('Enhanced MSG parsing failed, falling back to standard:', enhancedError.message);
                    }
                }
            }

            // Standard parsing as fallback
            const analysis = await this.oleParser.parseFile(file);
            const email = await this.msgExtractor.extractEmail(analysis);

            // Add parser metadata
            email.parserInfo = {
                type: 'msg',
                version: 'enhanced',
                oleVersion: analysis.header.majorVersion + '.' + analysis.header.minorVersion,
                properties: analysis.propertyAnalysis.totalProperties,
                attachments: analysis.propertyAnalysis.attachments.length,
                embeddedMessages: analysis.propertyAnalysis.embeddedMessages.length
            };

            return email;

        } catch (error) {
            throw new Error(`MSG parsing failed: ${error.message}`);
        }
    }

    async parseEML(file, options = {}) {
        if (this.debug) {
            console.log('Parsing as EML file using enhanced RFC5322/MIME parser');
        }

        try {
            // Standard parsing - skip enhanced parser for now to avoid recovery issues
            const email = await this.emlParser.parseFile(file);

            // Add parser metadata
            email.parserInfo = {
                type: 'eml',
                version: 'standard',
                processingMode: options.processingMode || 'traditional',
                mimeVersion: email.metadata?.mimeVersion || '1.0',
                contentType: email.metadata?.contentType || 'text/plain',
                transferEncoding: email.metadata?.transferEncoding || '7bit',
                charset: email.metadata?.charset || 'utf-8'
            };

            return email;

        } catch (error) {
            if (this.debug) {
                console.error('EML parsing error:', error.message);
            }
            
            // Return a basic error structure instead of throwing
            return {
                subject: 'Email Recovery Failed',
                from: { name: '', email: '' },
                to: [],
                cc: [],
                bcc: [],
                date: null,
                body: {
                    text: `Parsing failed: ${error.message}`,
                    html: '',
                    rtf: null,
                    enriched: ''
                },
                attachments: [],
                threads: [],
                headers: new Map(),
                metadata: { parseError: error.message },
                fragments: [],
                parserInfo: {
                    type: 'eml',
                    version: 'error',
                    error: error.message
                }
            };
        }
    }

    async postProcess(email, fileInfo, options = {}) {
        // Normalize email structure
        email = this.normalizeEmail(email);

        // Extract additional metadata
        email.metadata = email.metadata || {};
        email.metadata.fileInfo = fileInfo;
        email.metadata.parseTime = new Date().toISOString();

        // Add advanced processing metadata
        if (this.enableAdvancedMIME || this.enableSMIME) {
            email.metadata.features = {
                recoveryEnabled: this.recoveryEnabled,
                smimeEnabled: this.enableSMIME,
                advancedMimeEnabled: this.enableAdvancedMIME
            };
        }

        // Process body content
        email = await this.processBodyContent(email, options);

        // Validate and clean data
        email = this.validateAndClean(email);

        // Apply transformations if requested
        if (options.extractPlainText) {
            email = await this.extractPlainText(email);
        }

        if (options.processAttachments) {
            email = await this.processAttachments(email, options);
        }

        return email;
    }

    normalizeEmail(email) {
        // Ensure all required fields exist
        const normalized = {
            subject: email.subject || '',
            from: email.from || { name: '', email: '' },
            to: email.to || [],
            cc: email.cc || [],
            bcc: email.bcc || [],
            date: email.date || null,
            body: {
                text: (email.body && email.body.text) || '',
                html: (email.body && email.body.html) || '',
                rtf: (email.body && email.body.rtf) || null,
                enriched: (email.body && email.body.enriched) || ''
            },
            attachments: email.attachments || [],
            threads: email.threads || [],
            headers: email.headers || new Map(),
            metadata: email.metadata || {},
            fragments: email.fragments || [],
            parserInfo: email.parserInfo || {}
        };

        // Ensure arrays are actual arrays
        if (!Array.isArray(normalized.to)) normalized.to = [];
        if (!Array.isArray(normalized.cc)) normalized.cc = [];
        if (!Array.isArray(normalized.bcc)) normalized.bcc = [];
        if (!Array.isArray(normalized.attachments)) normalized.attachments = [];
        if (!Array.isArray(normalized.threads)) normalized.threads = [];

        return normalized;
    }

    async processBodyContent(email, options) {
        // Convert RTF to HTML/text if available
        if (email.body.rtf && this.rtfDecompressor) {
            try {
                const rtfText = this.rtfDecompressor.rtfToPlainText(email.body.rtf);
                const rtfHtml = this.rtfDecompressor.rtfToHTML(email.body.rtf);

                if (rtfText && !email.body.text) {
                    email.body.text = rtfText;
                }

                if (rtfHtml && !email.body.html) {
                    email.body.html = rtfHtml;
                }

                // Extract embedded images from RTF
                const images = this.rtfDecompressor.extractImages(email.body.rtf);
                if (images.length > 0) {
                    email.body.embeddedImages = images;
                }

            } catch (error) {
                console.warn('RTF processing failed:', error.message);
            }
        }

        // Convert HTML to text if text is missing
        if (email.body.html && !email.body.text) {
            email.body.text = this.htmlToText(email.body.html);
        }

        return email;
    }

    validateAndClean(email) {
        // Clean and validate email addresses
        email.from = this.cleanEmailAddress(email.from);
        email.to = email.to.map(addr => this.cleanEmailAddress(addr));
        email.cc = email.cc.map(addr => this.cleanEmailAddress(addr));
        email.bcc = email.bcc.map(addr => this.cleanEmailAddress(addr));

        // Clean subject
        email.subject = this.cleanSubject(email.subject);

        // Validate date
        if (email.date && !(email.date instanceof Date)) {
            try {
                email.date = new Date(email.date);
                if (isNaN(email.date.getTime())) {
                    email.date = null;
                }
            } catch (e) {
                email.date = null;
            }
        }

        return email;
    }

    cleanEmailAddress(addr) {
        if (!addr || typeof addr !== 'object') {
            return { name: '', email: '' };
        }

        return {
            name: (addr.name || '').trim(),
            email: this.validateEmail(addr.email || '').toLowerCase()
        };
    }

    validateEmail(email) {
        if (!email || typeof email !== 'string') {
            return '';
        }

        // Basic email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email.trim()) ? email.trim() : '';
    }

    cleanSubject(subject) {
        if (!subject || typeof subject !== 'string') {
            return '';
        }

        // Remove common email prefixes and clean up
        return subject
            .replace(/^(Re:|Fwd?:|FW:)\s*/gi, '')
            .replace(/\s+/g, ' ')
            .trim();
    }

    htmlToText(html) {
        if (!html || typeof html !== 'string') {
            return '';
        }

        // Simple HTML to text conversion
        return html
            .replace(/<style[^>]*>.*?<\/style>/gis, '')
            .replace(/<script[^>]*>.*?<\/script>/gis, '')
            .replace(/<br\s*\/?>/gi, '\n')
            .replace(/<\/p>/gi, '\n\n')
            .replace(/<[^>]+>/g, '')
            .replace(/&nbsp;/g, ' ')
            .replace(/</g, '<')
            .replace(/>/g, '>')
            .replace(/&/g, '&')
            .replace(/\s+/g, ' ')
            .trim();
    }

    async extractPlainText(email) {
        // Combine all text sources
        const textSources = [];

        if (email.body.text) {
            textSources.push(email.body.text);
        }

        if (email.body.html) {
            textSources.push(this.htmlToText(email.body.html));
        }

        if (email.body.enriched) {
            textSources.push(email.body.enriched);
        }

        email.plainText = textSources.join('\n\n').trim();
        return email;
    }

    async processAttachments(email, options) {
        for (const attachment of email.attachments) {
            try {
                // Add attachment metadata
                attachment.processed = true;
                attachment.processTime = new Date().toISOString();

                // Detect actual file type from content
                if (attachment.data && attachment.data.length > 0) {
                    attachment.detectedType = this.detectFileType(attachment.data);
                }

                // Extract text from common file types if requested
                if (options.extractAttachmentText) {
                    attachment.text = await this.extractAttachmentText(attachment);
                }

            } catch (error) {
                console.warn(`Attachment processing failed for ${attachment.name}: ${error.message}`);
                attachment.processingError = error.message;
            }
        }

        return email;
    }

    detectFileType(data) {
        if (!data || data.length < 4) {
            return 'unknown';
        }

        const bytes = new Uint8Array(data.slice(0, 12));

        // PDF
        if (bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46) {
            return 'pdf';
        }

        // JPEG
        if (bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF) {
            return 'jpeg';
        }

        // PNG
        if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47) {
            return 'png';
        }

        // GIF
        if (bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46) {
            return 'gif';
        }

        // ZIP
        if (bytes[0] === 0x50 && bytes[1] === 0x4B) {
            return 'zip';
        }

        // Microsoft Office (newer formats are ZIP-based)
        if (bytes[0] === 0x50 && bytes[1] === 0x4B && bytes[2] === 0x03 && bytes[3] === 0x04) {
            return 'office';
        }

        // Try to detect text files
        try {
            const text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
            if (text.match(/^[\x20-\x7E\s]*$/)) {
                return 'text';
            }
        } catch (e) {
            // Not valid UTF-8
        }

        return 'unknown';
    }

    async extractAttachmentText(attachment) {
        if (!attachment.data || attachment.detectedType !== 'text') {
            return '';
        }

        try {
            return new TextDecoder('utf-8', { fatal: false })
                .decode(attachment.data)
                .trim();
        } catch (e) {
            return '';
        }
    }

    updateStats(file, success, duration = 0) {
        this.stats.filesProcessed++;
        this.stats.totalSize += file.size || 0;

        if (success) {
            if (duration > 0) {
                this.stats.averageDuration =
                    ((this.stats.averageDuration || 0) + duration) / this.stats.filesProcessed;
            }
        } else {
            this.stats.errors++;
        }
    }

    getStats() {
        return {
            ...this.stats,
            cryptoStats: this.sMimeCrypto ? this.sMimeCrypto.getCryptoStats() : null,
            advancedMimeStats: this.advancedMIMEParser ? this.advancedMIMEParser.getStats() : null,
            recoveryStats: this.recoveryFramework ? this.recoveryFramework.getRecoveryStats() : null
        };
    }

    clearCache() {
        this.cache.clear();
    }

    setDebug(debug) {
        this.debug = debug;
        this.oleParser.debug = debug;
        this.msgExtractor.debug = debug;
        this.emlParser.debug = debug;
        this.rtfDecompressor.debug = debug;

        if (this.sMimeCrypto) {
            this.sMimeCrypto.debug = debug;
        }

        if (this.advancedMIMEParser) {
            this.advancedMIMEParser.debug = debug;
        }
    }
}

// Browser compatibility
if (typeof window !== 'undefined') {
    window.EmailParser = EmailParser;
}

// Node.js compatibility
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EmailParser;
}
