/**
 * Streaming OLE Parser for Large MSG Files
 * Processes OLE/MAPI files in memory-efficient chunks
 * Maintains compatibility with Enhanced OLE Parser recovery features
 */
class StreamingOLEParser extends OLEParser {
    constructor(options = {}) {
        super();
        this.chunkSize = options.chunkSize || 2 * 1024 * 1024;
        this.maxMemory = options.maxMemory || 10 * 1024 * 1024;
        this.debug = options.debug || false;

        // Streaming state tracking
        this.fatCache = new Map();
        this.miniFatCache = new Map();
        this.directoryCache = new Map();
        this.headerParsed = false;
        this.processingState = 'idle';

        // Memory and progress tracking
        this.memoryManager = options.memoryManager || new MemoryManager({ debug: this.debug });
        this.streamingTracker = new StreamingMemoryTracker(this.memoryManager);

        if (this.debug) {
            console.log('StreamingOLEParser initialized with chunk size:', this.chunkSize, 'bytes');
        }
    }

    /**
     * Stream parse MSG file in chunks
     */
    async parseFileStream(file, options = {}) {
        const startTime = performance.now();
        this.processingState = 'initializing';

        try {
            const fileSize = file.size;
            const chunkCount = Math.ceil(fileSize / this.chunkSize);

            // Start memory monitoring
            this.memoryManager.startMonitoring();

            const results = [];
            let headerInfo = null;
            let fatInfo = [];
            let directories = [];
            let properties = [];

            // Step 1: Process header chunk
            if (this.debug) console.log('Streaming OLE: Processing header chunk');
            const headerResult = await this.processHeaderChunk(file, 0);
            headerInfo = headerResult.header;
            results.push(headerResult);

            // Step 2: Process FAT chunks (if needed for large files)
            if (this.debug) console.log('Streaming OLE: Processing FAT chunks');
            fatInfo = await this.streamFATProcessing(file, headerInfo);

            // Step 3: Process directory structure chunks
            if (this.debug) console.log('Streaming OLE: Processing directory chunks');
            directories = await this.streamDirectoryProcessing(file, headerInfo, fatInfo);

            // Step 4: Stream property processing
            if (this.debug) console.log('Streaming OLE: Processing property chunks');
            properties = await this.streamPropertyProcessing(file, headerInfo, fatInfo, directories);

            // Merge results
            const finalResult = this.mergeStreamingResults(headerInfo, directories, properties);

            this.processingState = 'completed';

            if (this.debug) {
                const duration = performance.now() - startTime;
                console.log(`Streaming OLE completed in ${duration.toFixed(2)}ms`);
            }

            return finalResult;

        } catch (error) {
            this.processingState = 'error';
            throw new Error(`Streaming OLE parse failed: ${error.message}`);
        } finally {
            // Clean up
            this.cleanupStreaming();
            this.memoryManager.stopMonitoring();
        }
    }

    /**
     * Process header chunk (first 512 bytes)
     */
    async processHeaderChunk(file, offset = 0) {
        const headerSize = Math.min(512, file.size);

        try {
            const chunk = await file.slice(offset, offset + headerSize).arrayBuffer();
            const view = new DataView(chunk);

            // Track memory
            const allocationId = this.streamingTracker.trackChunkAllocation(
                'header_chunk', chunk.byteLength, chunk);

            // Validate OLE signature
            const signature = Array.from(new Uint8Array(chunk, 0, 8))
                .map(b => b.toString(16).padStart(2, '0')).join('');

            if (signature !== 'd0cf11e0a1b11ae1') {
                this.streamingTracker.deallocateChunk('header_chunk');
                throw new Error(`Invalid OLE signature: ${signature}`);
            }

            // Parse header using parent class method
            if (chunk.byteLength < 512) {
                // Pad to full header size for parent parser
                const paddedChunk = new ArrayBuffer(512);
                const paddedView = new Uint8Array(paddedChunk);
                paddedView.set(new Uint8Array(chunk.data), 0);
                chunk = { data: paddedChunk, startOffset: chunk.startOffset, endOffset: chunk.endOffset, size: paddedChunk.byteLength, isFirstChunk: chunk.isFirstChunk, isLastChunk: chunk.isLastChunk };
            }

            const headerData = {
                signature,
                headerParsed: true,
                rawData: chunk,
                allocationId
            };

            return {
                type: 'header_chunk',
                success: true,
                header: headerData,
                size: chunk.byteLength
            };

        } catch (error) {
            return {
                type: 'header_chunk',
                success: false,
                error: error.message,
                size: 0
            };
        }
    }

    /**
     * Stream FAT processing in chunks
     */
    async streamFATProcessing(file, headerInfo) {
        const fatSectors = this.calculateFATRequirements(file.size, headerInfo);
        const fatResults = [];

        for (let sectorIdx = 0; sectorIdx < fatSectors; sectorIdx++) {
            const sectorOffset = (sectorIdx + 1) * headerInfo.sectorSize;

            try {
                const sectorSize = Math.min(4096, headerInfo.sectorSize); // FAT sector size
                const chunk = await file.slice(sectorOffset, sectorOffset + sectorSize).arrayBuffer();

                const allocationId = this.streamingTracker.trackChunkAllocation(
                    `fat_sector_${sectorIdx}`, chunk.byteLength, chunk);

                // Process FAT sector data (simplified for streaming)
                const sectorData = this.parseFFATector(chunk);
                fatResults.push({
                    sectorIndex: sectorIdx,
                    data: sectorData,
                    allocationId
                });

            } catch (error) {
                if (this.debug) {
                    console.warn(`FAT sector ${sectorIdx} processing failed:`, error.message);
                }
            }

            // Memory management
            if (sectorIdx % 5 === 0) {
                await this.memoryManager.optimizeMemory();
            }
        }

        // Attempt to reconstruct FAT from processed sectors
        return await this.reconstructStreamingFAT(fatResults);
    }

    /**
     * Stream directory structure processing
     */
    async streamDirectoryProcessing(file, headerInfo, fatInfo) {
        const directories = [];
        const directorySectors = this.calculateDirectoryRequirements(file.size, headerInfo);

        for (let sectorIdx = 0; sectorIdx < directorySectors; sectorIdx++) {
            const sectorOffset = (headerInfo.directoryFirstSector + sectorIdx + 1) * headerInfo.sectorSize;

            try {
                const chunkSize = Math.min(headerInfo.sectorSize, file.size - sectorOffset);
                const chunk = await file.slice(sectorOffset, sectorOffset + chunkSize).arrayBuffer();

                const allocationId = this.streamingTracker.trackChunkAllocation(
                    `dir_sector_${sectorIdx}`, chunk.byteLength, chunk);

                // Parse directory entries from this sector
                const sectorDirectories = this.parseDirectorySector(new DataView(chunk), chunk.byteLength);
                directories.push(...sectorDirectories.map(dir => ({ ...dir, allocationId })));

            } catch (error) {
                if (this.debug) {
                    console.warn(`Directory sector ${sectorIdx} processing failed:`, error.message);
                }
            }

            // Memory management
            if (sectorIdx % 3 === 0) {
                await this.memoryManager.optimizeMemory();
            }
        }

        return directories;
    }

    /**
     * Stream property processing
     */
    async streamPropertyProcessing(file, headerInfo, fatInfo, directories) {
        const properties = [];
        const propertyDirs = directories.filter(dir =>
            dir.name && dir.name.startsWith('__substg1.0_'));

        for (let i = 0; i < propertyDirs.length; i += 10) { // Process in batches of 10
            const batch = propertyDirs.slice(i, i + 10);

            for (const dir of batch) {
                try {
                    const propertyData = await this.processPropertyStream(file, dir, headerInfo, fatInfo);

                    if (propertyData) {
                        properties.push(propertyData);
                    }

                } catch (error) {
                    if (this.debug) {
                        console.warn(`Property processing failed for ${dir.name}:`, error.message);
                    }
                }
            }

            // Memory management between batches
            await this.memoryManager.optimizeMemory();
        }

        return properties;
    }

    /**
     * Process individual property in streaming mode
     */
    async processPropertyStream(file, dir, headerInfo, fatInfo) {
        if (!dir.startSector || dir.size === 0) {
            return null;
        }

        try {
            // Determine if this is a mini-stream property
            const isMiniStream = dir.size < headerInfo.miniStreamCutoff;

            let propertyData;
            if (isMiniStream) {
                propertyData = await this.extractMiniStreamProperty(file, dir, headerInfo, fatInfo);
            } else {
                propertyData = await this.extractRegularProperty(file, dir, headerInfo, fatInfo);
            }

            return {
                name: dir.name,
                propId: this.extractPropId(dir.name),
                typeId: this.extractTypeId(dir.name),
                size: dir.size,
                data: propertyData,
                isMiniStream,
                timestamp: performance.now()
            };

        } catch (error) {
            return {
                name: dir.name,
                error: error.message,
                size: dir.size
            };
        }
    }

    /**
     * Extract regular property streams
     */
    async extractRegularProperty(file, dir, headerInfo, fatInfo) {
        const sectorChain = this.followSectorChain(dir.startSector, fatInfo);
        const data = new Uint8Array(dir.size);
        let bytesRead = 0;

        for (const sectorIndex of sectorChain) {
            if (bytesRead >= dir.size) break;

            const sectorOffset = (sectorIndex + 1) * headerInfo.sectorSize;
            const sectorSize = Math.min(headerInfo.sectorSize, dir.size - bytesRead);

            const allocationId = this.streamingTracker.trackChunkAllocation(
                `prop_sector_${sectorIndex}`, sectorSize);

            try {
                const chunk = await file.slice(sectorOffset, sectorOffset + sectorSize).arrayBuffer();
                data.set(new Uint8Array(chunk), bytesRead);
                bytesRead += chunk.byteLength;

            } catch (error) {
                if (this.debug) {
                    console.warn(`Property sector read failed for sector ${sectorIndex}:`, error.message);
                }
            }

            // Clean up
            this.streamingTracker.deallocateChunk(`prop_sector_${sectorIndex}`);
        }

        return data.slice(0, dir.size);
    }

    /**
     * Extract mini-stream properties
     */
    async extractMiniStreamProperty(file, dir, headerInfo, fatInfo) {
        // Find root entry to access mini-stream
        const rootEntry = this.findRootEntry(fatInfo);

        if (!rootEntry) {
            throw new Error('Root entry not found for mini-stream');
        }

        // Read mini-stream data
        const miniStreamData = await this.extractRegularProperty(file, rootEntry, headerInfo, fatInfo);

        // Extract property data from mini-stream
        const miniSectorOffset = dir.startSector * headerInfo.miniSectorSize;
        const miniSectorSize = Math.min(headerInfo.miniSectorSize, dir.size);

        if (miniSectorOffset + miniSectorSize > miniStreamData.length) {
            throw new Error('Mini-stream property extends beyond mini-stream length');
        }

        return miniStreamData.slice(miniSectorOffset, miniSectorOffset + dir.size);
    }

    // ============================================================================
    // UTILITY METHODS
    // ============================================================================

    calculateFATRequirements(fileSize, header) {
        // Simplified FAT sector calculation
        const maxSectors = Math.floor(fileSize / header.sectorSize);
        const fatSectors = Math.ceil(maxSectors / Math.floor(header.sectorSize / 4));
        return Math.min(fatSectors, 109); // Standard OLE limit
    }

    calculateDirectoryRequirements(fileSize, header) {
        // Estimate directory sectors needed
        const estimatedEntries = 100; // Conservative estimate
        const entriesPerSector = header.sectorSize / 128;
        return Math.ceil(estimatedEntries / entriesPerSector);
    }

    parseFFATector(sectorData) {
        const entries = [];
        const view = new DataView(sectorData);

        for (let i = 0; i < sectorData.byteLength; i += 4) {
            entries.push(view.getUint32(i, true));
        }

        return entries;
    }

    async reconstructStreamingFAT(fatSectors) {
        let currentSector = 0;
        const fatArray = [];

        for (const sectorData of fatSectors) {
            for (const entry of sectorData.data) {
                fatArray[currentSector] = entry;
                currentSector++;
            }
        }

        return fatArray;
    }

    parseDirectorySector(view, sectorSize) {
        const directories = [];

        for (let offset = 0; offset < sectorSize; offset += 128) {
            try {
                const entry = this.parseDirectoryEntry(view, offset);

                if (entry && entry.name && [1, 2, 5].includes(entry.type)) {
                    directories.push(entry);
                }
            } catch (error) {
                if (this.debug) {
                    console.warn(`Directory entry parsing failed at offset ${offset}:`, error.message);
                }
            }
        }

        return directories;
    }

    followSectorChain(startSector, fat) {
        const chain = [];
        let currentSector = startSector;
        const visited = new Set();

        while (currentSector !== 0xFFFFFFFE &&
               currentSector !== 0xFFFFFFFF &&
               !visited.has(currentSector) &&
               chain.length < 10000) { // Prevent infinite loops

            visited.add(currentSector);
            chain.push(currentSector);

            if (currentSector >= fat.length) break;
            currentSector = fat[currentSector];

            if (currentSector === 0xFFFFFFFD || currentSector === 0xFFFFFFFC) {
                break; // End of chain or special sector
            }
        }

        return chain;
    }

    findRootEntry(directories) {
        return directories.find(dir => dir.type === 5); // Root entry type
    }

    extractPropId(name) {
        const match = name.match(/__substg1\.0_([0-9A-F]{4})([0-9A-F]{4})/);
        return match ? match[1] : null;
    }

    extractTypeId(name) {
        const match = name.match(/__substg1\.0_([0-9A-F]{4})([0-9A-F]{4})/);
        return match ? match[2] : null;
    }

    mergeStreamingResults(header, directories, properties) {
        return {
            type: 'streaming_ole_result',
            header: header,
            directories: directories,
            properties: {
                totalProperties: properties.length,
                samples: properties,
                attachments: this.extractStreamingAttachments(properties),
                embeddedMessages: this.extractStreamingEmbeddedMessages(properties)
            },
            metadata: {
                processingMode: 'streaming',
                memoryStats: this.memoryManager.getMemoryStats(),
                chunkSize: this.chunkSize,
                processingState: this.processingState,
                timestamp: new Date().toISOString()
            }
        };
    }

    extractStreamingAttachments(properties) {
        // Extract attachment information from properties
        const attachments = [];
        const attachmentProps = properties.filter(p =>
            p.name && p.name.includes('__attach_version1.0_'));

        // Group by attachment
        const attachmentGroups = new Map();

        for (const prop of attachmentProps) {
            const attachId = this.extractAttachmentId(prop.name);

            if (attachId) {
                if (!attachmentGroups.has(attachId)) {
                    attachmentGroups.set(attachId, []);
                }
                attachmentGroups.get(attachId).push(prop);
            }
        }

        // Create attachment objects
        for (const [id, props] of attachmentGroups.entries()) {
            const attachment = this.buildStreamingAttachment(id, props);
            attachments.push(attachment);
        }

        return attachments;
    }

    extractStreamingEmbeddedMessages(properties) {
        // Extract embedded message information
        const embedded = [];
        const embeddedProps = properties.filter(p =>
            p.name && p.name.includes('__attach_version1.0_') &&
            p.data && this.isEmbeddedMessage(p.data));

        for (const prop of embeddedProps) {
            const embeddedMsg = {
                id: this.extractAttachmentId(prop.name),
                size: prop.size,
                propertyId: prop.propId,
                isEmbedded: true
            };
            embedded.push(embeddedMsg);
        }

        return embedded;
    }

    extractAttachmentId(name) {
        const match = name.match(/__attach_version1\.0_([A-F0-9]+)_/);
        return match ? match[1] : null;
    }

    isEmbeddedMessage(data) {
        // Check if data looks like an embedded message
        // Look for MAPI signature or embedded OLE data
        if (data.length < 8) return false;

        // Check for embedded OLE signature
        const signature = Array.from(data.slice(0, 8))
            .map(b => b.toString(16).padStart(2, '0')).join('');

        return signature === 'd0cf11e0a1b11ae1';
    }

    buildStreamingAttachment(id, properties) {
        const attachment = {
            name: 'Streaming Attachment',
            size: 0,
            type: 'unknown',
            method: 0,
            id: id,
            properties: []
        };

        // Extract information from properties
        for (const prop of properties) {
            if (prop.propId === '3704') { // PidTagAttachFilename
                attachment.name = this.tryDecodeText(prop.data) || attachment.name;
            } else if (prop.propId === '370E') { // PidTagAttachMimeTag
                attachment.type = this.tryDecodeText(prop.data) || attachment.type;
            } else if (prop.propId === '3701') { // PidTagAttachDataObject
                attachment.size = Math.max(attachment.size, prop.data.length);
                attachment.data = prop.data;
            }

            attachment.properties.push(prop);
        }

        return attachment;
    }

    tryDecodeText(data) {
        if (!data || data.length === 0) return null;

        try {
            return new TextDecoder('utf-8', { fatal: false })
                .decode(data)
                .replace(/\0/g, '');
        } catch (error) {
            return null;
        }
    }

    cleanupStreaming() {
        // Clean up all streaming allocations
        this.streamingTracker.clearStaleChunks(0);

        // Clear caches
        this.fatCache.clear();
        this.miniFatCache.clear();
        this.directoryCache.clear();

        // Reset state
        this.headerParsed = false;
        this.processingState = 'cleaned';
    }

    getStreamingStats() {
        return {
            memoryStats: this.memoryManager.getMemoryStats(),
            activeChunks: this.streamingTracker.getActiveChunks(),
            processedSectors: this.fatCache.size + this.directoryCache.size,
            processingState: this.processingState,
            totalProcessedSize: this.streamingTracker.getProcessedSize()
        };
    }
}

// Browser compatibility
if (typeof window !== 'undefined') {
    window.StreamingOLEParser = StreamingOLEParser;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = StreamingOLEParser;
}
