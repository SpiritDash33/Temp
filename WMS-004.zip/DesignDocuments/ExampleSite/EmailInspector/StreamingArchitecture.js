/**
 * Streaming Architecture for Email Parser Suite
 * Memory-efficient processing of large email files
 * Provides chunked parsing with full Phase 3 compatibility
 */
class StreamingArchitecture {
    constructor(options = {}) {
        this.chunkSize = options.chunkSize || 2 * 1024 * 1024; // 2MB default
        this.maxMemory = options.maxMemory || 10 * 1024 * 1024; // 10MB max
        this.progressCallback = options.progressCallback || null;

        // Processing state
        this.activeParsers = new Map();
        this.memoryStats = this.initializeMemoryStats();
        this.processingQueue = [];
        this.currentStream = null;
        this.cancellationToken = { cancelled: false };

        if (options.debug) {
            console.log('Streaming Architecture initialized with chunk size:', this.chunkSize, 'bytes');
        }
    }

    initializeMemoryStats() {
        return {
            peakUsage: 0,
            currentUsage: 0,
            chunksProcessed: 0,
            parserInstances: 0,
            gcCycles: 0,
            startTime: performance.now()
        };
    }

    /**
     * Determine if file should use streaming based on size
     */
    shouldUseStreaming(fileSize) {
        const thresholds = {
            small: 25 * 1024 * 1024,    // 25MB
            medium: 100 * 1024 * 1024,  // 100MB
            large: 500 * 1024 * 1024    // 500MB
        };

        if (fileSize <= thresholds.small) return false;
        if (fileSize <= thresholds.medium) return true;  // Hybrid mode
        return true;  // Full streaming mode
    }

    /**
     * Stream parse an email file
     */
    async streamParse(file, options = {}) {
        const fileSize = file.size;
        const useStreaming = options.forceStreaming || this.shouldUseStreaming(fileSize);

        if (!useStreaming) {
            throw new Error('File size below streaming threshold - use regular parsing');
        }

        this.resetState();
        this.updateProgress(0, 'Starting stream processing');

        try {
            const result = await this.processInChunks(file, options);
            this.updateProgress(100, 'Stream processing completed');
            return result;

        } catch (error) {
            this.cancellationToken.cancelled = true;
            await this.cleanup();
            throw new Error(`Streaming failed: ${error.message}`);
        }
    }

    /**
     * Process file in optimized chunks
     */
    async processInChunks(file, options) {
        const fileSize = file.size;
        const chunkCount = Math.ceil(fileSize / this.chunkSize);
        const results = [];

        for (let chunkIndex = 0; chunkIndex < chunkCount; chunkIndex++) {
            if (this.cancellationToken.cancelled) break;

            const progress = Math.round((chunkIndex / chunkCount) * 100);
            this.updateProgress(progress, `Processing chunk ${chunkIndex + 1}/${chunkCount}`);

            // Read chunk
            const startOffset = chunkIndex * this.chunkSize;
            const endOffset = Math.min(startOffset + this.chunkSize, fileSize);
            const chunk = await this.readChunk(file, startOffset, endOffset);

            // Process chunk
            const chunkResult = await this.processChunk(chunk, chunkIndex, options);
            if (chunkResult) {
                results.push(chunkResult);
            }

            // Memory management
            await this.manageMemory();

            this.memoryStats.chunksProcessed++;
        }

        // Merge results
        return this.mergeChunkResults(results, options.finalResult);
    }

    /**
     * Read specific chunk from file
     */
    async readChunk(file, startOffset, endOffset) {
        const chunkSize = endOffset - startOffset;

        if (chunkSize <= 0) {
            throw new Error('Invalid chunk range');
        }

        try {
            const arrayBuffer = await file.slice(startOffset, endOffset).arrayBuffer();

            if (arrayBuffer.byteLength !== chunkSize) {
                console.warn(`Chunk size mismatch: requested ${chunkSize}, got ${arrayBuffer.byteLength}`);
            }

            return {
                data: arrayBuffer,
                startOffset,
                endOffset,
                size: arrayBuffer.byteLength,
                isFirstChunk: startOffset === 0,
                isLastChunk: endOffset >= file.size
            };

        } catch (error) {
            throw new Error(`Failed to read chunk ${startOffset}-${endOffset}: ${error.message}`);
        }
    }

    /**
     * Process individual chunk with appropriate parser
     */
    async processChunk(chunk, chunkIndex, options) {
        this.trackMemoryUsage(chunk.size);

        try {
            // Detect file type from chunk if it's the first chunk
            if (chunk.isFirstChunk) {
                const fileType = this.detectFileType(chunk);
                this.updateProgress(0, `Detected ${fileType} file type`);
            }

            // Route to appropriate streaming parser
            const parserType = options.parserType || 'hybrid';
            const result = await this.routeToStreamingParser(chunk, chunkIndex, parserType);

            this.activeParsers.set(chunkIndex, result?.parser || 'chunk_processed');
            this.memoryStats.parserInstances = this.activeParsers.size;

            return result;

        } catch (error) {
            console.warn(`Chunk ${chunkIndex} processing failed:`, error.message);
            return {
                chunkIndex,
                error: error.message,
                size: chunk.size,
                partialData: null
            };
        }
    }

    /**
     * Detect file type from first chunk signature
     */
    detectFileType(chunk) {
        if (!chunk.isFirstChunk) return 'unknown';

        const bytes = new Uint8Array(chunk.data, 0, Math.min(512, chunk.data.byteLength));
        const signature = Array.from(bytes.slice(0, 8))
            .map(b => b.toString(16).padStart(2, '0')).join('');

        // OLE signature detection
        if (signature === 'd0cf11e0a1b11ae1') {
            return 'msg';
        }

        // Try EML detection
        const text = new TextDecoder('utf-8', { fatal: false }).decode(bytes).toLowerCase();

        if (text.includes('from:') || text.includes('subject:') || text.includes('mime-version:')) {
            return 'eml';
        }

        return 'unknown';
    }

    /**
     * Route chunk to appropriate streaming parser
     */
    async routeToStreamingParser(chunk, chunkIndex, parserType) {
        // This will be expanded when we implement the specific parsers

        if (parserType === 'ole' || parserType === 'hybrid') {
            // For OLE files, we'd use StreamingOLEParser
            return await this.processOLEChunk(chunk, chunkIndex);
        }

        if (parserType === 'eml' || parserType === 'hybrid') {
            // For EML files, we'd use StreamingEMLParser
            return await this.processEMLChunk(chunk, chunkIndex);
        }

        throw new Error(`Unsupported parser type: ${parserType}`);
    }

    /**
     * Process OLE (MSG) chunk
     */
    async processOLEChunk(chunk, chunkIndex) {
        // Placeholder for OLE streaming processing
        // Will be implemented with StreamingOLEParser

        if (chunk.isFirstChunk) {
            return {
                type: 'ole_header',
                chunkIndex,
                header: 'processed',
                fatInfo: 'pending'
            };
        }

        return {
            type: 'ole_data',
            chunkIndex,
            processed: chunk.size,
            partialResults: {}
        };
    }

    /**
     * Process EML chunk
     */
    async processEMLChunk(chunk, chunkIndex) {
        // Placeholder for EML streaming processing
        // Will be implemented with StreamingEMLParser

        if (chunk.isFirstChunk) {
            return {
                type: 'eml_headers',
                chunkIndex,
                headersExtracted: [],
                boundary: null
            };
        }

        return {
            type: 'eml_body',
            chunkIndex,
            bodyProcessed: chunk.size,
            attachments: []
        };
    }

    /**
     * Merge chunk processing results
     */
    mergeChunkResults(chunkResults, expectedResultType) {
        const merged = {
            type: expectedResultType || 'stream_result',
            chunksProcessed: chunkResults.length,
            totalSize: chunkResults.reduce((sum, r) => sum + (r.size || 0), 0),
            errors: [],
            partialResults: [],
            metadata: {
                streamingMode: true,
                chunkSize: this.chunkSize,
                processingTime: performance.now() - this.memoryStats.startTime
            }
        };

        // Categorize results
        for (const result of chunkResults) {
            if (result.error) {
                merged.errors.push(result);
            } else {
                merged.partialResults.push(result);
            }
        }

        return merged;
    }

    /**
     * Memory management and garbage collection
     */
    async manageMemory() {
        const currentUsage = this.getCurrentMemoryUsage();

        // Force garbage collection if approaching limit
        if (currentUsage > this.maxMemory * 0.8) {
            this.forceGarbageCollection();
            this.memoryStats.gcCycles++;
        }

        // Clean up finished processing
        await this.cleanupCompletedChunks();

        // Report memory stats
        this.trackMemoryUsage(0);
    }

    forceGarbageCollection() {
        // In browsers/Node.js, we can force GC
        if (typeof global !== 'undefined' && global.gc) {
            global.gc();
        } else if (typeof window !== 'undefined' && window.gc) {
            window.gc();
        }
    }

    async cleanupCompletedChunks() {
        // Remove completed parser instances
        const completedParsers = [];

        for (const [chunkIndex, parser] of this.activeParsers.entries()) {
            if (parser.completed || parser.error) {
                completedParsers.push(chunkIndex);
            }
        }

        // Clean up memory
        for (const chunkIndex of completedParsers) {
            this.activeParsers.delete(chunkIndex);
            // Additional cleanup as needed
        }
    }

    trackMemoryUsage(additionalBytes) {
        const currentUsage = this.getCurrentMemoryUsage() + additionalBytes;
        this.memoryStats.currentUsage = currentUsage;

        if (currentUsage > this.memoryStats.peakUsage) {
            this.memoryStats.peakUsage = currentUsage;
        }

        return currentUsage;
    }

    getCurrentMemoryUsage() {
        // Rough estimation - in production would use performance.memory
        let usage = 0;

        // Estimate based on active parsers and buffers
        usage += this.activeParsers.size * 1024 * 1024; // ~1MB per active parser
        usage += this.memoryStats.chunksProcessed * 512; // Metadata overhead

        return usage;
    }

    updateProgress(percent, message) {
        if (this.progressCallback) {
            this.progressCallback(percent, message, this.getStreamingStats());
        }
    }

    getStreamingStats() {
        return {
            ...this.memoryStats,
            activeParsers: this.activeParsers.size,
            peakMemory: Math.round(this.memoryStats.peakUsage / 1024 / 1024 * 100) / 100,
            currentMemory: Math.round(this.memoryStats.currentUsage / 1024 / 1024 * 100) / 100,
            isActive: !this.cancellationToken.cancelled
        };
    }

    /**
     * Cancel ongoing streaming operation
     */
    cancel() {
        this.cancellationToken.cancelled = true;
        this.updateProgress(0, 'Cancelled by user');

        return this.cleanup();
    }

    async cleanup() {
        this.activeParsers.clear();
        this.processingQueue.length = 0;

        if (this.currentStream) {
            // Clean up any active streams
        }

        // Force final garbage collection
        this.forceGarbageCollection();

        return true;
    }

    resetState() {
        this.cancellationToken.cancelled = false;
        this.activeParsers.clear();
        this.processingQueue.length = 0;
        this.memoryStats = this.initializeMemoryStats();

        if (this.currentStream) {
            this.currentStream = null;
        }
    }

    /**
     * Get optimal chunk size for file size
     */
    getOptimalChunkSize(fileSize) {
        const sizeInMB = fileSize / 1024 / 1024;

        if (sizeInMB < 50) return 1024 * 1024;       // 1MB for small files
        if (sizeInMB < 100) return 2 * 1024 * 1024;  // 2MB for medium
        if (sizeInMB < 500) return 4 * 1024 * 1024;  // 4MB for large
        if (sizeInMB < 1024) return 8 * 1024 * 1024; // 8MB for extra large

        return 16 * 1024 * 1024; // 16MB for enterprise files
    }

    /**
     * Set progress callback
     */
    onProgress(callback) {
        this.progressCallback = callback;
        return this;
    }
}

// Browser compatibility
if (typeof window !== 'undefined') {
    window.StreamingArchitecture = StreamingArchitecture;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = StreamingArchitecture;
}
