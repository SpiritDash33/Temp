/**
 * Enhanced OLE (Object Linking and Embedding) Parser
 * Fully compliant with MS-OXMSG and OLE specifications
 * Handles all edge cases, large files, mini-sectors, and embedded messages
 */
class OLEParser {
    constructor() {
        this.debug = true;
        this.maxRecursionDepth = 10;
        this.maxFileSize = 1024 * 1024 * 1024; // 1GB limit
        this.cache = new Map();
    }

    async parseFile(file) {
        if (file.size > this.maxFileSize) {
            throw new Error(`File too large: ${file.size} bytes (max: ${this.maxFileSize})`);
        }

        const buffer = await file.arrayBuffer();
        if (buffer.byteLength < 512) {
            throw new Error('File too small for OLE format');
        }

        const view = new DataView(buffer);

        // Validate OLE signature
        const signature = Array.from(new Uint8Array(buffer, 0, 8))
            .map(b => b.toString(16).padStart(2, '0')).join('');
        if (signature !== 'd0cf11e0a1b11ae1') {
            throw new Error('Invalid OLE file signature');
        }

        const header = this.parseHeader(view);
        if (this.debug) {
            console.log('File size:', buffer.byteLength, 'Sector size:', header.sectorSize);
        }

        // Build File Allocation Table with DIFAT support
        const fat = this.buildCompleteFAT(view, header);
        
        // Build Mini-FAT for small streams
        const miniFat = this.buildMiniFAT(view, header, fat);
        
        if (this.debug) {
            console.log('FAT entries:', fat.length, 'Mini-FAT entries:', miniFat.length);
        }

        // Parse directory structure with full tree support
        const { directories, tree } = this.parseDirectories(view, header, fat);
        if (this.debug) {
            console.log('Directory entries:', directories.length);
        }

        // Find root entry for mini-stream access
        const rootEntry = directories.find(d => d.type === 5);
        if (!rootEntry) {
            throw new Error('Root directory entry not found');
        }

        // Complete property analysis with all MS-OXPROPS support
        const propertyAnalysis = this.analyzePropertiesComplete(view, directories, header, fat, miniFat, rootEntry);
        
        if (this.debug) {
            console.log('Properties analyzed:', propertyAnalysis.totalProperties);
        }

        return {
            header,
            directories,
            tree,
            fat,
            miniFat,
            propertyAnalysis,
            rootEntry,
            rawSize: buffer.byteLength
        };
    }

    parseHeader(view) {
        try {
            const header = {
                // OLE signature already validated
                minorVersion: view.getUint16(24, true),
                majorVersion: view.getUint16(26, true),
                byteOrder: view.getUint16(28, true),
                sectorSize: Math.pow(2, view.getUint16(30, true)),
                miniSectorSize: Math.pow(2, view.getUint16(32, true)),
                
                // Reserved fields
                reserved1: view.getUint32(34, true),
                reserved2: view.getUint32(38, true),
                
                // FAT information
                directoryFirstSector: view.getUint32(48, true),
                transactionSignature: view.getUint32(52, true),
                miniStreamCutoff: view.getUint32(56, true),
                miniFatFirstSector: view.getUint32(60, true),
                miniFatSectors: view.getUint32(64, true),
                difatFirstSector: view.getUint32(68, true),
                difatSectors: view.getUint32(72, true),
                fatSectors: view.getUint32(44, true)
            };

            // Validation
            if (header.byteOrder !== 0xFFFE) {
                throw new Error('Invalid byte order identifier');
            }
            
            if (header.sectorSize < 512 || header.miniSectorSize < 64) {
                throw new Error('Invalid sector sizes');
            }

            return header;
        } catch (e) {
            throw new Error(`Header parsing failed: ${e.message}`);
        }
    }

    buildCompleteFAT(view, header) {
        const fat = [];
        const sectorsPerFatSector = header.sectorSize / 4;
        const processedSectors = new Set();

        // Process initial 109 DIFAT entries from header
        for (let i = 0; i < Math.min(109, header.fatSectors); i++) {
            const fatSector = view.getUint32(76 + i * 4, true);
            if (fatSector === 0xFFFFFFFE || processedSectors.has(fatSector)) {
                break;
            }
            
            if (this.isValidSectorNumber(fatSector, view.byteLength, header.sectorSize)) {
                this.readFatSector(view, fatSector, header, fat, sectorsPerFatSector);
                processedSectors.add(fatSector);
            }
        }

        // Process DIFAT chain for large files (>109 FAT sectors)
        if (header.difatSectors > 0) {
            this.processDIFATChain(view, header, fat, sectorsPerFatSector, processedSectors);
        }

        // Validate FAT to prevent infinite loops
        this.validateFAT(fat);

        return fat;
    }

    processDIFATChain(view, header, fat, sectorsPerFatSector, processedSectors) {
        let currentDifatSector = header.difatFirstSector;
        let difatSectorCount = 0;

        while (currentDifatSector !== 0xFFFFFFFE && 
               difatSectorCount < header.difatSectors &&
               !processedSectors.has(currentDifatSector)) {
            
            if (!this.isValidSectorNumber(currentDifatSector, view.byteLength, header.sectorSize)) {
                console.warn(`Invalid DIFAT sector: ${currentDifatSector}`);
                break;
            }

            const difatOffset = (currentDifatSector + 1) * header.sectorSize;
            
            try {
                // Process FAT sectors referenced in this DIFAT sector
                for (let i = 0; i < sectorsPerFatSector - 1; i++) {
                    const fatSector = view.getUint32(difatOffset + i * 4, true);
                    
                    if (fatSector === 0xFFFFFFFE) break;
                    
                    if (!processedSectors.has(fatSector) && 
                        this.isValidSectorNumber(fatSector, view.byteLength, header.sectorSize)) {
                        this.readFatSector(view, fatSector, header, fat, sectorsPerFatSector);
                        processedSectors.add(fatSector);
                    }
                }

                // Get next DIFAT sector
                currentDifatSector = view.getUint32(difatOffset + (sectorsPerFatSector - 1) * 4, true);
                difatSectorCount++;
                
            } catch (e) {
                console.warn(`Error processing DIFAT sector ${currentDifatSector}: ${e.message}`);
                break;
            }
        }
    }

    readFatSector(view, sector, header, fat, sectorsPerFatSector) {
        const offset = (sector + 1) * header.sectorSize;
        
        if (offset + header.sectorSize > view.byteLength) {
            console.warn(`FAT sector ${sector} extends beyond file bounds`);
            return;
        }

        try {
            for (let j = 0; j < sectorsPerFatSector; j++) {
                const fatEntry = view.getUint32(offset + j * 4, true);
                fat.push(fatEntry);
            }
        } catch (e) {
            console.warn(`Invalid FAT entry at sector ${sector}, offset ${j}: ${e.message}`);
        }
    }

    buildMiniFAT(view, header, fat) {
        const miniFat = [];
        const rootEntry = this.getRootEntry(view, header, fat);
        
        if (!rootEntry || header.miniFatFirstSector === 0xFFFFFFFE) {
            return miniFat;
        }

        let currentSector = header.miniFatFirstSector;
        const sectorsPerMiniFat = header.sectorSize / 4;
        const processedSectors = new Set();
        
        while (currentSector !== 0xFFFFFFFE && 
               currentSector < fat.length &&
               !processedSectors.has(currentSector)) {
            
            const offset = (currentSector + 1) * header.sectorSize;
            
            if (offset + header.sectorSize > view.byteLength) {
                console.warn(`Mini-FAT sector ${currentSector} extends beyond file bounds`);
                break;
            }

            try {
                for (let i = 0; i < sectorsPerMiniFat; i++) {
                    const miniFatEntry = view.getUint32(offset + i * 4, true);
                    miniFat.push(miniFatEntry);
                }
                
                processedSectors.add(currentSector);
                currentSector = fat[currentSector] || 0xFFFFFFFE;
                
            } catch (e) {
                console.warn(`Invalid mini-FAT entry at sector ${currentSector}: ${e.message}`);
                break;
            }
        }

        return miniFat;
    }

    getRootEntry(view, header, fat) {
        let currentSector = header.directoryFirstSector;
        const processedSectors = new Set();

        while (currentSector !== 0xFFFFFFFE && 
               currentSector < fat.length &&
               !processedSectors.has(currentSector)) {
            
            const sectorOffset = (currentSector + 1) * header.sectorSize;
            
            if (sectorOffset + header.sectorSize > view.byteLength) {
                break;
            }

            try {
                for (let i = 0; i < header.sectorSize; i += 128) {
                    const entry = this.parseDirectoryEntry(view, sectorOffset + i);
                    if (entry && entry.type === 5) {
                        return entry;
                    }
                }
            } catch (e) {
                console.warn(`Error reading directory sector ${currentSector}: ${e.message}`);
            }

            processedSectors.add(currentSector);
            currentSector = fat[currentSector] || 0xFFFFFFFE;
        }

        return null;
    }

    parseDirectories(view, header, fat) {
        const directories = [];
        const tree = { root: null, nodes: new Map() };
        let currentSector = header.directoryFirstSector;
        const processedSectors = new Set();

        while (currentSector !== 0xFFFFFFFE && 
               currentSector < fat.length &&
               !processedSectors.has(currentSector)) {
            
            const sectorOffset = (currentSector + 1) * header.sectorSize;
            
            if (sectorOffset + header.sectorSize > view.byteLength) {
                console.warn(`Directory sector ${currentSector} extends beyond file bounds`);
                break;
            }

            try {
                for (let i = 0; i < header.sectorSize; i += 128) {
                    const entry = this.parseDirectoryEntry(view, sectorOffset + i);
                    
                    if (entry && entry.name && entry.name.length > 0 && [1, 2, 5].includes(entry.type)) {
                        const index = directories.length;
                        directories.push(entry);
                        
                        // Build tree node with sibling/child references
                        tree.nodes.set(index, {
                            ...entry,
                            children: [],
                            leftSibling: view.getUint32(sectorOffset + i + 68, true),
                            rightSibling: view.getUint32(sectorOffset + i + 72, true),
                            child: view.getUint32(sectorOffset + i + 76, true),
                        });
                    }
                }
            } catch (e) {
                console.warn(`Error parsing directory entries in sector ${currentSector}: ${e.message}`);
            }

            processedSectors.add(currentSector);
            currentSector = fat[currentSector] || 0xFFFFFFFE;
        }

        // Find root and build tree structure
        const rootIndex = directories.findIndex(d => d.type === 5);
        if (rootIndex >= 0) {
            tree.root = rootIndex;
            this.buildDirectoryTree(tree, rootIndex, new Set());
        }

        return { directories, tree };
    }

    parseDirectoryEntry(view, offset) {
        try {
            const nameLength = view.getUint16(offset + 64, true);
            
            if (nameLength === 0 || nameLength > 64) {
                return null; // Invalid entry
            }

            let name = '';
            for (let i = 0; i < Math.min(nameLength - 2, 62); i += 2) {
                const char = view.getUint16(offset + i, true);
                if (char === 0) break;
                name += String.fromCharCode(char);
            }

            const type = view.getUint8(offset + 66);
            const nodeColor = view.getUint8(offset + 67); // Red/Black tree color
            const startSector = view.getUint32(offset + 116, true);
            const size = view.getUint32(offset + 120, true);

            // Additional validation
            if (type < 0 || type > 5) {
                return null;
            }

            return {
                name,
                type,
                nodeColor,
                startSector,
                size,
                creationTime: this.parseFileTime(view, offset + 100),
                modifiedTime: this.parseFileTime(view, offset + 108)
            };
            
        } catch (e) {
            console.warn(`Directory entry parsing failed at offset ${offset}: ${e.message}`);
            return null;
        }
    }

    parseFileTime(view, offset) {
        try {
            const low = view.getUint32(offset, true);
            const high = view.getUint32(offset + 4, true);
            
            if (low === 0 && high === 0) {
                return null; // No timestamp
            }

            const filetime = (high * 0x100000000) + low;
            const epochDiff = 11644473600000; // milliseconds between 1601 and 1970
            return new Date(filetime / 10000 - epochDiff);
            
        } catch (e) {
            console.warn(`Failed to parse FILETIME at offset ${offset}: ${e.message}`);
            return null;
        }
    }

    buildDirectoryTree(tree, parentIndex, visited) {
        if (visited.has(parentIndex)) {
            return; // Prevent infinite recursion
        }
        
        visited.add(parentIndex);
        const node = tree.nodes.get(parentIndex);
        
        if (!node || node.child === 0xFFFFFFFF) {
            return;
        }

        // Process child
        if (tree.nodes.has(node.child)) {
            node.children.push(node.child);
            this.buildDirectoryTree(tree, node.child, new Set(visited));
        }

        // Process siblings
        if (node.leftSibling !== 0xFFFFFFFF && tree.nodes.has(node.leftSibling)) {
            this.buildDirectoryTree(tree, node.leftSibling, new Set(visited));
        }
        
        if (node.rightSibling !== 0xFFFFFFFF && tree.nodes.has(node.rightSibling)) {
            this.buildDirectoryTree(tree, node.rightSibling, new Set(visited));
        }
    }

    analyzePropertiesComplete(view, directories, header, fat, miniFat, rootEntry) {
        const analysis = { 
            totalProperties: 0, 
            samples: [],
            attachments: [],
            embeddedMessages: []
        };

        directories.forEach((dir, index) => {
            if (!dir.name.startsWith('__substg1.0_')) {
                return;
            }

            analysis.totalProperties++;

            try {
                let data;
                
                // Determine if this is a mini-stream or regular stream
                if (dir.size < header.miniStreamCutoff && dir.size > 0) {
                    data = this.readMiniStream(view, dir.startSector, dir.size, header, miniFat, rootEntry);
                } else {
                    data = this.readCompleteSectorChain(view, dir.startSector, dir.size, header, fat);
                }

                if (data && data.length > 0) {
                    const propId = dir.name.match(/__substg1\.0_([0-9A-F]{4})([0-9A-F]{4})/)?.[1];
                    const typeId = dir.name.match(/__substg1\.0_([0-9A-F]{4})([0-9A-F]{4})/)?.[2];
                    
                    const sample = {
                        name: dir.name,
                        propId,
                        typeId,
                        size: dir.size,
                        actualSize: data.length,
                        isBinary: this.isBinaryProperty(propId, typeId),
                        textSample: this.tryDecodeText(data.slice(0, 200)),
                        fullText: null,
                        rawData: null
                    };

                    if (sample.isBinary) {
                        sample.rawData = data;
                        sample.fullText = '[binary data]';
                    } else {
                        sample.fullText = this.tryDecodeText(data);
                    }

                    analysis.samples.push(sample);

                    // Identify attachments and embedded messages
                    if (dir.name.includes('__attach_version1.0_')) {
                        this.categorizeAttachment(sample, analysis, directories, index);
                    }
                }
            } catch (e) {
                console.warn(`Error processing property ${dir.name}: ${e.message}`);
            }
        });

        return analysis;
    }

    categorizeAttachment(sample, analysis, directories, dirIndex) {
        const attachmentInfo = {
            dirIndex,
            name: 'Unknown Attachment',
            size: sample.size,
            type: 'unknown',
            method: 0,
            isEmbedded: false
        };

        // Check attachment method to identify embedded messages
        if (sample.propId === '3705') { // PidTagAttachMethod
            attachmentInfo.method = this.parseAttachmentMethod(sample.rawData);
            attachmentInfo.isEmbedded = attachmentInfo.method === 5; // ATTACH_EMBEDDED_MSG
        }

        if (attachmentInfo.isEmbedded) {
            analysis.embeddedMessages.push(attachmentInfo);
        } else {
            analysis.attachments.push(attachmentInfo);
        }
    }

    parseAttachmentMethod(rawData) {
        try {
            if (rawData && rawData.length >= 4) {
                return new DataView(rawData.buffer).getUint32(0, true);
            }
        } catch (e) {
            console.warn('Failed to parse attachment method:', e.message);
        }
        return 0;
    }

    readMiniStream(view, startSector, size, header, miniFat, rootEntry) {
        if (!rootEntry || startSector >= miniFat.length || size === 0) {
            return new Uint8Array(0);
        }

        // Read root entry data to access mini-stream
        const rootData = this.readCompleteSectorChain(view, rootEntry.startSector, rootEntry.size, header, []);
        if (!rootData || rootData.length === 0) {
            return new Uint8Array(0);
        }

        const data = new Uint8Array(size);
        let bytesRead = 0;
        let currentMiniSector = startSector;
        const processedSectors = new Set();

        while (bytesRead < size && 
               currentMiniSector !== 0xFFFFFFFE && 
               currentMiniSector < miniFat.length &&
               !processedSectors.has(currentMiniSector)) {
            
            const miniSectorOffset = currentMiniSector * header.miniSectorSize;
            
            if (miniSectorOffset + header.miniSectorSize > rootData.length) {
                console.warn(`Mini-sector ${currentMiniSector} extends beyond root stream`);
                break;
            }

            const bytesToRead = Math.min(header.miniSectorSize, size - bytesRead);
            
            try {
                data.set(rootData.slice(miniSectorOffset, miniSectorOffset + bytesToRead), bytesRead);
                bytesRead += bytesToRead;
                processedSectors.add(currentMiniSector);
                currentMiniSector = miniFat[currentMiniSector] || 0xFFFFFFFE;
                
            } catch (e) {
                console.warn(`Error reading mini-sector ${currentMiniSector}: ${e.message}`);
                break;
            }
        }

        return data.slice(0, bytesRead);
    }

    readCompleteSectorChain(view, startSector, size, header, fat) {
        if (startSector >= fat.length || size === 0) {
            return new Uint8Array(0);
        }

        const data = new Uint8Array(size);
        let bytesRead = 0;
        let currentSector = startSector;
        const processedSectors = new Set();

        while (bytesRead < size && 
               currentSector !== 0xFFFFFFFE && 
               currentSector < fat.length &&
               !processedSectors.has(currentSector)) {
            
            const sectorOffset = (currentSector + 1) * header.sectorSize;
            
            if (sectorOffset + header.sectorSize > view.byteLength) {
                console.warn(`Sector ${currentSector} extends beyond file bounds`);
                break;
            }

            const bytesToRead = Math.min(header.sectorSize, size - bytesRead);
            
            try {
                for (let i = 0; i < bytesToRead; i++) {
                    data[bytesRead + i] = view.getUint8(sectorOffset + i);
                }
                
                bytesRead += bytesToRead;
                processedSectors.add(currentSector);
                currentSector = fat[currentSector] || 0xFFFFFFFE;
                
            } catch (e) {
                console.warn(`Error reading sector ${currentSector}: ${e.message}`);
                break;
            }
        }

        return data.slice(0, bytesRead);
    }

    tryDecodeText(data) {
        if (!data || data.length === 0) {
            return '';
        }

        // Try UTF-16LE with BOM handling (most common for .msg files)
        try {
            const hasBOM = data.length >= 2 && data[0] === 0xFF && data[1] === 0xFE;
            const start = hasBOM ? 2 : 0;
            const text = new TextDecoder('utf-16le', { fatal: false }).decode(data.slice(start));
            const cleaned = text.replace(/\0/g, '').replace(/\r\n/g, '\n').trim();
            
            if (cleaned.length > 0 && this.isValidText(cleaned)) {
                return cleaned;
            }
        } catch (e) {
            if (this.debug) console.warn('UTF-16LE decode failed:', e.message);
        }

        // Try UTF-8
        try {
            const text = new TextDecoder('utf-8', { fatal: true }).decode(data);
            const cleaned = text.replace(/\0/g, '').replace(/\r\n/g, '\n').trim();
            
            if (cleaned.length > 0) {
                return cleaned;
            }
        } catch (e) {
            if (this.debug) console.warn('UTF-8 decode failed:', e.message);
        }

        // Try Windows-1252 (legacy support)
        try {
            const text = Array.from(data)
                .map(b => String.fromCharCode(b))
                .join('')
                .replace(/\0/g, '')
                .replace(/\r\n/g, '\n')
                .trim();
                
            if (text.length > 0 && this.isValidText(text)) {
                return text;
            }
        } catch (e) {
            if (this.debug) console.warn('Windows-1252 decode failed:', e.message);
        }

        // Try ISO-8859-1 as final fallback
        try {
            const text = Array.from(data)
                .map(b => String.fromCharCode(b > 127 ? 65533 : b)) // Replace high bytes with replacement char
                .join('')
                .replace(/\0/g, '')
                .trim();
                
            if (text.length > 0) {
                return text;
            }
        } catch (e) {
            if (this.debug) console.warn('ISO-8859-1 decode failed:', e.message);
        }

        return '[binary data]';
    }

    isValidText(text) {
        // Check for reasonable text content (not binary garbage)
        const printableChars = text.match(/[\x20-\x7E]/g) || [];
        const totalChars = text.length;
        
        if (totalChars === 0) return false;
        
        // At least 70% printable ASCII characters
        return (printableChars.length / totalChars) >= 0.7;
    }

    isBinaryProperty(propId, typeId) {
        // MS-OXPROPS binary property types
        const binaryPropIds = [
            '1009', // PidTagRtfCompressed
            '101B', // Unknown binary
            '3701', // PidTagAttachDataObject
            '3704', // Sometimes binary (depends on type)
            '370E', // Can be binary
            '0FF9', // PidTagRecordKey
            '0FFB'  // PidTagSearchKey
        ];
        
        // PtypBinary type identifiers
        const binaryTypeIds = ['0102', '101E', '101F'];
        
        return binaryPropIds.includes(propId) || binaryTypeIds.includes(typeId);
    }

    validateFAT(fat) {
        const visited = new Set();
        
        for (let i = 0; i < fat.length; i++) {
            if (visited.has(i)) continue;
            
            let current = i;
            const chainVisited = new Set();
            
            // Follow chain to detect loops
            while (current !== 0xFFFFFFFE && 
                   current !== 0xFFFFFFFD && 
                   current !== 0xFFFFFFFC &&
                   current < fat.length) {
                
                if (chainVisited.has(current)) {
                    console.warn(`FAT loop detected starting at sector ${i}`);
                    break;
                }
                
                chainVisited.add(current);
                visited.add(current);
                current = fat[current];
            }
        }
    }

    isValidSectorNumber(sector, fileSize, sectorSize) {
        const maxSectors = Math.floor(fileSize / sectorSize) - 1;
        return sector >= 0 && sector <= maxSectors && sector !== 0xFFFFFFFE;
    }
}

// Browser compatibility
if (typeof window !== 'undefined') {
    window.OLEParser = OLEParser;
}

// Node.js compatibility
if (typeof module !== 'undefined' && module.exports) {
    module.exports = OLEParser;
}
