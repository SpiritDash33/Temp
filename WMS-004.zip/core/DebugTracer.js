// DebugTracer.js - Simple, lightweight tracing utility for debugging
// Usage:
//   DebugTracer.enable();  // Turn on tracing
//   DebugTracer.traceEntry('functionName', { param1, param2 });
//   // ... function logic ...
//   DebugTracer.traceExit('functionName', { result });
//   DebugTracer.disable(); // Turn off tracing

class DebugTracer {
    static enabled = false;
    static indentLevel = 0;
    
    /**
     * Basic trace logging
     * @param {string} functionName - Name of the function being traced
     * @param {Object} variables - Variables to log
     * @param {string} action - 'entry' or 'exit'
     */
    static trace(functionName, variables = {}, action = 'entry') {
        if (!this.enabled) return;
        
        const indent = '  '.repeat(this.indentLevel);
        const timestamp = new Date().toISOString().split('T')[1];
        console.log(`${indent}🔍 [${timestamp}] ${functionName} ${action}:`, variables);
    }
    
    /**
     * Trace function entry with auto-indent
     * @param {string} functionName - Name of the function
     * @param {Object} vars - Variables to log
     */
    static traceEntry(functionName, vars = {}) {
        this.trace(functionName, vars, 'entry');
        this.indentLevel++;
    }
    
    /**
     * Trace function exit with auto-dedent
     * @param {string} functionName - Name of the function
     * @param {Object} vars - Variables to log
     */
    static traceExit(functionName, vars = {}) {
        this.indentLevel = Math.max(0, this.indentLevel - 1);
        this.trace(functionName, vars, 'exit');
    }
    
    /**
     * Enable tracing
     */
    static enable() {
        this.enabled = true;
        console.log('✅ DebugTracer enabled');
    }
    
    /**
     * Disable tracing
     */
    static disable() {
        this.enabled = false;
        this.indentLevel = 0;
        console.log('❌ DebugTracer disabled');
    }
    
    /**
     * Check if tracing is enabled
     */
    static isEnabled() {
        return this.enabled;
    }
}

// Make it globally available
if (typeof window !== 'undefined') {
    window.DebugTracer = DebugTracer;
}
