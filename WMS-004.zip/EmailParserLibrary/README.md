# Email Parser Library

A comprehensive JavaScript email parsing library for Microsoft MSG and EML/MIME files.

## Files Included

- `EmailParser.js` - Main orchestrator class
- `OLEParser.js` - Microsoft OLE file system parser
- `MSGExtractor.js` - MAPI property extraction for MSG files
- `EMLParser.js` - RFC5322/MIME compliant EML parser
- `RTFDecompressor.js` - RTF decompression (MS-OXRTFCP)
- `SMIMECrypto.js` - S/MIME cryptographic operations
- `AdvancedMIMEParser.js` - Advanced MIME type processing
- `MemoryManager.js` - Memory management for streaming
- `EMAIL_PARSER_LIBRARY_DOCUMENTATION.md` - Complete API documentation

## Quick Start

```javascript
// Include all required files in your HTML
<script src="OLEParser.js"></script>
<script src="MSGExtractor.js"></script>
<script src="EMLParser.js"></script>
<script src="RTFDecompressor.js"></script>
<script src="SMIMECrypto.js"></script>
<script src="AdvancedMIMEParser.js"></script>
<script src="MemoryManager.js"></script>
<script src="EmailParser.js"></script>

// Parse an email file
const parser = new EmailParser();
const email = await parser.parse(file);
```

## Features

- Complete MSG and EML/MIME support
- S/MIME cryptography
- Streaming for large files
- Advanced MIME types (calendar, contacts, documents)
- Error recovery
- Memory management

See `EMAIL_PARSER_LIBRARY_DOCUMENTATION.md` for complete documentation.